# Copyright 2026 Qore Technologies, s.r.o.; SPDX-License-Identifier: MIT
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys
root=Path.cwd();repo=root/'work/checkouts/packaging-pdf-installed-20261008';out=root/'results/pdf-installed-local2-20261008';out.mkdir()
sys.path.insert(0,str(repo/'tools'));spec=importlib.util.spec_from_file_location('qualify',repo/'tools/qualify-installed.py');qual=importlib.util.module_from_spec(spec);spec.loader.exec_module(qual)
key=json.loads((root/'qualification/v8-leap-aarch64.json').read_text())['signing_key'];qual.fetch_source(key['url'],key['sha256'],out/'signing-key.asc')
old=json.loads((root/'evidence/pdf-rpm-candidate-20261003.json').read_text())['canonical_targets']
native=json.loads((root/'results/pdfium-native-rev3-20261008/verified-summary.json').read_text())
source_commit='cc9bb928a6cbf7a475c2c61ca1d8869c92302ff5'
script=out/'inside.py';script.write_text('''from pathlib import Path
import os,json,subprocess,sys,importlib.util
sys.path.insert(0,'/packaging/tools');s=importlib.util.spec_from_file_location('qualify','/packaging/tools/qualify-installed.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
phase,target=sys.argv[1:];dest=Path('/results');directory=Path('/fixture');rows=[]
# The signed OBS dependency is installed over the already-qualified canonical module image.
rpms=sorted(str(p) for p in Path('/rpms').glob('*.rpm') if phase=='sdk' or p.name.startswith('libpdfium-qore148-0-'))
commands=[('import-key',['rpm','--import','/signing-key.asc']),('signature',['rpmkeys','--checksig','--verbose',*rpms]),('install',['rpm','-Uvh','--replacepkgs',*rpms])]
deps=q.module_dependencies('pdf','runtime',target)+q.module_dependencies('pdf','sdk',target) if phase=='sdk' else q.module_dependencies('pdf','runtime',target)
commands.append(('fixture-dependencies',(['zypper','--non-interactive','install','--no-recommends'] if target=='suse' else ['dnf','-y','--setopt=install_weak_deps=False','install'])+deps))
for name,cmd in commands:
 with (dest/(name+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit_code':p.returncode});(dest/'status.json').write_text(json.dumps(rows,indent=2)+'\\n');p.check_returncode()
q.require_rpm_signature((dest/'signature.log').read_text())
subprocess.run(['chown','-R','1019:100','/fixture'],check=True)
if phase=='runtime':
 for name in ['qore-devel','gcc','gcc-c++','libpdfium-qore-devel']:
  assert subprocess.run(['rpm','-q',name],stdout=subprocess.DEVNULL).returncode==1,name
with (dest/'packages.log').open('w') as log:subprocess.run(['rpm','-qa','--qf','%{NAME} %{EVR}.%{ARCH}\\n'],stdout=log,check=True)
files=subprocess.check_output(['rpm','-ql','qore-pdf-module'],text=True);api=subprocess.check_output(['qore','--latest-module-api'],text=True).strip();binary=q.installed_module_file('pdf',files,'/pdf-api-'+api+'.qmod')
for name,cmd in q.module_commands('pdf',phase,directory,binary,installed_files=files):
 env=['setpriv','--reuid=1019','--regid=100','--clear-groups','env','-u','QORE_MODULE_DIR','-u','QORE_MODULE_DIR_ONLY','-u','QORE_INCLUDE_DIR','-u','LD_LIBRARY_PATH','-u','LD_PRELOAD','HOME=/fixture','AUTOPKGTEST_TMP=/fixture']
 with (dest/(name+'.log')).open('w') as log:p=subprocess.run(env+cmd,cwd=directory,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':env+cmd,'exit_code':p.returncode});(dest/'status.json').write_text(json.dumps(rows,indent=2)+'\\n');print(name,p.returncode,flush=True);p.check_returncode()
''')
def run(target):
 obs={'fedora':'Fedora_44','leap':'openSUSE_Leap_16.0','el10':'AlmaLinux_10'}[target];family={'fedora':'fedora','leap':'suse','el10':'el'}[target]
 dest=out/target;dest.mkdir();rpms=dest/'rpms';rpms.mkdir()
 rows=native[obs+'/x86_64']['rpm_outputs'];files=[r['filename'] for r in rows if r['filename'].startswith(('libpdfium-qore148-0-148','libpdfium-qore-devel-'))]
 assert len(files)==2,files
 hashes={}
 for filename in files:
  with (rpms/filename).open('wb') as f:subprocess.run(['osc','api','/build/home:davidnichols:qore:testing/'+obs+'/x86_64/qore-pdfium/'+filename],stdout=f,check=True)
  hashes[filename]=hashlib.sha256((rpms/filename).read_bytes()).hexdigest()
 (dest/'rpm-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
 results={}
 for phase in ['runtime','sdk']:
  phaseout=dest/phase;phaseout.mkdir();fixture=phaseout/'fixture';fixture.mkdir()
  for name in qual.MODULE_FIXTURES['pdf']:
   p=fixture/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','-C',str(root.parent/'module-pdf'),'show',source_commit+':'+name]));p.chmod(0o755 if name.endswith('compiler') else 0o644)
  image=old[target]['installed'][phase+'_image']
  bootstrap=('zypper --non-interactive install --no-recommends python3 util-linux' if family=='suse' else 'dnf -y --setopt=install_weak_deps=False install python3 util-linux')+'; exec python3 -B -W error /inside.py '+phase+' '+family
  cmd=['docker','run','--rm','--init','-e','LC_ALL=C.UTF-8','-v',str(repo)+':/packaging:ro','-v',str(rpms)+':/rpms:ro','-v',str(phaseout)+':/results','-v',str(fixture)+':/fixture','-v',str(script)+':/inside.py:ro','-v',str(out/'signing-key.asc')+':/signing-key.asc:ro','-w','/fixture',image,'bash','-ec',bootstrap]
  (phaseout/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
  with (phaseout/'driver.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
  results[phase]=r.returncode;print(target,phase,r.returncode,flush=True)
  if r.returncode:break
 (dest/'summary.json').write_text(json.dumps(results,indent=2)+'\n');return target,results
with ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(run,old))
(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n');assert all(r=={'runtime':0,'sdk':0} for r in results.values()),results
