from pathlib import Path
import os,json,subprocess,sys,importlib.util
sys.path.insert(0,'/packaging/tools');s=importlib.util.spec_from_file_location('qualify','/packaging/tools/qualify-installed.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
phase,target=sys.argv[1:];dest=Path('/results');directory=Path('/fixture');rows=[]
# The signed OBS dependency is installed over the already-qualified canonical module image.
rpms=sorted(str(p) for p in Path('/rpms').glob('*.rpm') if phase=='sdk' or p.name.startswith('libpdfium-qore148-0-'))
commands=[('signature',['rpmkeys','--checksig',*rpms]),('install',['rpm','-Uvh','--replacepkgs',*rpms])]
deps=q.module_dependencies('pdf','runtime',target)+q.module_dependencies('pdf','sdk',target) if phase=='sdk' else q.module_dependencies('pdf','runtime',target)
commands.append(('fixture-dependencies',(['zypper','--non-interactive','install','--no-recommends'] if target=='suse' else ['dnf','-y','--setopt=install_weak_deps=False','install'])+deps))
for name,cmd in commands:
 with (dest/(name+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit_code':p.returncode});(dest/'status.json').write_text(json.dumps(rows,indent=2)+'\n');p.check_returncode()
if phase=='runtime':
 for name in ['qore-devel','gcc','gcc-c++','libpdfium-qore-devel']:
  assert subprocess.run(['rpm','-q',name],stdout=subprocess.DEVNULL).returncode==1,name
with (dest/'packages.log').open('w') as log:subprocess.run(['rpm','-qa','--qf','%{NAME} %{EVR}.%{ARCH}\n'],stdout=log,check=True)
files=subprocess.check_output(['rpm','-ql','qore-pdf-module'],text=True);api=subprocess.check_output(['qore','--latest-module-api'],text=True).strip();binary=q.installed_module_file('pdf',files,'/pdf-api-'+api+'.qmod')
for name,cmd in q.module_commands('pdf',phase,directory,binary,installed_files=files):
 env=['setpriv','--reuid=1019','--regid=100','--clear-groups','env','-u','QORE_MODULE_DIR','-u','QORE_MODULE_DIR_ONLY','-u','QORE_INCLUDE_DIR','-u','LD_LIBRARY_PATH','-u','LD_PRELOAD','HOME=/fixture','AUTOPKGTEST_TMP=/fixture']
 with (dest/(name+'.log')).open('w') as log:p=subprocess.run(env+cmd,cwd=directory,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':env+cmd,'exit_code':p.returncode});(dest/'status.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True);p.check_returncode()
