/** @mainpage TableMapper Module

    @tableofcontents

    @section tablemapperintro TableMapper Module Introduction

    Classes provided by this module:
    - @ref TableMapper::AbstractSqlStatementOutboundMapper "AbstractSqlStatementOutboundMapper": the base class for outbound mappers based on a database source
    - @ref TableMapper::InboundTableMapper "InboundTableMapper": extends the @ref Mapper::Mapper class; assumes an SQL table target
    - @ref TableMapper::InboundIdentityTableMapper "InboundIdentityTableMapper": extends the @ref TableMapper::InboundTableMapper "InboundTableMapper" class for the case when the source and target tables have the exact same structure
    - @ref TableMapper::InboundTableMapperIterator "InboundTableMapperIterator": provides a specialization of the @ref Mapper::AbstractMapperIterator class; assumes an SQL table target; automatically inserts mapped data into the target table based on the mapper provided
    - @ref TableMapper::SqlStatementOutboundMapper "SqlStatementOutboundMapper": provides a SQL statement source based mapper
    - @ref TableMapper::SqlStatementMapperIterator "SqlStatementMapperIterator": provides a helper SQL statement source based iterator with mapping capability

    @section inboundtablemapper_sequences Inserting Sequence Values with the InboundTableMapper Class

    @ref TableMapper::InboundTableMapper "InboundTableMapper" objects can be used to insert sequence values in the
    target table, and the values inserted are returned in the output value of @ref TableMapper::InboundTableMapper::insertRow
    "InboundTableMapper::insertRow()" and also present in the argument to any @ref TableMapper::InboundTableMapper::setRowCode "rowcode" call when using the @ref tablemapper_bulk_insert_api "bulk insert API" on supported databases (databases supporting the \c returning clause in insert statements).

    The mapper field options are:
    - \c sequence: inserts the value of the given sequence into the target column and increments the sequence
    - \c sequence_currval: inserts the current value the given sequence into the target column; does not increment the sequence

    @note "autoincrement" columns cannot be used if the inserted value should be returned from an insert operation;
    an explicit sequence needs to be used so that the inserted value can be returned and used for further processing.

    @see See the following section for an example and @ref tablemapperkeys for more information

    @section tablemapperexamples TableMapper Examples

    The following is an example map for an @ref TableMapper::InboundTableMapper "InboundTableMapper" hash with comments:
    @code{.py}
const DataMap = (
    # output column: "rec_id" populated from the given sequence
    "rec_id": ("sequence": "seq_rec_id"),
    # output column: "id" mapper from the "Id" element of any "^attributes^" hash in the input record
    "id": "^attributes^.Id",
    # output column: "name": maps from an input field with the same name (no translations are made)
    "name": True,
    # output column: "explicit_count": maps from the input "Count" field
    "explicit_count": "Count",
    # output column: "implicit_count": runs the given code on the input record and retuns the result, the code returns the number of "Products" sub-records
    "implicit_count": int sub (any ignored, hash rec) { return rec.Products.size(); },
    # output column: "order_date": converts the "OrderDate" string input field to a date in the specified format
    "order_date": ("name": "OrderDate", "date_format": "DD.MM.YYYY HH:mm:SS.us"),
    # output column: order_type: given as a constant value
    "order_type": ("constant": "NEW"),
);
    @endcode

    If this map is applied in the following way:
    @code{.py}
Table table(ds, "order_table");
InboundTableMapper map1(table, DataMap);
{
    on_success map1.commit();
    on_error map1.rollback();
    # apply the map and insert the mapped data for each input record
    map map1.insertRow($1), input;
}
printf("%d record%s inserted\n", map.getCount(), map.getCount() == 1 ? "" : "s");
    @endcode

    This will insert all the mapped input data into data into the \c ORDER_TABLE
    table and then print out the number of rows inserted.

    The following is an example for TableMapper::SqlStatementOutboundMapper. It selects data
    from the \c ORDER_DATE table and it transforms rows according to the mappings supplied in
    the constructor.

    @code{.py}
# SqlUtil Table object
Table table(ds, "order_table");
# mapping definition
const DataMap = (
    "id": True,
    "foo": "name",
    "bar": ("code": string sub (any ignored, hash rec) { return format_date("YYYYMMDD", rec."order_table"); }),
);
# SqlUtil select hash
hash sh = (
    "columns": ("id", "name", "order_date"),
    "where": ("id": op_gt(1000)),
);

SqlStatementOutboundMapper m(table, sh, DataMap);
on_exit m.commit();

while (*hash h = m.getData()) {
    do_something_with_data(h);
}
    @endcode

    @section tablemapper_bulk_insert_api InboundTableMapper Bulk Insert API

    @subsection tablemapper_bulk_insert_api_intro InboundTableMapper Bulk Insert API Introduction

    The bulk insert API allows for multiple rows to be mapped and inserted in a single server round trip for high-performance applications.
    This requires bulk DML support in the underlying DBI driver and also in @ref sqlutilintro "SqlUtil" (to determine if bulk DML
    support is available, call @ref SqlUtil::AbstractTable::hasArrayBind on the @ref SqlUtil::AbstractTable object).

    The bulk insert API consists of the following methods:
    - @ref TableMapper::InboundTableMapper::queueData
    - @ref TableMapper::InboundTableMapper::flush
    - @ref TableMapper::InboundTableMapper::discard
    - @ref TableMapper::InboundTableMapper::setRowCode

    The behavior of the bulk insert API can be modified or tuned with the following options:
    - \c "insert_block": the number of rows inserted in a single block (default: 1000)

    @note The bulk insert API is only used when \c "unstable_input" is @ref False "False" and bulk DML is supported in the @ref SqlUtil::AbstractTable object

    @subsection tablemapper_bulk_insert_api_usage InboundTableMapper Bulk Insert API Usage

    To queue data for bulk insert, call @ref TableMapper::InboundTableMapper::queueData instead of
    @ref TableMapper::InboundTableMapper::insertRow.
    To perform per-row actions, the @ref TableMapper::InboundTableMapper::setRowCode method should be called with a closure that accepts a hash
    representing a single row; whenever data is flushed to the database, this closure will be called with the row actually inserted
    (including sequence values used, etc).

    Before committing the transaction, ensure that @ref TableMapper::InboundTableMapper::flush is called for each @ref TableMapper::InboundTableMapper
    object participating in the transaction.  This ensures that all data has been flushed to the database before committing the transaction.

    If there are any errors, call @ref TableMapper::InboundTableMapper::discard before rolling the transaction back.

    @note If an error occurs flushing data, the count is reset by calling @ref Mapper::Mapper::resetCount "Mapper::resetCount()"

    @subsection tablemapper_bulk_insert_api_examples InboundTableMapper Bulk Insert API Examples

    Consider the following example:
    @code{.py}
# table1 and table2 must use the same @ref Qore::SQL::Datasource "Datasource" or @ref Qore::SQL::DatasourcePool "DatasourcePool" to participate in the same transaction
TableMapper::InboundTableMapper map1(table1, maph1);
TableMapper::InboundTableMapper map2(table2, maph2);

# the transaction only needs to be committed once
on_success table1.commit();
on_error table1.rollback();

# ensure that data for each mapper is inserted and flushed before committing the transaction
{
    on_success map1.flush();
    on_error map1.discard();

    map map1.queueData($1), data1.iterator();
}
{
    on_success map2.flush();
    on_error map2.discard();

    map map2.queueData($1), data2.iterator();
}
    @endcode

    @section tablemapperkeys TableMapper Specification Format

    The mapper hash is made up of target (ie output) column names as the key values assigned to field specifications as specified in @ref mapperkeys, plus the following hash options:
    - \c "sequence": a name of a sequence to use to populate the column; the output buffers for this option are bound as type @ref number_type "number", so the output type depends on the database driver's number option setting (for example, with \c "optimal-numbers", the values here are generally returned as strings; cannot be used with the upsert @ref TableMapper::InboundTableMapper "InboundTableMapper" option)
    - \c "sequence_currval": a name of a sequence to use to return the current value of the sequence; this is useful when assigning the same sequence value to multiple columns; the output buffers for this option are bound as type @ref number_type "number", so the output type depends on the database driver's number option setting (for example, with \c "optimal-numbers", the values here are generally returned as strings; cannot be used with the upsert @ref TableMapper::InboundTableMapper "InboundTableMapper" option)

    In both cases, the actual value inserted in the table is available in the following APIs:
      - @ref TableMapper::InboundTableMapper::insertRow
      - @ref TableMapper::InboundTableMapper::queueData
      - @ref TableMapper::InboundTableMapper::flush

    Additionally, the value is provided to any row code set with @ref TableMapper::InboundTableMapper::setRowCode; see @ref tablemapper_bulk_insert_api for more information.

    @section tablemapperrelnotes Release Notes

    @subsection tablemapperv1_3 TableMapper v1.3
    - updated the module to use the @ref Qore::SQL::AbstractSQLStatement "AbstractSQLStatement" class instead of the @ref Qore::SQL::SQLStatement "SQLStatement"
    - deprecated @ref TableMapper::AbstractSqlStatementOutboundMapper::getRowIterator "AbstractSqlStatementOutboundMapper::getRowIterator()" for @ref TableMapper::AbstractSqlStatementOutboundMapper::getStatement "AbstractSqlStatementOutboundMapper::getStatement()"

    @subsection tablemapperv1_2_2 TableMapper v1.2.2
    - updated to use the new SQL statement DBI method for efficient execution of queries only for describing
      result sets with outbound mappers to solve performance problems related to mappers that
      have statements with large data sets (<a href="https://github.com/qoretechnologies/qore/issues/2773">issue 2773</a>)
    - fixed @ref TableMapper::RawSqlStatementOutboundMapper "RawSqlStatementOutboundMapper" to be usable without subclassing
      (<a href="https://github.com/qoretechnologies/qore/issues/2775">issue 2775</a>)

    @subsection tablemapperv1_2_1 TableMapper v1.2.1
    - fixed issues where where description fields of input and output records for automatically-generated options did not reflect column comments and could not be overridden with user input (<a href="https://github.com/qoretechnologies/qore/issues/2520">issue 2520</a>)

    @subsection tablemapperv1_2 TableMapper v1.2
    - added support for upserts in @ref TableMapper::InboundTableMapper (<a href="https://github.com/qoretechnologies/qore/issues/1067">issue 1067</a>)
    - added @ref TableMapper::InboundTableMapper::queueData "queueData(list, __7_ hash)"
    - fixed a bug with the @ref TableMapper::SqlStatementOutboundMapper::iterator method; corrected the iterator object return value which was causing \c AbstractMapperIterator::mapBulk() to fail (<a href="https://github.com/qoretechnologies/qore/issues/979">issue 979</a>)
    - fixed a bug with @ref TableMapper::SqlStatementOutboundMapper; it would throw an error if the required \c "table" or \c "sh" options were used and only worked with subclasses that declared these options (<a href="https://github.com/qoretechnologies/qore/issues/981">issue 981</a>)
    - updated for complex types

    @subsection tablemapperv1_1_4 TableMapper v1.1.4
    - fixed a bug in flush messages in the @ref TableMapper::InboundTableMapper "InboundTableMapper" class (<a href="https://github.com/qoretechnologies/qore/issues/1849">issue 1849</a>)

    @subsection tablemapperv1_1_3 TableMapper v1.1.3
    - fixed bugs handling mapper fields with no input records in list mode (<a href="https://github.com/qoretechnologies/qore/issues/1736">issue 1736</a>)

    @subsection tablemapperv1_1_2 TableMapper v1.1.2
    - performance enhancements for @ref TableMapper::InboundTableMapper::queueData "InboundTableMapper::queueData()" when called with a hash of lists (<a href="https://github.com/qoretechnologies/qore/issues/1626">issue 1626</a>)

    @subsection tablemapperv1_1_1 TableMapper v1.1.1
    - fixed runtime option propagation to @ref TableMapper::SqlStatementMapperIterator "SqlStatementMapperIterator" from @ref TableMapper::AbstractSqlStatementOutboundMapper::iterator "AbstractSqlStatementOutboundMapper::iterator()" (<a href="https://github.com/qoretechnologies/qore/issues/1418">issue 1418</a>)
    - fixed @ref TableMapper::SqlStatementMapperIterator::getCount "SqlStatementMapperIterator::getCount()" (<a href="https://github.com/qoretechnologies/qore/issues/1417">issue 1417</a>)
    - added the following methods:
      - @ref TableMapper::AbstractSqlStatementOutboundMapper::getRowIterator "AbstractSqlStatementOutboundMapper::getRowIterator()"
      - @ref TableMapper::InboundTableMapper::iterator "InboundTableMapper::iterator()"
      - @ref TableMapper::InboundTableMapperIterator::getRuntime "InboundTableMapperIterator::getRuntime()"
      - @ref TableMapper::InboundTableMapperIterator::replaceRuntime "InboundTableMapperIterator::replaceRuntime()"
      - @ref TableMapper::InboundTableMapperIterator::setRuntime "InboundTableMapperIterator::setRuntime()"
      - @ref TableMapper::SqlStatementMapperIterator::getRuntime "SqlStatementMapperIterator::getRuntime()"
      - @ref TableMapper::SqlStatementMapperIterator::replaceRuntime "SqlStatementMapperIterator::replaceRuntime()"
      - @ref TableMapper::SqlStatementMapperIterator::setRuntime "SqlStatementMapperIterator::setRuntime()"

    @subsection tablemapperv1_1 TableMapper v1.1
    - added table name and datasource description to error messages
    - added the getDatasource() method to classes
    - implemented more efficient support for inserts from a sequence for databases supporting the \c "returning" clause in insert statements; now such inserts are made in a single round trip instead of n + 1 where n is the number of sequences in the insert
    - implemented an optimized insert approach assuming stable input data
    - implemented the following new options for TableMapper::InboundTableMapper:
      - \c "unstable_input": to accommodate unstable input data and disable the insert optimization (default: False)
      - \c "insert_block": for DB drivers supporting bulk DML (for use with the TableMapper::InboundTableMapper::queueData(), TableMapper::InboundTableMapper::flush(), and TableMapper::InboundTableMapper::discard() methods), the number of rows inserted at once (default: 1000, only used when \c "unstable_input" is @ref False "False") and bulk inserts are supported in the table object
    - added method for bulk / batch inserts for db drivers supporting bulk DML (ex: Oracle)
    - updated to Mapper changes: use table description to define output record for the Mapper module
    - added the @ref TableMapper::AbstractSqlStatementOutboundMapper "AbstractSqlStatementOutboundMapper" class
    - added the @ref TableMapper::InboundIdentityTableMapper "InboundIdentityTableMapper" class
    - added the @ref TableMapper::RawSqlStatementOutboundMapper "RawSqlStatementOutboundMapper" class
    - added the @ref TableMapper::SqlStatementMapperIterator "SqlStatementMapperIterator" class
    - added the @ref TableMapper::SqlStatementOutboundMapper "SqlStatementOutboundMapper" class

    @subsection tablemapperv1_0 TableMapper v1.0
    - Initial release.
*/
//! the TableMapper namespace contains all the definitions in the TableMapper module
namespace TableMapper {
        //! provides an inbound data mapper to a Table target
    class InboundTableMapper : public Mapper::Mapper {
    public:
                    //! option keys for this object
        const int OptionKeys = ...;
                    //! User options
        const int UserOptions = ...;
                    //! default option values
        const hash OptionDefaults = ...;
    protected:
                    //! the target table object
        SqlUtil::AbstractTable table;
        
                    //! the target Database object in case sequence value need to be acquired
        SqlUtil::AbstractDatabase db;
        
                    //! if the AbstractTable object supports the "returning" clause
        bool has_returning;
        
                    //! "returning" arguments for sequences
        list<auto> ret_args;
        
                    //! extra arguments for sequence output binds
        list<auto> out_args;
        
                    //! sequence bind arguments for prepared statement reuse (sequence names for nextval(%v))
        list<auto> seq_bind_args;
        
                    //! "unstable input" option for non-optimized inserts/upserts (~33% performance reduction in insert/upsert speed)
        bool unstable_input;
        
                    //! statement for inserts/upserts
        Qore::SQL::AbstractSQLStatement stmt;
        
                    //! bulk DML block size (also valid for upserts despite the name)
        int insert_block;
        
                    //! buffer for bulk DML
        hash hbuf;
        
        __7_ int hbuf_size;
        
                    //! per-row @ref closure or @ref call_reference for batch inserts/upserts
        __7_ code<nothing(hash<auto>)> rowcode;
        
                    //! upsert flag
        bool upsert;
        
                    //! upsert strategy option
        __7_ int upsert_strategy;
        
                    //! closure used for upserting
        __7_ code<int(hash<auto>)> upsert_code;
        
    public:
                //! builds the object based on a hash providing field mappings, data constraints, and optionally custom mapping logic
                /** The target table is also scanned using @ref sqlutilintro "SqlUtil" and column definitions are used to update the target record specification, also if there are any columns with NOT NULL constraints and no default value, mapping, or constant value, then a MAP-ERROR exception is thrown
        
                    @par Example:
                    @code{.py}
        const DbMapper = {
            "id": {"sequence": "seq_inventory_example"},
            "store_code": "StoreCode",
            "product_code": "ProductCode",
            "product_desc": "ProductDescription",
            "ordered": "Ordered",
            "available": "Available",
            "in_transit": "InTransit",
            "status": {"constant": "01"},
            "total": int sub (any x, hash rec) { return rec.Available.toInt() + rec.Ordered.toInt() + rec.InTransit.toInt(); },
        };
        
        InboundTableMapper mapper(table, DbMapper);
                    @endcode
        
                    @param target the target table object
                    @param mapv a hash providing field mappings; each hash key is the name in lower case of the output column in the target table; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref tablemapperkeys for detailed documentation for this option
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options plus the following options specific to this object:
                    - \c "unstable_input": set this option to @ref True "True" (default @ref False "False") if the input passed to the mapper is unstable, meaning that different hash keys or a different hash key order can be passed as input data in each call to insertRow(); if this option is set, then insert speed will be reduced by about 33%; when this option is not set, an optimized insert/upsert approach is used which allows for better performance
                    - \c "insert_block": for DB drivers supporting bulk DML (for use with the queueData(), flush(), and discard() methods), the number of rows inserted/upserted at once (default: 1000, only used when \c "unstable_input" is @ref False "False") and bulk inserts are supported in the table object; see @ref tablemapper_bulk_insert_api for more information; note that this is also applied when upserting despite the name
                    - \c "rowcode": a per-row @ref closure or @ref call_reference for batch inserts/upserts; this must take a single hash argument and will be called for every row after a bulk insert/upsert; the hash argument representing the row inserted/upserted will also contain any output values for inserts if applicable (such as sequence values inserted from \c "sequence" field options for the given column)
                    - \c "upsert": if @ref True "True" then data will be upserted instead of inserted (default is to insert)
                    - \c "upsert_strategy": see \c upsert_options for possible values for the upsert strategy; if this option is present, then \c "upsert" is also assumed to be @ref True "True"; if not present but \c "upsert" is @ref True "True", then \c SqlUtil::AbstractTable::UpsertAuto is assumed
        
                    @throw MAP-ERROR the map hash has a logical error (ex: \c "trunc" key given without \c "maxlen", invalid map key); insert-only options used with the \c "upsert" option
                    @throw TABLE-ERROR the table includes a column using an unknown native data type
        
                    @see setRowCode()
                */
        void constructor(SqlUtil::Table target, hash<auto> mapv, __7_ hash<auto> opts);
        
                //! builds the object based on a hash providing field mappings, data constraints, and optionally custom mapping logic
                /** The target table is also scanned using @ref sqlutilintro "SqlUtil" and column definitions are used to update the target record specification, also if there are any columns with NOT NULL constraints and no default value, mapping, or constant value, then a MAP-ERROR exception is thrown
        
                    @par Example:
                    @code{.py}
        const DbMapper = {
            "id": {"sequence": "seq_inventory_example"},
            "store_code": "StoreCode",
            "product_code": "ProductCode",
            "product_desc": "ProductDescription",
            "ordered": "Ordered",
            "available": "Available",
            "in_transit": "InTransit",
            "status": {"constant": "01"},
            "total": int sub (any x, hash rec) { return rec.Available.toInt() + rec.Ordered.toInt() + rec.InTransit.toInt(); },
        };
        
        InboundTableMapper mapper(table, DbMapper);
                    @endcode
        
                    @param target the target table object
                    @param mapv a hash providing field mappings; each hash key is the name of the output field; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref tablemapperkeys for detailed documentation for this option
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options plus the following options specific to this object:
                    - \c "unstable_input": set this option to @ref True "True" (default @ref False "False") if the input passed to the mapper is unstable, meaning that different hash keys or a different hash key order can be passed as input data in each call to insertRow(); if this option is set, then insert speed will be reduced by about 33%; when this option is not set, an optimized insert/upsert approach is used which allows for better performance
                    - \c "insert_block": for DB drivers supporting bulk DML (for use with the queueData(), flush(), and discard() methods), the number of rows inserted/upserted at once (default: 1000, only used when \c "unstable_input" is @ref False "False") and bulk inserts are supported in the table object; see @ref tablemapper_bulk_insert_api for more information; note that this is also applied when upserting despite the name
                    - \c "rowcode": a per-row @ref closure or @ref call_reference for batch inserts/upserts; this must take a single hash argument and will be called for every row after a bulk insert/upsert; the hash argument representing the row inserted/upserted will also contain any output values for inserts if applicable (such as sequence values inserted from \c "sequence" field options for the given column)
                    - \c "upsert": if @ref True "True" then data will be upserted instead of inserted (default is to insert)
                    - \c "upsert_strategy": see \c upsert_options for possible values for the upsert strategy; if this option is present, then \c "upsert" is also assumed to be @ref True "True"; if not present but \c "upsert" is @ref True "True", then \c SqlUtil::AbstractTable::UpsertAuto is assumed
        
                    @throw MAP-ERROR the map hash has a logical error (ex: \c "trunc" key given without \c "maxlen", invalid map key); insert-only options used with the \c "upsert" option
                    @throw TABLE-ERROR the table includes a column using an unknown native data type
        
                    @see setRowCode()
                */
        void constructor(SqlUtil::AbstractTable target, hash<auto> mapv, __7_ hash<auto> opts);
        
                //! throws an exception if there is data pending in the block cache
                /** @throw BLOCK-ERROR there is unflushed data in the block cache; make sure to call flush() or discard() before destroying the object
                */
        void destructor();
        
                //! returns a description of the output record based on the @ref SqlUtil::AbstractTable "AbstractTable" target
        static __7_ hash<string, AbstractDataField> getOutputRecord(string mapper_name, AbstractTable table, __7_ hash<auto> opts, __7_ hash<SqlUtilDataTypeOptionInfo> field_opts, __7_ hash<auto> mapv);
        
    protected:
                //! common constructor initialization
        void init(hash<auto> mapv, __7_ hash<auto> opts);
        
    public:
    protected:
                //! performs type handling
        auto mapFieldType(string key, hash<auto> mapping, AbstractDataProviderType type, auto value, hash<auto> rec);
        
    public:
    protected:
                //! perform per-field pre-processing on the passed map in the constructor
                /** @param k the field name
                    @param fh a reference to the field's value in the map
                */
        void checkMapField(string k, reference<auto> fh);
        
    public:
                //! returns a list of valid field keys for this class (can be overridden in subclasses)
                /** @return a list of valid field keys for this class (can be overridden in subclasses)
                */
        hash<string, bool> validKeys();
        
                //! returns a list of valid constructor options for this class (can be overridden in subclasses)
                /** @return a list of valid constructor options for this class (can be overridden in subclasses)
                */
        hash<auto> optionKeys();
        
                //! returns mapper options useful for users
        hash<string, hash<MapperOptionInfo>> getUserOptions();
        
                //! inserts or upserts a row into the target table based on a mapped input record; does not commit the transaction
                /** @param rec the input record
        
                    @return a hash of the row values inserted/upserted (row name: value); note that any sequence values inserted are also returned here
        
                    @note on mappers with "insert_block > 1" (i.e. also the underlying DB must allow for bulk operations), it is not allowed to use both single-record insertions (like insertRow()) and bulk operations (queueData()) in one transaction. Mixing insertRow() with queueData() leads to mismatch of Oracle DB types raising corresponding exceptions depending on particular record types (e.g. "ORA-01722: invalid number").
        
                    @throw MISSING-INPUT a field marked mandatory is missing
                    @throw STRING-TOO-LONG a field value exceeds the maximum value and the 'trunc' key is not set
                    @throw INVALID-NUMBER the field is marked as numeric but the input value contains non-numeric data
                */
        hash<auto> insertRow(hash<auto> rec);
        
                //! sets a @ref closure "closure" or @ref call_reference "call reference" that will be called when data has been sent to the database and all output data is available; must accept a hash argument that represents the data written to the database including any output arguments. This code will be reset, once the transaction is commited.
                /** @par Example:
                    @code{.py}
        code rowcode = sub (hash row) {
            # process row data
        };
        table_mapper.setRowCode(rowcode);
                    @endcode
        
                    @param rowc a @ref closure "closure" or @ref call_reference "call reference" that will be called when data has been sent to the database and all output data is available; must accept a hash argument that represents the data written to the database including any output arguments
        
                    @note the per-row @ref closure "closure" or @ref call_reference "call reference" can also be set by using the \c "rowcode" option in the constructor()
                */
        void setRowCode(__7_ code<nothing(hash<auto>)> rowc);
        
                //! inserts/upserts a row (or a set of rows, in case a hash of lists is passed) into the block buffer based on a mapped input record; the block buffer is flushed to the DB if the buffer size reaches the limit defined by the \c "insert_block" option; does not commit the transaction
                /** @par Example:
                    @code{.py}
        # Example 1:
        {
            on_success table_mapper.flush();
            on_error table_mapper.discard();
        
            while (*hash<auto> h = stmt.fetchColumns(1000)) {
                table_mapper.queueData(h);
            }
        }
        
        # Example 2:
        {
            const Map1 = (
                "num": ("a"),
                "str": ("b"),
            );
        
            Table table(someDataSource, "some_table");
            InboundTableMapper table_mapper(table, DataMap. ("insert_block" : 3));
        
            on_error table_mapper.discard();
        
            list<hash<auto>> data = (("a": 1, "b": "bar"), ("a": 2, "b": "foo"));
        
            list<hash<auto>> mapped_data = (map table_mapper.queueData($1), data.iterator()) ?? ();
            # mapped_data = () - no insertion done yet since to insert_block=3
        
            list<hash<auto>> flushed_data = table_mapper.flush() ?? ();
        
            mapped_data += flushed_data;
            # mapped_data = ("num" : (1,2), "str" : ("bar","foo"));
            # the table is updated too
        }
                    @endcode
        
                    Data is only inserted/upserted if the block buffer size reaches the limit defined by the \c "insert_block"
                    option, in which case this method returns all the data inserted/upserted.  In case the mapped data is only
                    inserted into the cache, no value is returned.
        
                    @param rec the input record or record set in case a hash of lists is passed
                    @param crec an optional simple hash of data to be added to each input row before mapping
        
                    @return if batch data was inserted then a hash (columns) of lists (row data) of all data inserted and
                    potentially returned (in case of sequences) from the database server is returned; if constant mappings are
                    used with batch data, then they are returned as single values assigned to the hash keys; always returns a
                    batch (hash of lists)
        
                    @note
                    - make sure to call flush() before committing the transaction or discard() before rolling back the
                      transaction or destroying the object when using this method
                    - flush() or discard() needs to be executed for each mapper used in the block when using multiple mappers
                      whereas the DB transaction needs to be committed or rolled back once per datasource
                    - this method and batched inserts/upserts in general cannot be used when the \c "unstable_input" option is
                      given in the constructor
                    - if the \c "insert_block" option is set to 1, then this method simply calls insertRow(); however please
                      note that in this case the return value is a hash of single value lists corresponding to a batch data
                      insert
                    - if an error occurs flushing data, the count is reset by calling
                      @ref Mapper::Mapper::resetCount "Mapper::resetCount()"
                    - using a hash of lists in \a rec; note that this provides very high performance with SQL drivers that
                      support Bulk DML
                    - in case a hash of empty lists is passed, Qore::NOTHING is returned
                    - 'crec' does not affect the number of output lines; in particular, if 'rec' is a batch with \c N rows of
                      a column \c C and 'crec = ("C" : "mystring")' then the output will be as if there was 'N' rows with
                      \c C = "mystring" on the input.
                    - on mappers with "insert_block > 1" (i.e. also the underlying DB must allow for bulk operations), it is
                      not allowed to use both single-record insertions (like insertRow()) and bulk operations (queueData()) in
                      one transaction. Mixing insertRow() with queueData() leads to mismatch of Oracle DB types raising
                      corresponding exceptions depending on particular record types (e.g. "ORA-01722: invalid number").
        
                    @see
                    - flush()
                    - discard()
        
                    @throw MAPPER-BATCH-ERROR this exception is thrown if this method is called when the \c "unstable_input"
                    option was given in the constructor
                    @throw MISSING-INPUT a field marked mandatory is missing
                    @throw STRING-TOO-LONG a field value exceeds the maximum value and the 'trunc' key is not set
                    @throw INVALID-NUMBER the field is marked as numeric but the input value contains non-numeric data
                */
        __7_ hash<auto> queueData(hash<auto> rec, __7_ hash<auto> crec);
        
                //! inserts/upserts a set of rows (from an iterator that returns hashes as values where each hash value represents an input record) into the block buffer based on a mapped input record; the block buffer is flushed to the DB if the buffer size reaches the limit defined by the \c "insert_block" option; does not commit the transaction
                /** @par Example:
                    @code{.py}
        on_success table_mapper.commit();
        on_error table_mapper.rollback();
        {
            on_success table_mapper.flush();
            on_error table_mapper.discard();
        
            table_mapper.queueData(data.iterator());
        }
                    @endcode
        
                    Data is only inserted/upserted if the block buffer size reaches the limit defined by the \c "insert_block" option, in which case this method returns all the data inserted/upserted.  In case the mapped data is only inserted into the cache, no value is returned.
        
                    @param iter iterator over the record set (list of hashes)
                    @param crec an optional simple hash of data to be added to each input row before mapping
        
                    @return if batch data was inserted then a hash (columns) of lists (row data) of all data inserted and potentially returned (in case of sequences) from the database server is returned; if constant mappings are used with batch data, then they are returned as single values assigned to the hash keys
        
                    @note
                    - make sure to call flush() before committing the transaction or discard() before rolling back the transaction or destroying the object when using this method
                    - flush() or discard() needs to be executed for each mapper used in the block when using multiple mappers whereas the DB transaction needs to be committed or rolled back once per datasource
                    - this method and batched inserts/upserts in general cannot be used when the \c "unstable_input" option is given in the constructor
                    - if the \c "insert_block" option is set to 1, then this method simply calls insertRow() to insert the data, nevertheless it still returns bulk output
                    - if an error occurs flushing data, the count is reset by calling @ref Mapper::Mapper::resetCount "Mapper::resetCount()"
                    - on mappers with "insert_block > 1" (i.e. also the underlying DB must allow for bulk operations), it is not allowed to use both single-record insertions (like insertRow()) and bulk operations (queueData()) in one transaction. Mixing insertRow() with queueData() leads to mismatch of Oracle DB types raising corresponding exceptions depending on particular record types (e.g. "ORA-01722: invalid number").
        
                    @see
                    - flush()
                    - discard()
        
                    @throw MAPPER-BATCH-ERROR this exception is thrown if this method is called when the \c "unstable_input" option was given in the constructor
                    @throw MISSING-INPUT a field marked mandatory is missing
                    @throw STRING-TOO-LONG a field value exceeds the maximum value and the 'trunc' key is not set
                    @throw INVALID-NUMBER the field is marked as numeric but the input value contains non-numeric data
                */
        __7_ hash<auto> queueData(Qore::AbstractIterator iter, __7_ hash<auto> crec);
        
                //! inserts/upserts a set of rows (list of hashes representing input records) into the block buffer based on a mapped input record; the block buffer is flushed to the DB if the buffer size reaches the limit defined by the \c "insert_block" option; does not commit the transaction
                /** @par Example:
                    @code{.py}
        on_success table_mapper.commit();
        on_error table_mapper.rollback();
        {
            on_success table_mapper.flush();
            on_error table_mapper.discard();
        
            table_mapper.queueData(data.iterator());
        }
                    @endcode
        
                    Data is only inserted/upserted if the block buffer size reaches the limit defined by the \c "insert_block" option, in which case this method returns all the data inserted/upserted.  In case the mapped data is only inserted into the cache, no value is returned.
        
                    @param l a list of hashes representing the input records
                    @param crec an optional simple hash of data to be added to each row
        
                    @return if batch data was inserted/upserted then a hash (columns) of lists (row data) of all data inserted/upserted and potentially returned (in case of sequences) from the database server is returned
        
                    @note
                    - make sure to call flush() before committing the transaction or discard() before rolling back the transaction or destroying the object when using this method
                    - flush() or discard() needs to be executed for each mapper used in the block when using multiple mappers whereas the DB transaction needs to be committed or rolled back once per datasource
                    - this method and batched inserts/upserts in general cannot be used when the \c "unstable_input" option is given in the constructor
                    - if the \c "insert_block" option is set to 1, then this method simply calls insertRow()
                    - if an error occurs flushing data, the count is reset by calling @ref Mapper::Mapper::resetCount "Mapper::resetCount()"
        
                    @see
                    - flush()
                    - discard()
        
                    @throw MAPPER-BATCH-ERROR this exception is thrown if this method is called when the \c "unstable_input" option was given in the constructor
                    @throw MISSING-INPUT a field marked mandatory is missing
                    @throw STRING-TOO-LONG a field value exceeds the maximum value and the 'trunc' key is not set
                    @throw INVALID-NUMBER the field is marked as numeric but the input value contains non-numeric data
                */
        __7_ hash<auto> queueData(list<auto> l, __7_ hash<auto> crec);
        
    protected:
                //! inserts a row into the block buffer based on a mapped input record; does not commit the transaction
                /** Data is only inserted/upserted if the block buffer size reaches the limit defined by the \c "insert_block" option, in which case this method returns all the data inserted/upserted.  In case the mapped data is only inserted/upserted into the cache, no value is returned.
        
                    @param rec a hash representing a single input record
        
                    @return if batch data was inserted (flushed) then a hash (columns) of lists (row data) of all data
                    inserted and potentially returned (in case of sequences) from the database server is returned; if constant
                    mappings are used with batch data, then they are returned as single values assigned to the hash keys; if
                    nothing was flushed to the database in the call, Qore::NOTHING is returned
        
                    @note this function does not process hashes of lists (bulk format), it expects always single input record on the input; it returns a batch, though.
        
                    @throw MISSING-INPUT a field marked mandatory is missing
                    @throw STRING-TOO-LONG a field value exceeds the maximum value and the 'trunc' key is not set
                    @throw INVALID-NUMBER the field is marked as numeric but the input value contains non-numeric data
                */
        __7_ hash<auto> queueDataIntern(hash<auto> rec);
        
    public:
    protected:
                /**
                 * transforms single record to a batch - i.e. all non-constant elements
                 * are transformed to lists (with single elements)
                 */
        hash record2Batch(hash h);
        
    public:
    protected:
                /** returns true when the mapper is all "constant", i.e. if it always
                  * provide the same output regardless on the input
                  */
        bool isMapperConstant();
        
    public:
                /**
                 * adds a batch (hash of lists) to another batch (in-place)
                 * @param hb reference to a batch that will be enriched
                 * @param batch the batch to be added to 'hb'
                 */
        static nothing addBatchToBatch(reference<hash<auto>> hb, hash<auto> batch);
        
                //! adds a batch (hash of lists) to another batch (in-place)
                /** @deprecated use addBatchToBatch(reference<hash>, hash) instead
                 */
        static deprecated nothing addBatchToBatch(reference<hash> hb, reference x1, hash batch, __7_ reference x2);
        
                //! flushes any remaining batched data to the database; this method should always be called before committing the transaction or destroying the object
                /** @par Example:
                    @code{.py}
        on_success table_mapper.commit();
        on_error table_mapper.rollback();
        {
            on_success table_mapper.flush();
            on_error table_mapper.discard();
        
            map table_mapper.queueData($1), data.iterator();
        }
                    @endcode
        
                    @return if batch data was inserted then a hash (columns) of lists (row data) of all data inserted and potentially returned (in case of sequences) from the database server is returned; if constant mappings are used with batch data, then they are returned as single values assigned to the hash keys
        
                    @note
                    - flush() or discard() needs to be executed for each mapper used in the block when using multiple mappers whereas the DB transaction needs to be committed or rolled back once per datasource
                    - also clears any row @ref closure or @ref call_reference set for batch operations
                    - if an error occurs flushing data, the count is reset by calling @ref Mapper::Mapper::resetCount "Mapper::resetCount()"
        
                    @see
                    - queueData()
                    - discard()
                */
        __7_ hash<auto> flush();
        
                //! discards any buffered batched data; this method should be called after using the batch APIs (queueData()) and an error occurs
                /** @par Example:
                    @code{.py}
        on_success table_mapper.commit();
        on_error table_mapper.rollback();
        {
            on_success table_mapper.flush();
            on_error table_mapper.discard();
        
            map table_mapper.queueData($1), data.iterator();
        }
                    @endcode
        
                    @note
                    - flush() or discard() needs to be executed for each mapper used in the block when using multiple mappers whereas the DB transaction needs to be committed or rolled back once per datasource
                    - also clears any row @ref closure or @ref call_reference set for batch operations
                    - if an error occurs flushing data, the count is reset by calling @ref Mapper::Mapper::resetCount "Mapper::resetCount()"
        
                    @see
                    - queueData()
                    - flush()
                */
        void discard();
        
    protected:
                /**
                 * flushes queued data to the database
                 * @param force_flush to flush even if there is not enough data to fill a block,
                 *                    e.g. on explicit flush() call
                 * @return Qore::NOTHING when nothing was flushed, otherwise returns
                 *         a batch (hash of lists) with the data that were flushed into the DB,
                 *         updated by the 'ret_args' from the DB.
                 */
        __7_ hash<auto> flushIntern(bool force_flush);
        
    public:
                //! returns a list argument for the SqlUtil "returning" option, if applicable
        __7_ list<hash<auto>> getReturning();
        
                //! ignore logging from Mapper since we may have to log sequence values; output logged manually in insertRow()
        void logOutput(hash<auto> h);
        
    protected:
        hash<auto> asOutputRecord(auto h);
        
    public:
                //! returns an iterator for the current object
                /**
                    @param i input iterator; @ref Qore::AbstractIterator::getValue "AbstractIterator::getValue()" must return a hash
        
                    @since %TableMapper 1.1.1
                 */
        TableMapper::InboundTableMapperIterator iterator(Qore::AbstractIterator i);
        
                //! Plain alias to insertRow(). Obsolete. Do not use.
        deprecated hash<auto> insertRowNoCommit(hash<auto> rec);
        
                //! flushes any queued data and commits the transaction
        nothing commit();
        
                //! discards any queued data and rolls back the transaction
        nothing rollback();
        
                //! returns the table name
        string getTableName();
        
                //! returns the underlying SqlUtil::AbstractTable object
        SqlUtil::AbstractTable getTable();
        
                //! returns the @ref Qore::SQL::AbstractDatasource "AbstractDatasource" object associated with this object
        Qore::SQL::AbstractDatasource getDatasource();
        
    protected:
                //! prepends the datasource description to the error string and calls Mapper::error()
        void error(string fmt);
        
    public:
    protected:
                //! prepends the datasource description to the error description and calls Mapper::error2()
        void error2(string ex, string fmt);
        
    public:
    };
    
        //! maps from source to target tables with exactly the same structure
    class InboundIdentityTableMapper : public TableMapper::InboundTableMapper {
    public:
                //! builds the object based on an optional hash providing field mappings, data constraints, and optionally custom mapping logic
                /** The target table is also scanned using @ref sqlutilintro "SqlUtil" and column definitions are used to update the target record specification, also if there are any columns with NOT NULL constraints and no default value, mapping, or constant value, then a MAP-ERROR exception is thrown
        
                    @par Example:
                    @code{.py}
        const DbMapper = (
            "id": ("sequence": "seq_inventory_example"),
            );
        
        InboundIdentityTableMapper mapper(table, DbMapper);
                    @endcode
        
                    @param target the target table object
                    @param mapv a optional hash providing overrides for the default 1:1 input to output field mappings; each hash key is the name in lower case of the output column in the target table; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref mapperkeys for detailed documentation for this option
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options plus the following options specific to this object:
                    - \c "unstable_input": set this option to @ref True "True" (default @ref False "False") if the input passed to the mapper is unstable, meaning that different hash keys or a different hash key order can be passed as input data in each call to insertRow(); if this option is set, then insert speed will be reduced by about 33%; when this option is not set, an optimized insert approach is used which allows for better performance
                    - \c "insert_block": for DB drivers supporting bulk DML (for use with the queueData(), flush(), and discard() methods), the number of rows inserted at once (default: 1000, only used when \c "unstable_input" is @ref False "False") and bulk inserts are supported in the table object; see @ref tablemapper_bulk_insert_api for more information
        
                    @throw MAP-ERROR the map hash has a logical error (ex: \c "trunc" key given without \c "maxlen", invalid map key)
                */
        void constructor(SqlUtil::Table target, __7_ hash<auto> opts, hash<auto> mapv);
        
                //! builds the object based on an optional hash providing field mappings, data constraints, and optionally custom mapping logic
                /** The target table is also scanned using @ref sqlutilintro "SqlUtil" and column definitions are used to update the target record specification, also if there are any columns with NOT NULL constraints and no default value, mapping, or constant value, then a MAP-ERROR exception is thrown
        
                    @par Example:
                    @code{.py}
        const DbMapper = (
            "id": ("sequence": "seq_inventory_example"),
            );
        
        InboundIdentityTableMapper mapper(table, DbMapper);
                    @endcode
        
                    @param target the target table object
                    @param mapv a hash providing field mappings; each hash key is the name of the output field; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref mapperkeys for detailed documentation for this option
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options plus the following options specific to this object:
                    - \c "unstable_input": set this option to @ref True "True" (default @ref False "False") if the input passed to the mapper is unstable, meaning that different hash keys or a different hash key order can be passed as input data in each call to insertRow(); if this option is set, then insert speed will be reduced by about 33%; when this option is not set, an optimized insert approach is used which allows for better performance
                    - \c "insert_block": for DB drivers supporting bulk DML (for use with the queueData(), flush(), and discard() methods), the number of rows inserted at once (default: 1000, only used when \c "unstable_input" is @ref False "False") and bulk inserts are supported in the table object; see @ref tablemapper_bulk_insert_api for more information
        
                    @throw MAP-ERROR the map hash has a logical error (ex: \c "trunc" key given without \c "maxlen", invalid map key)
                    @throw TABLE-ERROR the table includes a column using an unknown native data type
                */
        void constructor(SqlUtil::AbstractTable target, __7_ hash<auto> opts, hash<auto> mapv);
        
    protected:
                //! common constructor initialization
        void init(hash<auto> mapv, __7_ hash<auto> opts);
        
    public:
    protected:
                //! returns a description of the input record based on the @ref SqlUtil::AbstractTable "AbstractTable" source
        hash<string, AbstractDataField> getInputRecord(SqlUtil::AbstractTable table, __7_ hash<auto> opts);
        
    public:
    };
    
        //! provides a hash iterator based on a @ref TableMapper::InboundTableMapper "InboundTableMapper" object and an iterator input source; for each iteration the iterted row is inserted into the @ref SqlUtil::Table "Table" target
    class InboundTableMapperIterator : public Mapper::AbstractMapperIterator<hash<auto>> {
    public:
    protected:
                    //! data mapper
        TableMapper::InboundTableMapper mapc;
        
                    //! row commit limit (<= 0 for no commits)
        int commit_limit;
        
                    //! row count for commit
        int cnt;
        
                    //! a copy of the last hash value mapped
        hash<auto> val;
        
    public:
                //! creates the iterator from the mapper passed
                /**
                    @param i input iterator; @ref Qore::AbstractIterator::getValue "AbstractIterator::getValue()" must return a hash
                    @param mapper the mapper object that the iterator will be based on
        
                    @since %TableMapper 1.1.1
                 */
        void constructor(Qore::AbstractIterator i, InboundTableMapper mapper);
        
                //! creates the iterator from the arguments passed
                /** The target table is also scanned using @ref sqlutilintro "SqlUtil" and column definitions are used to update the target record specification, also if there are any columns with NOT NULL constraints and no default value, mapping, or constant value, then a MAP-ERROR exception is thrown
        
                    @par Example:
                    @code{.py}
        const DbMapper = (
            "id": ("sequence": "seq_inventory_example"),
            "store_code": "StoreCode",
            "product_code": "ProductCode",
            "product_desc": "ProductDescription",
            "ordered": "Ordered",
            "available": "Available",
            "in_transit": "InTransit",
            "status": ("constant": "01"),
            "total": int sub (any x, hash rec) { return rec.Available.toInt() + rec.Ordered.toInt() + rec.InTransit.toInt(); },
            );
        
        InboundTableMapperIterator i(input, table, DbMapper);
                    @endcode
        
                    @param i input iterator; @ref Qore::AbstractIterator::getValue "AbstractIterator::getValue()" must return a hash
                    @param target the target table object
                    @param mapv a hash providing field mappings; each hash key is the name of the output column in lower case in the target table; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref mapperkeys for detailed documentation for this option
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options; note that options related to bulk DML are ignored by this object since it works on one row at a time
                    @param commit_limit row count before a commit is made; if <= 0 then no commits are made by this object, otherwise a commit is made for each \a commit_limit rows processed by this object, commits are made in calls to @ref next
        
                    @note by default \a commit_limit is 0 meaning that this object will make no commits; in this case the transaction will
                    have to be commited explicitly externally
                */
        void constructor(Qore::AbstractIterator i, SqlUtil::Table target, hash<auto> mapv, __7_ hash<auto> opts, int commit_limit);
        
                //! creates the iterator from the arguments passed
                /** The target table is also scanned using @ref sqlutilintro "SqlUtil" and column definitions are used to update the target record specification, also if there are any columns with NOT NULL constraints and no default value, mapping, or constant value, then a MAP-ERROR exception is thrown
        
                    @par Example:
                    @code{.py}
        const DbMapper = (
            "id": ("sequence": "seq_inventory_example"),
            "store_code": "StoreCode",
            "product_code": "ProductCode",
            "product_desc": "ProductDescription",
            "ordered": "Ordered",
            "available": "Available",
            "in_transit": "InTransit",
            "status": ("constant": "01"),
            "total": int sub (any x, hash rec) { return rec.Available.toInt() + rec.Ordered.toInt() + rec.InTransit.toInt(); },
            );
        
        InboundTableMapperIterator i(input, table, DbMapper);
                    @endcode
        
                    @param i input iterator; @ref Qore::AbstractIterator::getValue "AbstractIterator::getValue()" must return a hash
                    @param target the target table object
                    @param mapv a hash providing field mappings; each hash key is the name of the output column in lower case in the target table; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref mapperkeys for detailed documentation for this option
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options; note that options related to bulk DML are ignored by this object since it works on one row at a time
                    @param commit_limit row count before a commit is made; if <= 0 then no commits are made by this object, otherwise a commit is made for each \a commit_limit rows processed by this object, commits are made in calls to @ref next
        
                    @note by default \a commit_limit is 0 meaning that this object will make no commits; in this case the transaction will
                    have to be commited explicitly externally
                */
        void constructor(Qore::AbstractIterator i, SqlUtil::AbstractTable target, hash<auto> mapv, __7_ hash<auto> opts, int commit_limit);
        
                //! creates the iterator from the arguments passed
                /** The target table is also scanned using @ref sqlutilintro "SqlUtil" and column definitions are used to update the target record specification, also if there are any columns with NOT NULL constraints and no default value, mapping, or constant value, then a MAP-ERROR exception is thrown
        
                    @par Example:
                    @code{.py}
        const DbMapper = (
            "id": ("sequence": "seq_inventory_example"),
            "store_code": "StoreCode",
            "product_code": "ProductCode",
            "product_desc": "ProductDescription",
            "ordered": "Ordered",
            "available": "Available",
            "in_transit": "InTransit",
            "total": int sub (any x, hash rec) { return rec.Available.toInt() + rec.Ordered.toInt() + rec.InTransit.toInt(); },
            );
        
        InboundTableMapper mapper(table, DbMapper);
        InboundTableMapperIterator i(input, mapper);
                    @endcode
        
                    @param i input iterator; @ref Qore::AbstractIterator::getValue "AbstractIterator::getValue()" must return a hash
                    @param mapv the mapper to transform the data
                    @param commit_limit row count before a commit is made; if <= 0 then no commits are made by this object, otherwise a commit is made for each \a commit_limit rows processed by this object, commits are made in calls to @ref next
                */
        void constructor(Qore::AbstractIterator i, TableMapper::InboundTableMapper mapv, int commit_limit);
        
                //! returns the current row transformed with the mapper
        hash<auto> getValue();
        
                //! Moves the current position of the input iterator to the next element; returns @ref False "False" if there are no more elements otherwise inserts the row in the target table and returns @ref True "True"
                /** if \a commit_limit is > 0 then @ref TableMapper::InboundTableMapper::commit is called for every \a commit_limit rows according to the internal row count
        
                    @return @ref False "False" if there are no more elements, in this case if there is an uncommitted transaction according to the internal row count, then @ref TableMapper::InboundTableMapper::commit is called as well
                */
        bool next();
        
                //! returns the \a commit_limit value set in the constructor()
        int commitLimit();
        
                //! commits the transaction
        nothing commit();
        
                //! rolls back the transaction
        nothing rollback();
        
                //! returns the table name
        string getTableName();
        
                //! returns the internal record count
                /** @see resetCount()
                */
        int getCount();
        
                //! resets the internal record count
                /** @see getCount()
                */
        void resetCount();
        
                //! returns the @ref Qore::SQL::AbstractDatasource "AbstractDatasource" object associated with this object
        Qore::SQL::AbstractDatasource getDatasource();
        
                //! set the @ref mapper_runtime_handling "runtime option" with \a "key" to value \a "value"
                /**
                     @param key a string with valid runtime key
                     @param value anything passed to the current runtime \c key
        
                    @see
                    - @ref mapper_runtime_handling
                    - replaceRuntime()
                    - getRuntime()
        
                    @since %TableMapper 1.1.1
                 */
        void setRuntime(string key, auto value);
        
                //! adds @ref mapper_runtime_handling "runtime options" to the current runtime option hash
                /**
                    @param runtime a hash of runtime options to add to the current @ref mapper_runtime_handling "runtime option hash"
        
                    @see
                    - @ref mapper_runtime_handling
                    - replaceRuntime()
                    - getRuntime()
        
                    @since %TableMapper 1.1.1
                 */
        void setRuntime(hash<auto> runtime);
        
                //! replaces @ref mapper_runtime_handling "runtime options"
                /**
                    @param runtime a hash of runtime options to use to replace the current @ref mapper_runtime_handling "runtime option hash"
        
                    @see
                    - @ref mapper_runtime_handling
                    - getRuntime()
                    - setRuntime()
        
                    @since %TableMapper 1.1.1
                 */
        void replaceRuntime(__7_ hash<auto> runtime);
        
                //! get current @ref mapper_runtime_handling "runtime option" value for a key
                /**
                    @param key the runtime option key
                    @returns a runtime value if the key exists in the current @ref mapper_runtime_handling "runtime option hash" and is set
        
                    @see
                    - @ref mapper_runtime_handling
                    - replaceRuntime()
                    - setRuntime()
        
                    @since %TableMapper 1.1.1
                 */
        auto getRuntime(string key);
        
    };
    
        //! provides a hash iterator based on a mapper object and an SQLStatement or SqlUtil select hash
        /** provides support for bulk DML:
            - @ref hasBulk returns @ref True
            - @ref mapBulk fetches the number of rows requested and then maps to output values
        */
    class SqlStatementMapperIterator : public Mapper::AbstractMapperIterator<hash<auto>> {
    public:
    protected:
                    //! data mapper
        Mapper::Mapper m_mapper;
        
    public:
                //! creates the iterator from the Mapper passed
                /** @param mapper the mapper to iterate
                 */
        void constructor(TableMapper::AbstractSqlStatementOutboundMapper mapper);
        
                //! creates the iterator from the arguments passed
                /** @param table SqlUtil::AbstractTable as a base for select hash \c sh
                    @param sh a SqlUtil select hash (columns/joins/wheres...)
                    @param mapv a hash providing field mappings; each hash key is the name of the output field; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref mapperkeys for detailed documentation for this option
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options
        
                    @throw MAP-ERROR the map hash has a logical error (ex: \c "trunc" key given without \c "maxlen", invalid map key)
                 */
        void constructor(SqlUtil::AbstractTable table, hash<auto> sh, hash<auto> mapv, __7_ hash<auto> opts);
        
                //! creates the iterator from the arguments passed
                /** @param table SqlUtil::Table as a base for select hash \c sh
                    @param sh a SqlUtil select hash (columns/joins/wheres...)
                    @param mapv a hash providing field mappings; each hash key is the name of the output field; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref mapperkeys for detailed documentation for this option
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options
        
                    @throw MAP-ERROR the map hash has a logical error (ex: \c "trunc" key given without \c "maxlen", invalid map key)
                 */
        void constructor(SqlUtil::Table table, hash<auto> sh, hash<auto> mapv, __7_ hash<auto> opts);
        
                //! creates the iterator from the arguments passed
                /** @param stmt already constructed SQLStatement object
                    @param mapv the mapper to transform the data
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options
                */
        void constructor(Qore::SQL::AbstractSQLStatement stmt, hash<auto> mapv, __7_ hash<auto> opts);
        
    protected:
        void setup(hash<auto> mapv, __7_ hash<auto> opts);
        
    public:
                //! returns the current row transformed with the mapper
        hash<auto> getValue();
        
                //! returns the internal record count
                /** @see resetCount()
                */
        int getCount();
        
                //! resets the internal record count
                /** @see getCount()
                */
        void resetCount();
        
                //! returns @ref True because this class supports bulk mode
        bool hasBulk();
        
                //! performs bulk mapping by selecting the requested number of rows in a single select
                /** @param size the number of rows to return
        
                    @return a list of mapped hashes with a maximum number of rows corresponding to the \a size argument; in case there is less input data than requested, the list returned could have fewer rows than requested; in case there is no more data, the return value is an empty list
                 */
        list<auto> mapBulk(int size);
        
                //! set the @ref mapper_runtime_handling "runtime option" with \a "key" to value \a "value"
                /**
                     @param key a string with valid runtime key
                     @param value anything passed to the current runtime \c key
        
                    @see
                    - @ref mapper_runtime_handling
                    - replaceRuntime()
                    - getRuntime()
        
                    @since %TableMapper 1.1.1
                 */
        void setRuntime(string key, auto value);
        
                //! adds @ref mapper_runtime_handling "runtime options" to the current runtime option hash
                /**
                    @param runtime a hash of runtime options to add to the current @ref mapper_runtime_handling "runtime option hash"
        
                    @see
                    - @ref mapper_runtime_handling
                    - replaceRuntime()
                    - getRuntime()
        
                    @since %TableMapper 1.1.1
                 */
        void setRuntime(hash<auto> runtime);
        
                //! replaces @ref mapper_runtime_handling "runtime options"
                /**
                    @param runtime a hash of runtime options to use to replace the current @ref mapper_runtime_handling "runtime option hash"
        
                    @see
                    - @ref mapper_runtime_handling
                    - getRuntime()
                    - setRuntime()
        
                    @since %TableMapper 1.1
                 */
        void replaceRuntime(__7_ hash<auto> runtime);
        
                //! get current @ref mapper_runtime_handling "runtime option" value for a key
                /**
                    @param key the runtime option key
                    @returns a runtime value if the key exists in the current @ref mapper_runtime_handling "runtime option hash" and is set
        
                    @see
                    - @ref mapper_runtime_handling
                    - replaceRuntime()
                    - setRuntime()
        
                    @since %TableMapper 1.1.1
                 */
        auto getRuntime(string key);
        
    };
    
        //! provides an abstract base for all SQL based outbound mappers
    class AbstractSqlStatementOutboundMapper : public Mapper::Mapper {
    public:
                    //! option keys for this class
        const int OptionKeys = ...;
                    //! default option values
        const hash OptionDefaults = ...;
    protected:
        AbstractSQLStatement m_stmt;
        
        int select_block;
        
        __7_ hash<auto> m_orig_opts;
        
    public:
                //! builds the object based on an optional hash providing field mappings, data constraints, and optionally custom mapping logic
                /** The source statement is also scanned using @ref Qore::SQL::AbstractSQLStatement and column definitions are used to update the source record specification.
        
                    @param mapv a optional hash providing overrides for the default 1:1 input to output field mappings; each hash key is the name in lower case of the output column in the target table; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref mapperkeys for detailed documentation for this option
                    @param opts a hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options plus the following options specific to this object:
                    - \c "select_block": for size of the batch returned from TableMapper::SqlStatementOutboundMapper::getData() or SqlStatementOutboundMapper::getDataRows()
                    - \c "sh": an SqlUtil select hash
                    - \c "table": (required) the AbstractTable object for the source of the data
        
                    @throw MAP-ERROR invalid select_block size; must be >= 1 if present
                */
        void constructor(hash<auto> mapv, __7_ hash<auto> opts);
        
                //! returns a list of valid constructor options for this class (can be overridden in subclasses)
                /** @return a list of valid constructor options for this class (can be overridden in subclasses)
                */
        hash<auto> optionKeys();
        
                //! returns mapper options useful for users
        hash<string, hash<MapperOptionInfo>> getUserOptions();
        
                //! commits the transaction and frees the Qore::SQL::AbstractDatasource transaction thread resource
        void commit();
        
                //! rolls the transaction back and frees the Qore::SQL::AbstractDatasource transaction thread resource
        void rollback();
        
                //! returns the @ref Qore::SQL::AbstractDatasource "AbstractDatasource" object associated with this object
        abstract Qore::SQL::AbstractDatasource getDatasource();
        
    protected:
                //! re-implement to initialize options
        abstract void initOptions(reference<hash> opts);
        
    public:
    protected:
                //! re-implement to initialize Qore::SQL::AbstractSQLStatement on demand
        abstract void initStatement();
        
    public:
                //! returns a row iterator for the underlying SQL statement for this object
                /** @since TableMapper 1.1.1
        
                    @deprecated use getStatement() instead; this method is a legacy alias
                 */
        Qore::SQL::AbstractSQLStatement getRowIterator();
        
                //! returns a row iterator for the underlying SQL statement for this object
                /** @since TableMapper 1.3
                 */
        Qore::SQL::AbstractSQLStatement getStatement();
        
                //! Returns an SqlStatementMapperIterator based on the current object
                /** @return an SqlStatementMapperIterator based on the current object
        
                    Data are retrieved with standard Qore::AbstractIterator::getValue() or similar.
                    Value is a hash with column names as keys.
                 */
        SqlStatementMapperIterator iterator();
        
                //! Retrieve mapped data as a hash of lists.
                /** @return *hash with data or Qore::NOTHING in case there are no more data available.
        
                    The size of the batch is driven by the \c select_block option passed in the constructor.
        
                    The hash is in Qore::SQL::AbstractDatasource::select() form - meaning it is a hash
                    with column names as keys. Values are lists of column values.
                    This data structure is used for Qore::context statement or BulksSqlUtil
                    operations.
                 */
        __7_ hash<string, auto> getData();
        
                //! Retrieve mapped data as a list of hashes.
                /** @return *list with data or Qore::NOTHING in case there are no more data available.
        
                    Size of the batch is driven by the \c select_block option passed in the constructor.
        
                    List is in Qore::SQL::AbstractDatasource::selectRows() form - meaning it is a list
                    with hashes, where every hash has column names as keys with single values as
                    hash values.
                 */
        __7_ list<auto> getDataRows();
        
    protected:
                //! returns an input record description from an SQLStatement
        static __7_ hash<string, AbstractDataField> getInputRecordFromStmt(AbstractSQLStatement stmt, __7_ hash<auto> input);
        
    public:
    };
    
        //! provides an outbound data mapper to a Table with SqlUtil select hash as a asource
    class SqlStatementOutboundMapper : public AbstractSqlStatementOutboundMapper {
    public:
    protected:
        SqlUtil::AbstractTable m_table;
        
        __7_ hash m_sh;
        
                    //! option keys for this class
        const int OptionKeys = ...;
                    //! user options for this class
        const hash UserOptions = ...;
    public:
                //! builds the object based on an optional hash providing field mappings, data constraints, and optionally custom mapping logic
                /** The source statement is also scanned using @ref Qore::SQL::SQLStatement and column definitions are used to update the source record specification.
        
                    @param source the source table object. A \c sh select hash is applied to this table
                    @param sh a SqlUtil select hash
                    @param mapv a optional hash providing overrides for the default 1:1 input to output field mappings; each hash key is the name in lower case of the output column in the target table; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref mapperkeys for detailed documentation for this option
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options plus the following options specific to this object:
                    - \c "select_block": for size of the batch returned from TableMapper::AbstarctSqlStatementOutboundMapper::getData() or AbstarctSqlStatementOutboundMapper::getDataRows()
        
                    @throw MAP-ERROR
                */
        void constructor(SqlUtil::Table source, __7_ hash<auto> sh, hash<auto> mapv, __7_ hash<auto> opts);
        
                //! builds the object based on an optional hash providing field mappings, data constraints, and optionally custom mapping logic
                /** The source statement is also scanned using @ref Qore::SQL::AbstractSQLStatement and column definitions are used to update the source record specification.
        
                    @param source the source table object. A \c sh select hash is applied to this table
                    @param sh a SqlUtil select hash
                    @param mapv a optional hash providing overrides for the default 1:1 input to output field mappings; each hash key is the name in lower case of the output column in the target table; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref mapperkeys for detailed documentation for this option
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options plus the following options specific to this object:
                    - \c "select_block": for size of the batch returned from TableMapper::AbstractSqlStatementOutboundMapper::getData() or AbstarctSqlStatementOutboundMapper::getDataRows()
        
                    @throw MAP-ERROR
                */
        void constructor(SqlUtil::AbstractTable source, __7_ hash<auto> sh, hash<auto> mapv, __7_ hash<auto> opts);
        
                //! returns the table name
                /** @return string with main table name
                 */
        string getTableName();
        
                //! returns the underlying SqlUtil::AbstractTable object
                /** @return SqlUtil::AbstractTable provided in constructor
                 */
        SqlUtil::AbstractTable getTable();
        
                //! returns the @ref Qore::SQL::AbstractDatasource "AbstractDatasource" object associated with this object
        Qore::SQL::AbstractDatasource getDatasource();
        
                //! initializes the internal statement object
        void initStatement();
        
                //! returns a list of valid constructor options for this class (can be overridden in subclasses)
                /** @return a list of valid constructor options for this class (can be overridden in subclasses)
                */
        hash<auto> optionKeys();
        
                //! returns mapper options useful for users
        hash<string, hash<MapperOptionInfo>> getUserOptions();
        
    protected:
                //! initializes options
        void initOptions(reference<hash<auto>> opts);
        
    public:
                //! returns a description of the input record based on @ref Qore::SQL::AbstractSQLStatement::describe
        static __7_ hash<string, AbstractDataField> getStaticInputRecord(AbstractTable table, __7_ hash<auto> select_hash, __7_ reference<string> sql, __7_ hash<auto> input);
        
    };
    
        //! provides an outbound data mapper to a raw SQL statement
    class RawSqlStatementOutboundMapper : public AbstractSqlStatementOutboundMapper {
    public:
    protected:
        AbstractDatasource m_ds;
        
        string m_sql;
        
        __7_ list m_sqlargs;
        
                    //! option keys for this class
        const int OptionKeys = ...;
                    //! user options for this class
        const hash UserOptions = ...;
    public:
                //! builds the obejct based on real SQL statement
                /** The source statement is also scanned using @ref Qore::SQL::AbstractSQLStatement and column definitions are used to update the source record specification.
        
                    @param ds Qore::SQL::AbstractDatasource instance. Note that this object uses a transaction lock for the current thread.
                    @param sql a string with SQL statement. Variables binding is provided by \c sqlargs
                    @param sqlargs optional list with sql argumets/variables
                    @param mapv a optional hash providing overrides for the default 1:1 input to output field mappings; each hash key is the name in lower case of the output column in the target table; each value is either @ref True "True" (meaning no translations are done; the data is copied 1:1) or a hash describing the mapping; see @ref mapperkeys for detailed documentation for this option
                    @param opts an optional hash of options for the mapper; see @ref mapperoptions for a description of valid mapper options plus the following options specific to this object:
                    - \c "select_block": for size of the batch returned from TableMapper::AbstarctSqlStatementOutboundMapper::getData() or AbstarctSqlStatementOutboundMapper::getDataRows()
        
                @par Example
                @code{.py}{.py}
        %requires TableMapper
        
        Datasource ds("oracle:omq/omq@xbox");
        on_success ds.commit();
        on_error ds.rollback();
        
        hash MAPV = ("id" : "workflowid", "name" : True);
        RawSqlStatementOutboundMapper m(ds, "select * from workflows where workflowid = %v or workflowid = %v", (1,2), MAPV);
        printf("%Y\n", m.getDataRows());
        #list: (2 elements)
        #  [0]=hash: (2 members)
        #    id : 1
        #    name : "ASYNC-TEST"
        #  [1]=hash: (2 members)
        #    id : 2
        #    name : "BUG-476-TEST"
                @endcode
                 */
        void constructor(Qore::SQL::AbstractDatasource ds, string sql, __7_ softlist<auto> sqlargs, hash<auto> mapv, __7_ hash<auto> opts);
        
                //! returns the @ref Qore::SQL::AbstractDatasource "AbstractDatasource" object associated with this object
        Qore::SQL::AbstractDatasource getDatasource();
        
                //! returns a list of valid constructor options for this class (can be overridden in subclasses)
                /** @return a list of valid constructor options for this class (can be overridden in subclasses)
                */
        hash<auto> optionKeys();
        
                //! returns mapper options useful for users
        hash<string, hash<MapperOptionInfo>> getUserOptions();
        
    protected:
                //! initializes the internal statement object
        void initStatement();
        
    public:
    protected:
                //! initializes options
        void initOptions(reference<hash<auto>> opts);
        
    public:
                //! returns a description of the input record based on @ref Qore::SQL::AbstractSQLStatement::describe
        static __7_ hash<string, AbstractDataField> getStaticInputRecord(Qore::SQL::AbstractDatasource ds, string sql, __7_ softlist<auto> args, __7_ hash<auto> input);
        
    };
    
}

