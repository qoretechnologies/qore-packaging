# Copyright 2026 Qore Technologies, s.r.o.; SPDX-License-Identifier: MIT
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,xml.etree.ElementTree as E,json,re,hashlib,sys
root=Path.cwd();out=root/'results/pdf-native-rev2-verified-20261008';out.mkdir(exist_ok=True);expected='1e58422b96543fc4a9e4d1a7f3aca3bb'
targets=[tuple(t.split('/')) for t in sys.argv[1:]] if len(sys.argv)>1 else [('Fedora_44','x86_64'),('openSUSE_Leap_16.0','x86_64'),('AlmaLinux_10','x86_64'),('openSUSE_Leap_16.0','aarch64')]
def verify(target):
 repo,arch=target;d=out/(repo+'-'+arch);d.mkdir(exist_ok=True);base=f'/build/home:davidnichols:qore:testing/{repo}/{arch}/qore-pdf-module'
 for kind,path in [('status','/_status'),('history','/_history'),('binaries',''),('buildinfo','/_buildinfo')]:
  data=subprocess.check_output(['osc','api',base+path]);(d/(kind+'.xml')).write_bytes(data)
 status=E.parse(d/'status.xml').getroot();assert status.get('code')=='succeeded' and status.get('dirty')!='true',status.attrib
 history=list(E.parse(d/'history.xml').getroot())[-1];assert history.get('srcmd5')==expected and history.get('rev')=='2',history.attrib
 assert E.parse(d/'buildinfo.xml').getroot().findtext('srcmd5')==expected
 log=root/(f'results/pdf-native-rev2-x86-final-20261008/{repo}/build.log' if arch=='x86_64' else ('results/pdf-native-rev2-20261008/openSUSE_Leap_16.0-aarch64/build.log' if repo=='openSUSE_Leap_16.0' else f'results/pdf-native-rev2-arm-final-20261008/{repo}/build.log'))
 if repo=='AlmaLinux_10' and arch=='aarch64':log=root/'results/pdf-el-final-state-20261008/build.log'
 s=log.read_text();counts=[[int(v) for v in m] for m in re.findall(r'Ran (\d+) test cases, (\d+) succeeded \((\d+) assertions\)',s)]
 assert len(counts)==7 and sum(r[0] for r in counts)==79 and sum(r[2] for r in counts)==616 and all(r[0]==r[1] for r in counts),counts
 assert 'WARNING could not set SOURCE_DATE_EPOCH' not in s
 diags=[l for l in s.splitlines() if re.search(r'warning:|WARNING| W: | E: ',l)]
 for line in diags:
  assert ('polkit-default-privs' in line and 'scriptlet failed, exit status 2' in line or 'hidden-file-or-dir /usr/share/qore/i18n/.qore-catalog-manifests' in line or repo=='AlmaLinux_10' and 'stl_algobase.h:452:30' in line and '[-Warray-bounds=]' in line),line
 bins=[x.attrib for x in E.parse(d/'binaries.xml').getroot() if x.get('filename','').endswith('.rpm')];assert len(bins)==5,bins
 r={'repository':repo,'architecture':arch,'source_md5':expected,'history':history.attrib,'suites':7,'cases':79,'assertions':616,'timestamp_warnings':0,'retained_approved_diagnostics':diags,'rpm_outputs':bins,'log':str(log.relative_to(root)),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};(d/'verified.json').write_text(json.dumps(r,indent=2)+'\n');print(repo,arch,'verified',flush=True);return repo+'/'+arch,r
with ThreadPoolExecutor(max_workers=4) as p:r=dict(p.map(verify,targets))
p=out/'summary.json';previous=json.loads(p.read_text()) if p.exists() else {};previous.update(r);p.write_text(json.dumps(previous,indent=2)+'\n')
