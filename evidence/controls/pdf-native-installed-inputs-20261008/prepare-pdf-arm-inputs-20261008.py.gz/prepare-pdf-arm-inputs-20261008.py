# Copyright 2026 Qore Technologies, s.r.o.; SPDX-License-Identifier: MIT
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,importlib.util,json,re,subprocess,sys,urllib.request,xml.etree.ElementTree as E
root=Path.cwd();checkout=root/'work/checkouts/packaging-pdf-installed-20261008';out=root/'results/pdf-arm-inputs-20261008';out.mkdir(exist_ok=True)
sys.path.insert(0,str(checkout/'tools'));sp=importlib.util.spec_from_file_location('qualify',checkout/'tools/qualify-installed.py');q=importlib.util.module_from_spec(sp);sp.loader.exec_module(q)
commit='cc9bb928a6cbf7a475c2c61ca1d8869c92302ff5';project='home:davidnichols:qore:testing';osc=['osc','--setopt','http_retries=1','api']
def fixture(path):
 data=subprocess.check_output(['git','-C',str(root.parent/'module-pdf'),'show',commit+':'+path]);url=f'https://raw.githubusercontent.com/qoretechnologies/module-pdf/{commit}/{path}'
 with urllib.request.urlopen(url,timeout=90) as r:assert r.read()==data,url
 return {'path':path,'url':url,'sha256':hashlib.sha256(data).hexdigest()}
with ThreadPoolExecutor(max_workers=8) as pool:fixtures=list(pool.map(fixture,sorted(q.MODULE_FIXTURES['pdf'])))
(out/'fixtures.json').write_text(json.dumps(fixtures,indent=2)+'\n')
def prepare(target):
 repo={'fedora':'Fedora_44','leap':'openSUSE_Leap_16.0','el10':'AlmaLinux_10'}[target];folder=out/target;folder.mkdir(exist_ok=True)
 manifest=json.loads((root/f'qualification/core21-{target}-aarch64.json').read_text());manifest['modules']=[{'name':'pdf','commit':commit,'fixtures':fixtures}];provenance={}
 def add(package,names,expected):
  base=f'/build/{project}/{repo}/aarch64/{package}'
  data={}
  for kind,path in [('info','/_buildinfo'),('status','/_status'),('history','/_history'),('binaries','')]:
   data[kind]=subprocess.check_output([*osc,base+path]);(folder/(package+'-'+kind+'.xml')).write_bytes(data[kind])
  info=E.fromstring(data['info']);status=E.fromstring(data['status']);history=list(E.fromstring(data['history']))
  assert status.get('code')=='succeeded' and status.get('dirty')!='true',(package,status.attrib)
  assert info.findtext('srcmd5')==expected,(package,info.findtext('srcmd5'))
  assert history and history[-1].get('srcmd5')==expected,(package,[h.attrib for h in history][-1:])
  files=[b.get('filename') for b in E.fromstring(data['binaries'])]
  provenance[package]={'srcmd5':expected,'history':history[-1].attrib}
  for name,phase in names:
   choices=[f for f in files if re.fullmatch(re.escape(name)+r'-[0-9].*\.(aarch64|noarch)\.rpm',f)];assert len(choices)==1,(name,choices)
   filename=choices[0];url='https://api.opensuse.org/public'+base+'/'+filename
   cached=folder/filename
   if cached.exists():
    payload=cached.read_bytes()
   else:
    with urllib.request.urlopen(url,timeout=120) as r:payload=r.read()
    cached.write_bytes(payload)
   entry={'name':name,'url':url,'filename':filename,'sha256':hashlib.sha256(payload).hexdigest(),'phase':phase}
   manifest['packages']=[p for p in manifest['packages'] if p['name']!=name]+[entry]
  after=E.fromstring(subprocess.check_output([*osc,base+'/_buildinfo']));assert after.findtext('srcmd5')==expected
 core=[(p['name'],p['phase']) for p in manifest['packages'] if '/aarch64/qore/' in p['url']]
 add('qore',core,manifest['obs_srcmd5'])
 add('qore-pdf-module',[('qore-pdf-module','runtime'),('qore-pdf-module-doc','runtime')],'1e58422b96543fc4a9e4d1a7f3aca3bb')
 add('qore-pdfium',[('libpdfium-qore148-0','runtime'),('libpdfium-qore-devel','sdk')],'a815379d22cf1df53054e4fb1cd735f8')
 def verify(entry):
  p=folder/entry['filename']
  if not p.exists():
   with urllib.request.urlopen(entry['url'],timeout=120) as r:p.write_bytes(r.read())
  assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256'],entry['name']
 with ThreadPoolExecutor(max_workers=6) as pool:list(pool.map(verify,manifest['packages']))
 q.validate(manifest);(checkout/f'qualification/pdf-{target}-aarch64.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (folder/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n');(folder/'status.json').write_text(json.dumps({'packages':len(manifest['packages']),'validated':True})+'\n');print(target,len(manifest['packages']),'verified',flush=True)
with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(prepare,sys.argv[1:]))
