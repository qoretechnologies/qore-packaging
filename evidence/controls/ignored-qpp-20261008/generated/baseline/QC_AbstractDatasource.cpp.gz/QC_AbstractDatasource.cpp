/* -*- mode: c++; indent-tabs-mode: nil -*- */
/** @file QC_AbstractDatasource.qpp AbstractDatasource class (interface) definition */
/*
    Qore Programming Language

    Copyright (C) 2003 - 2026 Qore Technologies, s.r.o.

    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the "Software"),
    to deal in the Software without restriction, including without limitation
    the rights to use, copy, modify, merge, publish, distribute, sublicense,
    and/or sell copies of the Software, and to permit persons to whom the
    Software is furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.

    Note that the Qore library is released under a choice of three open-source
    licenses: MIT (as above), LGPL 2+, or GPL 2+; see README-LICENSE for more
    information.
*/

#include <qore/Qore.h>
#include <qore/QoreColumnarResult.h>

#include "qore/intern/QC_ColumnarResult.h"
#include "qore/intern/SqlMutationContext.h"

class AbstractDatasource {};

DLLLOCAL extern QoreClass* QC_ABSTRACTSQLSTATEMENT;

static QoreObject* qore_abstract_datasource_vselect_columnar(QoreObject* self, const QoreString* sql,
        const QoreListNode* arguments, ExceptionSink* xsink) {
    ReferenceHolder<QoreListNode> call_args(new QoreListNode(autoTypeInfo), xsink);
    call_args->push(new QoreStringNode(*sql), xsink);
    if (*xsink) {
        return nullptr;
    }
    call_args->push(arguments ? arguments->listRefSelf() : QoreValue(), xsink);
    if (*xsink) {
        return nullptr;
    }

    ValueHolder result(self->evalMethod("vselect", *call_args, xsink), xsink);
    if (*xsink) {
        return nullptr;
    }

    return qore_columnar_result_to_object(
        qore_columnar_result_from_value(*result, nullptr, "AbstractDatasource::vselect()", xsink), xsink);
}
/* Qore class Qore::SQL::AbstractDatasource */

qore_classid_t CID_ABSTRACTDATASOURCE;
QoreClass* QC_ABSTRACTDATASOURCE;

// bool AbstractDatasource::bulkLoadBegin(string table, list<string> columns, *hash<auto> options){}
static QoreValue AbstractDatasource_bulkLoadBegin_VsC12list_string_C11_hash_auto_(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* table = *qpp_string_helper_0;
    const QoreListNode* columns = HARD_QORE_VALUE_LIST(args, 1);
    const QoreHashNode* options = get_param_value(args, 2).get<const QoreHashNode>();
# 143 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
        xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide "
        "native bulk loading; it is implemented in Datasource and DatasourcePool for example");
    return false;
}

// nothing AbstractDatasource::bulkLoadEnd(bool success){}
static QoreValue AbstractDatasource_bulkLoadEnd_Vb(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    bool success = HARD_QORE_VALUE_BOOL(args, 0);
# 166 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide "
        "native bulk loading; it is implemented in Datasource and DatasourcePool for example");
    return QoreValue();
}

// nothing AbstractDatasource::bulkLoadRows(hash<auto> rows){}
static QoreValue AbstractDatasource_bulkLoadRows_C10hash_auto_(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreHashNode* rows = HARD_QORE_VALUE_HASH(args, 0);
# 155 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide "
        "native bulk loading; it is implemented in Datasource and DatasourcePool for example");
    return QoreValue();
}

// nothing AbstractDatasource::clearMutationObserver(){}
static QoreValue AbstractDatasource_clearMutationObserver(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 776 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide "
        "the desired functionality; it is implemented in Datasource and DatasourcePool for example");
    return QoreValue();
}

// bool AbstractDatasource::currentThreadInTransaction(){}
static QoreValue AbstractDatasource_currentThreadInTransaction(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 600 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide the desired functionality; it is implemented in Datasource and DatasourcePool for example");
   return false;
}

// int AbstractDatasource::getCapabilities(){}
static QoreValue AbstractDatasource_getCapabilities(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 684 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    return 0;
}

// string AbstractDatasource::getDriverRealName(){}
static QoreValue AbstractDatasource_getDriverRealName(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 662 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    return self->evalMethod("getDriverName", nullptr, xsink);
}

// *hash<SqlMutationInfo> AbstractDatasource::getMutationDeclaration(){}
static QoreValue AbstractDatasource_getMutationDeclaration(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 836 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    return QoreValue();
}

// auto AbstractDatasource::getOption(string option){}
static QoreValue AbstractDatasource_getOption_Vs(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 642 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    xsink->raiseException("DBI-OPTION-ERROR", "This method must be re-implemented in subclasses to provide the "
        "desired functionality; it is implemented in Datasource and DatasourcePool for example");
    return QoreValue();
}

// hash<auto> AbstractDatasource::getOptionHash(){}
static QoreValue AbstractDatasource_getOptionHash(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 630 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    return new QoreHashNode(autoTypeInfo);
}

// AbstractSQLStatement AbstractDatasource::getSQLStatement(){}
static QoreValue AbstractDatasource_getSQLStatement(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 614 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide "
        "the desired functionality; it is implemented in Datasource and DatasourcePool for example");
    return QoreValue();
}

// bool AbstractDatasource::hasMutationObserver(){}
static QoreValue AbstractDatasource_hasMutationObserver(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 788 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    return false;
}

// nothing AbstractDatasource::popMutationDeclaration(){}
static QoreValue AbstractDatasource_popMutationDeclaration(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 824 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide "
        "the desired functionality; it is implemented in Datasource and DatasourcePool for example");
    return QoreValue();
}

// nothing AbstractDatasource::pushMutationDeclaration(hash<SqlMutationInfo> info){}
static QoreValue AbstractDatasource_pushMutationDeclaration_C21hash_SqlMutationInfo_(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 809 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide "
        "the desired functionality; it is implemented in Datasource and DatasourcePool for example");
    return QoreValue();
}

// bool AbstractDatasource::reportMutationStreamBegin(int declared_bytes = 0){}
static QoreValue AbstractDatasource_reportMutationStreamBegin_Vi(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 853 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide "
        "the desired functionality; it is implemented in Datasource and DatasourcePool for example");
    return false;
}

// bool AbstractDatasource::reportMutationStreamEnd(int consumed_bytes, bool ok = True){}
static QoreValue AbstractDatasource_reportMutationStreamEnd_ViVb(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 882 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide "
        "the desired functionality; it is implemented in Datasource and DatasourcePool for example");
    return false;
}

// bool AbstractDatasource::reportMutationStreamProgress(int consumed_bytes){}
static QoreValue AbstractDatasource_reportMutationStreamProgress_Vi(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 868 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide "
        "the desired functionality; it is implemented in Datasource and DatasourcePool for example");
    return false;
}

// ColumnarResult AbstractDatasource::selectColumnar(string sql, ...){}
static QoreValue AbstractDatasource_selectColumnar_VsVV(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* sql = *qpp_string_helper_0;
# 236 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
    ReferenceHolder<QoreListNode> arguments((args->size() > 1 ? args->copyListFrom(1) : nullptr), xsink);
    if (*xsink) {
        return QoreValue();
    }
    return qore_abstract_datasource_vselect_columnar(self, sql, *arguments, xsink);
}

// nothing AbstractDatasource::setMutationObserver(code<*hash<SqlMutationDecisionInfo>(hash<SqlMutationEventInfo>)> observer, int event_mask = SQL_MUTATION_MASK_DEFAULT, auto arg){}
static QoreValue AbstractDatasource_setMutationObserver_C64code__hash_SqlMutationDecisionInfo__hash_SqlMutationEventInfo___ViVA(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 763 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
        xsink->raiseException("ABSTRACT-DATASOURCE-ERROR", "This method must be re-implemented in subclasses to provide "
        "the desired functionality; it is implemented in Datasource and DatasourcePool for example");
    return QoreValue();
}

// ColumnarResult AbstractDatasource::vselectColumnar(string sql, *softlist<auto> arguments){}
static QoreValue AbstractDatasource_vselectColumnar_VsC15_softlist_auto_(QoreObject* self, AbstractDatasource* ds, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* sql = *qpp_string_helper_0;
    const QoreListNode* arguments = get_param_value(args, 1).get<const QoreListNode>();
# 369 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/baseline/QC_AbstractDatasource.qpp"
        return qore_abstract_datasource_vselect_columnar(self, sql, arguments, xsink);
}

DLLLOCAL void preinitAbstractDatasourceClass() {
    QC_ABSTRACTDATASOURCE = new QoreBuiltinClass("AbstractDatasource", "::Qore::SQL::AbstractDatasource", QDOM_DATABASE);
    CID_ABSTRACTDATASOURCE = QC_ABSTRACTDATASOURCE->getID();
    QC_ABSTRACTDATASOURCE->setSystem();
}

DLLLOCAL QoreClass* initAbstractDatasourceClass(QoreNamespace& ns) {
    if (!QC_ABSTRACTDATASOURCE)
        preinitAbstractDatasourceClass();

    // nothing AbstractDatasource::beginTransaction();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 449);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("beginTransaction", Public, QCF_NO_FLAGS, nothingTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // bool AbstractDatasource::bulkLoadBegin(string table, list<string> columns, *hash<auto> options){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 143);
        QC_ABSTRACTDATASOURCE->addMethod("bulkLoadBegin", (q_method_t)AbstractDatasource_bulkLoadBegin_VsC12list_string_C11_hash_auto_, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 3, stringTypeInfo, QORE_PARAM_NO_ARG, "table", qore_get_complex_list_type(stringTypeInfo), QORE_PARAM_NO_ARG, "columns", autoHashOrNothingTypeInfo, QORE_PARAM_NO_ARG, "options");
    }

    // nothing AbstractDatasource::bulkLoadEnd(bool success){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 166);
        QC_ABSTRACTDATASOURCE->addMethod("bulkLoadEnd", (q_method_t)AbstractDatasource_bulkLoadEnd_Vb, Public, QCF_NO_FLAGS, QDOM_DEFAULT, nothingTypeInfo, 1, boolTypeInfo, QORE_PARAM_NO_ARG, "success");
    }

    // nothing AbstractDatasource::bulkLoadRows(hash<auto> rows){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 155);
        QC_ABSTRACTDATASOURCE->addMethod("bulkLoadRows", (q_method_t)AbstractDatasource_bulkLoadRows_C10hash_auto_, Public, QCF_NO_FLAGS, QDOM_DEFAULT, nothingTypeInfo, 1, autoHashTypeInfo, QORE_PARAM_NO_ARG, "rows");
    }

    // nothing AbstractDatasource::clearMutationObserver(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 776);
        QC_ABSTRACTDATASOURCE->addMethod("clearMutationObserver", (q_method_t)AbstractDatasource_clearMutationObserver, Public, QCF_NO_FLAGS, QDOM_DEFAULT, nothingTypeInfo);
    }

    // nothing AbstractDatasource::commit();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 75);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("commit", Public, QCF_NO_FLAGS, nothingTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // bool AbstractDatasource::currentThreadInTransaction(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 600);
        QC_ABSTRACTDATASOURCE->addMethod("currentThreadInTransaction", (q_method_t)AbstractDatasource_currentThreadInTransaction, Public, QCF_NO_FLAGS, QDOM_DEFAULT, boolTypeInfo);
    }

    // auto AbstractDatasource::exec(string sql, ...);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 97);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("exec", Public, QCF_USES_EXTRA_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); return v; }());
    }

    // auto AbstractDatasource::execRaw(string sql);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 129);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("execRaw", Public, QCF_NAMED_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); return v; }());
    }

    // int AbstractDatasource::getCapabilities(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 684);
        QC_ABSTRACTDATASOURCE->addMethod("getCapabilities", (q_method_t)AbstractDatasource_getCapabilities, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, bigIntTypeInfo);
    }

    // auto AbstractDatasource::getClientVersion();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 557);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getClientVersion", Public, QCF_NO_FLAGS, autoTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // hash<auto> AbstractDatasource::getConfigHash();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 579);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getConfigHash", Public, QCF_NO_FLAGS, autoHashTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // string AbstractDatasource::getConfigString();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 591);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getConfigString", Public, QCF_NO_FLAGS, stringTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // *string AbstractDatasource::getDBEncoding();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 491);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getDBEncoding", Public, QCF_NO_FLAGS, stringOrNothingTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // *string AbstractDatasource::getDBName();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 479);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getDBName", Public, QCF_NO_FLAGS, stringOrNothingTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // string AbstractDatasource::getDriverName();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 533);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getDriverName", Public, QCF_NO_FLAGS, stringTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // string AbstractDatasource::getDriverRealName(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 662);
        QC_ABSTRACTDATASOURCE->addMethod("getDriverRealName", (q_method_t)AbstractDatasource_getDriverRealName, Public, QCF_NO_FLAGS, QDOM_DEFAULT, stringTypeInfo);
    }

    // *string AbstractDatasource::getHostName();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 511);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getHostName", Public, QCF_NO_FLAGS, stringOrNothingTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // *hash<SqlMutationInfo> AbstractDatasource::getMutationDeclaration(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 836);
        QC_ABSTRACTDATASOURCE->addMethod("getMutationDeclaration", (q_method_t)AbstractDatasource_getMutationDeclaration, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, hashdeclSqlMutationInfo->getTypeInfo(true));
    }

    // *string AbstractDatasource::getOSEncoding();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 501);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getOSEncoding", Public, QCF_NO_FLAGS, stringOrNothingTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // auto AbstractDatasource::getOption(string option){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 642);
        QC_ABSTRACTDATASOURCE->addMethod("getOption", (q_method_t)AbstractDatasource_getOption_Vs, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, autoTypeInfo, 1, stringTypeInfo, QORE_PARAM_NO_ARG, "option");
    }

    // hash<auto> AbstractDatasource::getOptionHash(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 630);
        QC_ABSTRACTDATASOURCE->addMethod("getOptionHash", (q_method_t)AbstractDatasource_getOptionHash, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, autoHashTypeInfo);
    }

    // *string AbstractDatasource::getPassword();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 469);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getPassword", Public, QCF_NO_FLAGS, stringOrNothingTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // *int AbstractDatasource::getPort();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 521);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getPort", Public, QCF_NO_FLAGS, bigIntOrNothingTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // AbstractSQLStatement AbstractDatasource::getSQLStatement(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 614);
        QC_ABSTRACTDATASOURCE->addMethod("getSQLStatement", (q_method_t)AbstractDatasource_getSQLStatement, Public, QCF_NO_FLAGS, QDOM_DEFAULT, QC_ABSTRACTSQLSTATEMENT->getTypeInfo());
    }

    // auto AbstractDatasource::getServerVersion();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 545);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getServerVersion", Public, QCF_NO_FLAGS, autoTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // *string AbstractDatasource::getUserName();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 459);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("getUserName", Public, QCF_NO_FLAGS, stringOrNothingTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // bool AbstractDatasource::hasMutationObserver(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 788);
        QC_ABSTRACTDATASOURCE->addMethod("hasMutationObserver", (q_method_t)AbstractDatasource_hasMutationObserver, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, boolTypeInfo);
    }

    // bool AbstractDatasource::inTransaction();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 567);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("inTransaction", Public, QCF_NO_FLAGS, boolTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // nothing AbstractDatasource::popMutationDeclaration(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 824);
        QC_ABSTRACTDATASOURCE->addMethod("popMutationDeclaration", (q_method_t)AbstractDatasource_popMutationDeclaration, Public, QCF_NO_FLAGS, QDOM_DEFAULT, nothingTypeInfo);
    }

    // nothing AbstractDatasource::pushMutationDeclaration(hash<SqlMutationInfo> info){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 809);
        QC_ABSTRACTDATASOURCE->addMethod("pushMutationDeclaration", (q_method_t)AbstractDatasource_pushMutationDeclaration_C21hash_SqlMutationInfo_, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, nothingTypeInfo, 1, hashdeclSqlMutationInfo->getTypeInfo(false), QORE_PARAM_NO_ARG, "info");
    }

    // bool AbstractDatasource::reportMutationStreamBegin(int declared_bytes = 0){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 853);
        QC_ABSTRACTDATASOURCE->addMethod("reportMutationStreamBegin", (q_method_t)AbstractDatasource_reportMutationStreamBegin_Vi, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, bigIntTypeInfo, QoreSimpleValue((int64)0), "declared_bytes");
    }

    // bool AbstractDatasource::reportMutationStreamEnd(int consumed_bytes, bool ok = True){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 882);
        QC_ABSTRACTDATASOURCE->addMethod("reportMutationStreamEnd", (q_method_t)AbstractDatasource_reportMutationStreamEnd_ViVb, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 2, bigIntTypeInfo, QORE_PARAM_NO_ARG, "consumed_bytes", boolTypeInfo, QoreSimpleValue(true), "ok");
    }

    // bool AbstractDatasource::reportMutationStreamProgress(int consumed_bytes){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 868);
        QC_ABSTRACTDATASOURCE->addMethod("reportMutationStreamProgress", (q_method_t)AbstractDatasource_reportMutationStreamProgress_Vi, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, bigIntTypeInfo, QORE_PARAM_NO_ARG, "consumed_bytes");
    }

    // nothing AbstractDatasource::rollback();
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 84);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("rollback", Public, QCF_NO_FLAGS, nothingTypeInfo, [&]() { type_vec_t v; return v; }(), [&]() { arg_vec_t v; return v; }(), [&]() { name_vec_t v; return v; }());
    }

    // auto AbstractDatasource::select(string sql, ...);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 195);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("select", Public, QCF_USES_EXTRA_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); return v; }());
    }

    // ColumnarResult AbstractDatasource::selectColumnar(string sql, ...){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 236);
        QC_ABSTRACTDATASOURCE->addMethod("selectColumnar", (q_method_t)AbstractDatasource_selectColumnar_VsVV, Public, QCF_RET_VALUE_ONLY|QCF_USES_EXTRA_ARGS, QDOM_DEFAULT, QC_COLUMNARRESULT->getTypeInfo(), 1, stringTypeInfo, QORE_PARAM_NO_ARG, "sql");
    }

    // auto AbstractDatasource::selectRow(string sql, ...);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 264);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("selectRow", Public, QCF_USES_EXTRA_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); return v; }());
    }

    // auto AbstractDatasource::selectRows(string sql, ...);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 289);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("selectRows", Public, QCF_USES_EXTRA_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); return v; }());
    }

    // auto AbstractDatasource::selectRowsTyped(string sql, ...);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 309);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("selectRowsTyped", Public, QCF_USES_EXTRA_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); return v; }());
    }

    // auto AbstractDatasource::selectTyped(string sql, ...);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 215);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("selectTyped", Public, QCF_USES_EXTRA_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); return v; }());
    }

    // nothing AbstractDatasource::setMutationObserver(code<*hash<SqlMutationDecisionInfo>(hash<SqlMutationEventInfo>)> observer, int event_mask = SQL_MUTATION_MASK_DEFAULT, auto arg){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 763);
        QC_ABSTRACTDATASOURCE->addMethod("setMutationObserver", (q_method_t)AbstractDatasource_setMutationObserver_C64code__hash_SqlMutationDecisionInfo__hash_SqlMutationEventInfo___ViVA, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, nothingTypeInfo, 3, qore_get_complex_code_type(hashdeclSqlMutationDecisionInfo->getTypeInfo(true), [&]() { type_vec_t v; v.push_back(hashdeclSqlMutationEventInfo->getTypeInfo(false)); return v; }(), false), QORE_PARAM_NO_ARG, "observer", bigIntTypeInfo, QoreSimpleValue((int64)SQL_MUTATION_MASK_DEFAULT), "event_mask", autoTypeInfo, QORE_PARAM_NO_ARG, "arg");
    }

    // auto AbstractDatasource::vexec(string sql, *softlist<auto> arguments);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 112);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("vexec", Public, QCF_NAMED_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); v.push_back(softAutoListOrNothingTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); v.push_back("arguments"); return v; }());
    }

    // auto AbstractDatasource::vselect(string sql, *softlist<auto> arguments);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 336);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("vselect", Public, QCF_NAMED_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); v.push_back(softAutoListOrNothingTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); v.push_back("arguments"); return v; }());
    }

    // ColumnarResult AbstractDatasource::vselectColumnar(string sql, *softlist<auto> arguments){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 369);
        QC_ABSTRACTDATASOURCE->addMethod("vselectColumnar", (q_method_t)AbstractDatasource_vselectColumnar_VsC15_softlist_auto_, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, QC_COLUMNARRESULT->getTypeInfo(), 2, stringTypeInfo, QORE_PARAM_NO_ARG, "sql", softAutoListOrNothingTypeInfo, QORE_PARAM_NO_ARG, "arguments");
    }

    // auto AbstractDatasource::vselectRow(string sql, *softlist<auto> arguments);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 393);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("vselectRow", Public, QCF_NAMED_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); v.push_back(softAutoListOrNothingTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); v.push_back("arguments"); return v; }());
    }

    // auto AbstractDatasource::vselectRows(string sql, *softlist<auto> arguments);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 421);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("vselectRows", Public, QCF_NAMED_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); v.push_back(softAutoListOrNothingTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); v.push_back("arguments"); return v; }());
    }

    // auto AbstractDatasource::vselectRowsTyped(string sql, *softlist<auto> arguments);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 437);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("vselectRowsTyped", Public, QCF_NAMED_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); v.push_back(softAutoListOrNothingTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); v.push_back("arguments"); return v; }());
    }

    // auto AbstractDatasource::vselectTyped(string sql, *softlist<auto> arguments);
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AbstractDatasource.qpp", 352);
        QC_ABSTRACTDATASOURCE->addAbstractMethod("vselectTyped", Public, QCF_NAMED_ARGS, autoTypeInfo, [&]() { type_vec_t v; v.push_back(stringTypeInfo); v.push_back(softAutoListOrNothingTypeInfo); return v; }(), [&]() { arg_vec_t v; v.push_back(QoreValue()); v.push_back(QoreValue()); return v; }(), [&]() { name_vec_t v; v.push_back("sql"); v.push_back("arguments"); return v; }());
    }

    return QC_ABSTRACTDATASOURCE;
}
