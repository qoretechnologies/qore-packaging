
//! main Qore-language namespace
namespace Qore {
//! Methods in this pseudo-class can be executed on @ref binary "binary values"
/***/
class zzz8binaryzzz9 : public zzz8valuezzz9 {

public:
//! Returns @ref True if the binary object is empty (size = 0), @ref False if not
/** The opposite of Qore::zzz8binaryzzz9::val()

    @return @ref True if the binary object is empty (size = 0), @ref False if not

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
bool b = bin.empty();
    @endcode
*/
bool empty() const;

public:
//! Retrieves the byte position of a sequence of bytes within a binary object
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @par Example:
    @code{.py}
int i = bin.find(bin2);
if (i == -1) {
    printf("could not find %y in %y\n", bin2, bin);
}
    @endcode

    @param pattern the byte sequence to find in the binary object
    @param byte_offset the starting byte position for the search; if negative, then specifies an offset from the end of
    the current binary object

    @return the byte position of a sequence of bytes within a binary object, -1 is returned if the byte sequence is
    not found or if \a byte_offset specifies a position beyond the end of the string

    @note an empty \a pattern argument always matches

    @see
    - Qore::zzz8binaryzzz9::rfind(data, softint)

    @since %Qore 0.9.1
*/
int find(data pattern, softint byte_offset = 0) const;

public:
//! Retrieves the byte position of a sequence of bytes within a binary object searching from the end of the binary object
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @par Example:
    @code{.py}
int i = bin.rfind(bin2);
if (i == -1) {
    printf("could not find %y in %y\n", bin2, bin);
}
    @endcode

    @param pattern the byte sequence to find in the binary object
    @param byte_offset the starting byte position for the search; if negative, then specifies an offset from the end of
    the current binary object; if \a byte_offset specifies a position beyond the end of the string, then the search
    starts from the end of the string

    @return the byte position of a sequence of bytes within a binary object, -1 is returned if the byte sequence is
    not found

    @note an empty \a pattern argument always matches

    @see
    - Qore::zzz8binaryzzz9::find(data, softint)

    @since %Qore 0.9.1
*/
int rfind(data pattern, softint byte_offset = -1) const;

public:
//! Returns the number of bytes in the binary object
/**@return the number of bytes in the binary object

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
int len = b.size();
    @endcode

    @see Qore::zzz8binaryzzz9::sizep()
*/
int size() const;

public:
//! Returns @ref True since binary objects can return a non-zero size
/** @par Code Flags:
    @ref CONSTANT

@return @ref True since binary objects can return a non-zero size

    @see Qore::zzz8binaryzzz9::size()

    @since %Qore 0.8.9
*/
bool sizep() const;

public:
//! Returns a list of binary objects representing each component of the binary object separated by the bytes identified by the separator argument, with the separator removed
/**@par Code Flags:
    @ref CONSTANT, @ref NAMED_ARGS

    @param separator the bytes that separate the fields
    @param keep_trailing_empty keep the empty final field produced by data that ends with the separator; see @ref split_trailing_empty_fields

    @return a list of binary objects representing each component of the binary object separated by the bytes identified by the separator argument, with the separator removed

    @par Example:
    @code{.py}
list<binary> l = bin.split(sep);
    @endcode

    @note equivalent to split(data, binary, bool)

    @since
    - %Qore 0.8.5
    - %Qore 3.0 added the \c keep_trailing_empty parameter
 */
list<binary> split(data separator, bool keep_trailing_empty = False) const;

public:
//! Returns a portion of the binary data starting from an integer offset
/** Arguments can be negative, giving offsets from the end of the data.

   @par Code Flags:
    @ref CONSTANT, @ref NAMED_ARGS

     @param start The starting byte for the portion of the data where the first byte is at offset 0; if the offset is negative, it designates the number of bytes from the end of the data

    @return the portion of the data starting from an integer bte offset; the rest of the data is returned after this offset

    @par Example:
    @code{.py}
# get the last 10 bytes of a binary object
binary b1 = b0.substr(-10);
    @endcode

    @note equivalent to @ref Qore::substr(binary, softint)

    @since %Qore 0.8.8
 */
binary substr(softint start) const;

public:
//! Returns a portion of the binary data starting from an integer offset
/** Arguments can be negative, giving offsets from the end of the data.

   @par Code Flags:
    @ref CONSTANT, @ref NAMED_ARGS

     @param start The starting byte for the portion of the data where the first byte is at offset 0; if the offset is negative, it designates the number of bytes from the end of the data
    @param length The maximum number of characters to copy; if this value is negative, the rest of the string from \a start will be copied to the substring, except without - \a length characters from the end of the string

    @return the portion of the data starting from an integer bte offset; the rest of the data is returned after this offset

    @par Example:
    @code{.py}
# get the last 5 bytes of the last 10 bytes of a binary object
binary b1 = b0.substr(-10, 5);
    @endcode

    @note equivalent to @ref Qore::substr(binary, softint, softint)

    @since %Qore 0.8.8
 */
binary substr(softint start, softint length) const;

public:
//! Returns the base64-encoded representation of the binary object
/** @par Code Flags:
    @ref CONSTANT, @ref NAMED_ARGS

    @par Example:
    @code{.py}
string base64 = bin.toBase64(64);
    @endcode

    Implementation based on <a href="http://www.ietf.org/rfc/rfc1421.txt">RFC-1421</a> and
    <a href="http://www.ietf.org/rfc/rfc2045.txt">RFC-2045</a>

    @param max_line_length the maximum length of a line in the resulting output string in bytes; if this value is > 0 then
    output lines will be separated by CRLF characters

    @return the base64-encoded string of the data passed

    @since %Qore 0.8.8

    @see
    - Qore::zzz8stringzzz9::toBase64()
    - make_base64_string(binary, softint)
*/
string toBase64(softint max_line_length = -1) const;

public:
//! Returns the base64-url-encoded representation of the binary object
/** Base64-URL encoding is defined by <a href="https://datatracker.ietf.org/doc/html/rfc4648">RFC-4648</a>

   @par Code Flags:
    @ref CONSTANT, @ref NAMED_ARGS

     @par Example:
    @code{.py}
string base64 = bin.toBase64Url();
    @endcode

    @param max_line_length ignored for Base64-URL output; accepted for compatibility with Qore::zzz8binaryzzz9::toBase64()

    @return the base64-url-encoded string of the data passed

    @since %Qore 1.19.0

    @see
    - Qore::zzz8stringzzz9::toBase64Url()
    - make_base64_url_string(binary)
*/
string toBase64Url(softint max_line_length = -1) const;

public:
//! returns a string of hexadecimal digits corresponding to the contents of the binary object; hex characters are always in lower case
/** @par Code Flags:
    @ref CONSTANT

    @par Example:
    @code{.py}
string str = b.toHex();
    @endcode

    @return a string of hexadecimal digits corresponding to the contents of the binary object; hex characters are always in lower case

    @since %Qore 0.8.8

    @see
    - @ref Qore::zzz8stringzzz9::toHex()
    - @ref Qore::make_hex_string(binary)
 */
string toHex() const;

public:
//! returns a hexadecimal representation with configurable per-byte delimiters and line wrapping
/** Each byte is emitted as \a byte_prefix + 2-char lowercase hex + \a byte_suffix.
    If \a bytes_per_line > 0, \a line_separator is inserted between successive
    groups of that many bytes.  All separator arguments are optional; null /
    omitted means empty.  The 2-char hex conversion is performed via a 16-entry
    lookup table in C++, which is roughly two orders of magnitude faster than
    a per-byte sprintf("%02x") loop in Qore code.

    This API is intentionally general: with the right combination of
    arguments it emits a C \c unsigned\ char[] literal, a Python \c bytes
    literal, a plain hex dump, IPv6-style colon-separated bytes, or any
    other fixed-width-per-byte textual format.

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @par Example: C \c unsigned\ char[] literal body
    @code{.py}
string body = b.toHexArray(" 0x", ",", 12, "\n ");
# "\n  0x00, 0x01, ...\n  0x0c, 0x0d, ..."
    @endcode

    @par Example: Python bytes literal body
    @code{.py}
string py = b.toHexArray("\\x");
# "\\xff\\xab..."
    @endcode

    @par Example: IPv6-style colon-separated bytes
    @code{.py}
string addr = b.toHexArray(NOTHING, ":");
# "ff:ab:01:02:..."
    @endcode

    @par Example: simple dump
    @code{.py}
string dump = b.toHexArray(NOTHING, NOTHING, 16, "\n");
# "00010203...0f\n10111213...1f\n..."
    @endcode

    @param byte_prefix optional string emitted before each byte's hex digits
    @param byte_suffix optional string emitted after each byte's hex digits
    @param bytes_per_line if > 0, a line break is inserted every N bytes
    @param line_separator optional separator inserted between lines when
           \a bytes_per_line is > 0 (if omitted and \a bytes_per_line > 0,
           a newline is used)

    @return the formatted hex string

    @since %Qore 3.0
 */
string toHexArray(__7_ string byte_prefix, __7_ string byte_suffix, int bytes_per_line = 0, __7_ string line_separator) const;

public:
//! Returns the <a href="http://en.wikipedia.org/wiki/MD5">MD5 message digest</a> of the binary data as a hex string
/** The trailing null character is not included in the digest returned.

    @return a hex string of the digest (ex: \c "5d41402abc4b2a76b9719d911017c592")

   @par Code Flags:
    @ref RET_VALUE_ONLY

     @par Example:
    @code{.py}
string str = binary("hello").toMD5(); # returns "5d41402abc4b2a76b9719d911017c592"
    @endcode

    @throw MD5-DIGEST-ERROR error calculating digest (should not normally happen)

    @note
    - equivalent to MD5()
    - the MD5 algorithm is not collision-resistant; it's recommended to use another hash algorithm (like SHA-256) if cryptographic security is important

    @see
    - MD5_bin()
    - Qore::zzz8stringzzz9::toMD5()

    @since %Qore 0.8.5
 */
string toMD5() const;

public:
//! Returns the <a href="http://en.wikipedia.org/wiki/SHA-1">SHA1</a> message digest of the binary data as a hex string
/** The trailing null character is not included in the digest returned.

    @return a hex string of the digest (ex: \c "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d")

   @par Code Flags:
    @ref RET_VALUE_ONLY

     @par Example:
    @code{.py}
string str = binary("hello").toSHA1(); # returns "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    @endcode

    @throw SHA1-DIGEST-ERROR error calculating digest (should not normally happen)

    @note equivalent to SHA1()

    @see
    - SHA1_bin()
    - Qore::zzz8stringzzz9::toSHA1()

    @since %Qore 0.8.5
 */
string toSHA1() const;

public:
//! Returns the SHA-224 message digest (a variant of <a href="http://en.wikipedia.org/wiki/SHA-2">SHA-2</a>) of the binary data as a hex string
/** The trailing null character is not included in the digest returned.

    @par Platform Availability:
    @ref Qore::Option::HAVE_SHA224

   @par Code Flags:
    @ref RET_VALUE_ONLY

 
    @return a hex string of the digest (ex: \c "ea09ae9cc6768c50fcee903ed054556e5bfc8347907f12598aa24193")

    @par Example:
    @code{.py}
string str = binary("hello").toSHA224("hello"); # returns "ea09ae9cc6768c50fcee903ed054556e5bfc8347907f12598aa24193"
    @endcode

    @throw SHA224-DIGEST-ERROR error calculating digest (should not normally happen)

    @note equivalent to SHA224()

    @see
    - SHA224_bin()
    - Qore::zzz8stringzzz9::toSHA224()

    @since %Qore 0.8.5
 */
string toSHA224() const;

public:
//! Returns the SHA-256 message digest (a variant of <a href="http://en.wikipedia.org/wiki/SHA-2">SHA-2</a>) of the binary data as a hex string
/** The trailing null character is not included in the digest returned.

    @par Platform Availability:
    @ref Qore::Option::HAVE_SHA256

   @par Code Flags:
    @ref RET_VALUE_ONLY

 
    @return a hex string of the digest (ex: \c "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824")

    @par Example:
    @code{.py}
string str = binary("hello").toSHA256(); # returns "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"
    @endcode

    @throw SHA256-DIGEST-ERROR error calculating digest (should not normally happen)

    @note equivalent to SHA256()

    @see
    - SHA256_bin()
    - Qore::zzz8stringzzz9::toSHA256()

    @since %Qore 0.8.5
 */
string toSHA256() const;

public:
//! Returns the SHA-384 message digest (a variant of <a href="http://en.wikipedia.org/wiki/SHA-2">SHA-2</a>) of the binary data as a hex string
/** The trailing null character is not included in the digest returned.

    @par Platform Availability:
    @ref Qore::Option::HAVE_SHA384

   @par Code Flags:
    @ref RET_VALUE_ONLY

 
    @return a hex string of the digest (ex: \c "59e1748777448c69de6b800d7a33bbfb9ff1b463e44354c3553bcdb9c666fa90125a3c79f90397bdf5f6a13de828684f")

    @par Example:
    @code{.py}
string str = binary("hello").toSHA384(); # returns "59e1748777448c69de6b800d7a33bbfb9ff1b463e44354c3553bcdb9c666fa90125a3c79f90397bdf5f6a13de828684f"
    @endcode

    @throw SHA384-DIGEST-ERROR error calculating digest (should not normally happen)

    @note equivalent to SHA384()

    @see
    - SHA384_bin()
    - Qore::zzz8stringzzz9::toSHA384()

    @since %Qore 0.8.5
 */
string toSHA384() const;

public:
//! Returns the SHA-512 message digest (a variant of <a href="http://en.wikipedia.org/wiki/SHA-2">SHA-2</a>) of the binary data as a hex string
/** The trailing null character is not included in the digest returned.

    @par Platform Availability:
    @ref Qore::Option::HAVE_SHA512

   @par Code Flags:
    @ref RET_VALUE_ONLY

 
    @return a hex string of the digest (ex: \c "9b71d224bd62f3785d96d46ad3ea3d73319bfbc2890caadae2dff72519673ca72323c3d99ba5c11d7c7acc6e14b8c5da0c4663475c2e5c3adef46f73bcdec043")

    @par Example:
    @code{.py}
string str = binary("hello").toSHA512(); # returns "9b71d224bd62f3785d96d46ad3ea3d73319bfbc2890caadae2dff72519673ca72323c3d99ba5c11d7c7acc6e14b8c5da0c4663475c2e5c3adef46f73bcdec043"
    @endcode

    @throw SHA512-DIGEST-ERROR error calculating digest (should not normally happen)

    @note equivalent to SHA512()

    @see
    - SHA512_bin()
    - Qore::zzz8stringzzz9::toSHA512()

    @since %Qore 0.8.5
 */
string toSHA512() const;

public:
//! Returns a string created from the binary data, taking an optional second argument giving the string encoding; if no second argument is passed then the @ref default_encoding "default character encoding" is assumed
/**@par Code Flags:
    @ref CONSTANT, @ref NAMED_ARGS

    @param encoding the character encoding tag for the string return value; if not present, the @ref default_encoding "default character encoding" is assumed

    @return a string created from the binary data passed

    @par Example:
    @code{.py}
string str = b.toString("iso-8859-1");
    @endcode

    @since %Qore 0.8.8
*/
string toString(__7_ string encoding) const;

public:
//! Returns Qore::NT_BINARY
/**@return Qore::NT_BINARY

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
switch (b.typeCode()) {
    case NT_BINARY:
        printf("%y: is a binary\n", b);
        break;
}
    @endcode
*/
int typeCode() const;

public:
//! Returns @ref False if the binary object is empty (size = 0), @ref True if not
/** The opposite of Qore::zzz8binaryzzz9::empty()

    @return @ref False if the binary object is empty (size = 0), @ref True if not

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
bool b = bin.val();
    @endcode

    @see
    - @ref perl-bool-eval "%perl-bool-eval"
    - @ref strict-bool-eval "%strict-bool-eval"
*/
bool val() const;
};
}
