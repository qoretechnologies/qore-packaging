/* -*- mode: c++; indent-tabs-mode: nil -*- */
/*
    Pseudo_QC_String.qpp

    Qore Programming Language

    Copyright (C) 2003 - 2026 Qore Technologies, s.r.o.

    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the "Software"),
    to deal in the Software without restriction, including without limitation
    the rights to use, copy, modify, merge, publish, distribute, sublicense,
    and/or sell copies of the Software, and to permit persons to whom the
    Software is furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.

    Note that the Qore library is released under a choice of three open-source
    licenses: MIT (as above), LGPL 2+, or GPL 2+; see README-LICENSE for more
    information.
*/

#include <qore/Qore.h>
#include "qore/intern/ql_crypto.h"
#include "qore/intern/QoreLibIntern.h"
#include "qore/intern/QC_StringSplitIterator.h"
#include "qore/intern/QC_StringRegexSplitIterator.h"
#include "qore/intern/QC_StringCharIterator.h"
#include "qore/intern/QoreAsciiCompatStringHelper.h"

#include <cctype>

static const QoreStringNode* get_pseudo_string_arg(const QoreValue& v) {
    assert(v.getType() == NT_STRING && !v.isShortString());
    return reinterpret_cast<const QoreStringNode*>(v.getInternalNode());
}

static QoreStringNode* qore_pseudo_regex_escape_string(const QoreStringNode* str, ExceptionSink* xsink) {
    SimpleRefHolder<QoreStringNode> result(new QoreStringNode("", str->getEncoding()));
    size_t pos = 0;
    size_t count = 0;
    while (pos < str->size()) {
        if (count && !(count % 100) && qore_check_cancel(xsink, "escaping regex string")) {
            return nullptr;
        }

        unsigned clen = 0;
        unsigned cp = str->getUnicodePointFromBytePos(pos, clen, xsink);
        if (*xsink) {
            return nullptr;
        }

        if (!(cp < 128 && isalnum(static_cast<unsigned char>(cp)))) {
            (*result)->concat('\\');
        }
        if ((*result)->concatUnicode(cp, xsink)) {
            return nullptr;
        }

        pos += clen;
        ++count;
    }
    return result.release();
}
/* Qore class Qore::<string> */

qore_classid_t CID_PSEUDOSTRING;
QoreClass* QC_PSEUDOSTRING;

// AbstractIterator<int> PseudoString::codePointIterator() const{}
static QoreValue PseudoString_codePointIterator(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 616 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return new QoreObject(QC_STRINGCHARITERATOR, getProgram(), new StringCharIterator(str));
}

// int PseudoString::comparePartial(string other_string) const{}
static QoreValue PseudoString_comparePartial_Vs(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* other_string = *qpp_string_helper_0;
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1344 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    // convert pattern encoding to string if necessary
    TempEncodingHelper temp(other_string, str->getEncoding(), xsink);
    if (*xsink)
        return QoreValue();

    // memcmp() and not strncmp(): strings can contain embedded nulls, either because the encoding uses
    // them (UTF-16*) or because the string data itself contains them
    size_t tsize = temp->size();
    size_t ssize = str->size();
    int rc = memcmp(str->c_str(), temp->c_str(), QORE_MIN(tsize, ssize));
    if (!rc && tsize > ssize) {
        // the argument matches the entire current string but is longer than it
        rc = -1;
    }
    return !rc ? 0 : (rc < 0 ? -1 : 1);
}

// bool PseudoString::contains(string substring) const{}
static QoreValue PseudoString_contains_Vs(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* substring = *qpp_string_helper_0;
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1521 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    // convert pattern encoding to string if necessary
    TempEncodingHelper temp(substring, str->getEncoding(), xsink);
    if (*xsink) {
        return QoreValue();
    }
    // note: bindex() and not find(const char*), which determines the argument's length with strlen()
    // and therefore cannot handle encodings with embedded nulls such as UTF-16*
    return str->bindex(**temp, 0) >= 0;
}

// bool PseudoString::empty() const{}
static QoreValue PseudoString_empty(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 200 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->empty();
}

// string PseudoString::encoding() const{}
static QoreValue PseudoString_encoding(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 215 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return new QoreStringNode(str->getEncoding()->getCode());
}

// bool PseudoString::endsWith(string suffix) const{}
static QoreValue PseudoString_endsWith_Vs(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* suffix = *qpp_string_helper_0;
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1502 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    // convert pattern encoding to string if necessary
    TempEncodingHelper temp(suffix, str->getEncoding(), xsink);
    if (*xsink) {
        return QoreValue();
    }
    return str->endsWith(**temp);
}

// bool PseudoString::equalPartial(string other_string) const{}
static QoreValue PseudoString_equalPartial_Vs(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* other_string = *qpp_string_helper_0;
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1377 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->equalPartialSoft(other_string, xsink);
}

// bool PseudoString::equalPartialPath(string other_string) const{}
static QoreValue PseudoString_equalPartialPath_Vs(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* other_string = *qpp_string_helper_0;
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1395 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->equalPartialPath(other_string, xsink);
}

// int PseudoString::find(softstring substring, softint offset = 0) const{}
static QoreValue PseudoString_find_vsvi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* substring = *qpp_string_helper_0;
    int64 offset = HARD_QORE_VALUE_INT(args, 1);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 324 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->index(*substring, offset, xsink);
}

// *int PseudoString::getByte(int byte_offset) const{}
static QoreValue PseudoString_getByte_Vi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 byte_offset = HARD_QORE_VALUE_INT(args, 0);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1459 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    int64 sz = (int64)str->size();
    int64 off = byte_offset < 0 ? sz + byte_offset : byte_offset;
    if (off < 0 || off >= sz) {
        return QoreValue();
    }
    return (int64)(unsigned char)str->c_str()[off];
}

// string PseudoString::getDecoded(int decoding_flags = CD_ALL) const{}
static QoreValue PseudoString_getDecoded_Vi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 decoding_flags = HARD_QORE_VALUE_INT(args, 0);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1691 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreStringNodeHolder rv(new QoreStringNode(str->getEncoding()));
    return rv->concatDecode(xsink, *str, decoding_flags) ? nullptr : rv.release();
}

// string PseudoString::getEncoded(int encoding_flags = CE_XHTML) const{}
static QoreValue PseudoString_getEncoded_Vi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 encoding_flags = HARD_QORE_VALUE_INT(args, 0);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1674 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreStringNodeHolder rv(new QoreStringNode(str->getEncoding()));
    return rv->concatEncode(xsink, *str, encoding_flags) ? nullptr : rv.release();
}

// *string PseudoString::getLine(int offset = 0, *string line_separator, bool trim_line = True, *reference<int> byte_count) const{}
static QoreValue PseudoString_getLine_ViNsVbC15_reference_int_(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 offset = HARD_QORE_VALUE_INT(args, 0);
    QoreValue qpp_string_value_1 = get_param_value(args, 1);
    QoreStringNodeValueHelper qpp_string_helper_1(qpp_string_value_1);
    const QoreStringNode* line_separator = qpp_string_value_1.getType() == NT_STRING ? *qpp_string_helper_1 : nullptr;
    bool trim_line = HARD_QORE_VALUE_BOOL(args, 2);
    const ReferenceNode* byte_count = get_param_value(args, 3).get<const ReferenceNode>();
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1555 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
        if (str->empty())
        return QoreValue();

    if (offset < 0) {
        offset = str->size() + offset;
        if (offset < 0)
            offset = 0;
    } else if (offset >= (int64)str->size())
        return QoreValue();

    TempEncodingHelper eolstr;
    if (line_separator) {
        eolstr.set(line_separator, str->getEncoding(), xsink);
        if (*xsink)
            return QoreValue();

        if (eolstr->size() > str->size())
            return QoreValue();
    }

    // the scan below is a single bounded pass, but it can be over an arbitrarily large string, so
    // check for cancellation before starting it (see design/cooperative-cancellation.md, pattern 1)
    if (qore_check_cancel(xsink, "getting line from string")) {
        return QoreValue();
    }

    int64 strsize = 0;

    const char* start = str->c_str() + offset;
    // the byte length has to be used throughout: strings can contain embedded nulls, either because
    // the encoding uses them (UTF-16*) or because the string data itself contains them
    size_t avail = str->size() - offset;
    // in encodings that are not self-synchronizing (UTF-16*) a byte-oriented match can start in the
    // middle of a character; those matches must be skipped
    const unsigned align = qore_string_private::get_char_alignment(str->getEncoding());
    SimpleRefHolder<QoreStringNode> rv(new QoreStringNode(str->getEncoding()));

    // the end of line sequence found, if any, and its length in bytes
    const char* p = nullptr;
    size_t eol_len = 0;

    if (eolstr) {
        // an empty separator matches at the start of the string, as with strstr()
        p = eolstr->size()
            ? qore_string_private::memmem_aligned(start, avail, eolstr->c_str(), eolstr->size(), align,
                offset)
            : start;
        eol_len = eolstr->size();
    } else {
        // detect the end of line sequence automatically; the characters have to be encoded in the
        // string's encoding, since they are not single bytes in encodings that are not
        // ASCII-compatible (UTF-16*)
        QoreString cr(str->getEncoding());
        QoreString lf(str->getEncoding());
        if (str->getEncoding()->isAsciiCompat()) {
            cr.concat('\r');
            lf.concat('\n');
        } else if (cr.concatUnicode('\r') || lf.concatUnicode('\n')) {
            xsink->raiseException("UNSUPPORTED-ENCODING", "cannot detect end of line characters in "
                "encoding \"%s\"", str->getEncoding()->getCode());
            return QoreValue();
        }

        const char* crp = qore_string_private::memmem_aligned(start, avail, cr.c_str(), cr.size(),
            align, offset);
        const char* lfp = qore_string_private::memmem_aligned(start, avail, lf.c_str(), lf.size(),
            align, offset);
        if (crp && (!lfp || crp < lfp)) {
            p = crp;
            eol_len = cr.size();
            // "\r\n" is a single end of line sequence
            if (lfp == crp + cr.size()) {
                eol_len += lf.size();
            }
        } else if (lfp) {
            p = lfp;
            eol_len = lf.size();
        }
    }

    if (p) {
        strsize = p - start + eol_len;
        if (trim_line) {
            if (p != start) {
                rv->concat(start, p - start);
            }
        } else {
            rv->concat(start, strsize);
        }
    } else {
        rv->concat(start, avail);
        strsize = avail;
    }

    if (byte_count) {
        QoreTypeSafeReferenceHelper r(byte_count, xsink);
        if (!r)
            return QoreValue();

        if (r.assign(strsize))
            return QoreValue();
    }

    return rv.release();
}

// int PseudoString::getUnicode(int offset = 0) const{}
static QoreValue PseudoString_getUnicode_Vi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 offset = HARD_QORE_VALUE_INT(args, 0);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1432 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->getUnicodePoint(offset, xsink);
}

// bool PseudoString::intp() const{}
static QoreValue PseudoString_intp(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 384 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    if (str->empty()) {
        return false;
    }
    QoreAsciiCompatStringHelper text(*str);
    char c = text.c_str()[0];
    if (c == '-') {
        c = text.c_str()[1];
    }
    return isdigit(static_cast<unsigned char>(c)) ? true : false;
}

// bool PseudoString::isDataAscii() const{}
static QoreValue PseudoString_isDataAscii(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1241 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->isDataAscii();
}

// bool PseudoString::isDataPrintableAscii() const{}
static QoreValue PseudoString_isDataPrintableAscii(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1256 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->isDataPrintableAscii();
}

// AbstractIterator<char> PseudoString::iterator() const{}
static QoreValue PseudoString_iterator(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 640 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return new QoreObject(QC_STRINGITERATOR, getProgram(), new StringIterator(str));
}

// int PseudoString::length() const{}
static QoreValue PseudoString_length(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 160 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->length();
}

// string PseudoString::lwr() const{}
static QoreValue PseudoString_lwr(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 250 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    SimpleRefHolder<QoreStringNode> rv(new QoreStringNode(str->getEncoding()));
   if (do_tolower(*(*rv), *str, xsink))
      return QoreValue();

   return rv.release();
}

// bool PseudoString::regex(string pattern, int options = 0) const{}
static QoreValue PseudoString_regex_VsVi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* pattern = *qpp_string_helper_0;
    int64 options = HARD_QORE_VALUE_INT(args, 1);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 846 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreRegex qr(*pattern, options, xsink);
    if (*xsink) {
        return QoreValue();
    }

    return qr.exec(str, xsink);
}

// int PseudoString::regexCount(string pattern, int options = 0) const{}
static QoreValue PseudoString_regexCount_VsVi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* pattern = *qpp_string_helper_0;
    int64 options = HARD_QORE_VALUE_INT(args, 1);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 913 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreRegex qr(*pattern, options, xsink);
    if (*xsink) {
        return QoreValue();
    }
    return qr.countMatches(str, xsink);
}

// string PseudoString::regexEscape() const{}
static QoreValue PseudoString_regexEscape(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1002 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return qore_pseudo_regex_escape_string(str, xsink);
}

// *list<*string> PseudoString::regexExtract(string pattern, int options = 0) const{}
static QoreValue PseudoString_regexExtract_VsVi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* pattern = *qpp_string_helper_0;
    int64 options = HARD_QORE_VALUE_INT(args, 1);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 885 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreRegex qr(*pattern, options, xsink);
    if (*xsink)
        return QoreValue();

    return qr.extractSubstrings(str, xsink);
}

// *list<hash<RegexMatchInfo>> PseudoString::regexExtractDetailed(string pattern, int options = 0) const{}
static QoreValue PseudoString_regexExtractDetailed_VsVi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* pattern = *qpp_string_helper_0;
    int64 options = HARD_QORE_VALUE_INT(args, 1);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 979 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreRegex qr(*pattern, options, xsink);
    if (*xsink) {
        return QoreValue();
    }
    return qr.extractDetailed(str, xsink);
}

// auto PseudoString::regexExtractNamed(string pattern, int options = 0) const{}
static QoreValue PseudoString_regexExtractNamed_VsVi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* pattern = *qpp_string_helper_0;
    int64 options = HARD_QORE_VALUE_INT(args, 1);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 946 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreRegex qr(*pattern, options, xsink);
    if (*xsink) {
        return QoreValue();
    }
    return qr.extractNamedGroups(str, xsink);
}

// int PseudoString::rfind(softstring substring, softint offset = -1) const{}
static QoreValue PseudoString_rfind_vsvi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* substring = *qpp_string_helper_0;
    int64 offset = HARD_QORE_VALUE_INT(args, 1);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 358 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->rindex(*substring, (qore_offset_t)offset, xsink);
}

// int PseudoString::size() const{}
static QoreValue PseudoString_size(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 138 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->size();
}

// bool PseudoString::sizep() const{}
static QoreValue PseudoString_sizep(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 1475 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return true;
}

// list<string> PseudoString::split(string separator, bool with_separator = False, bool keep_trailing_empty = False) const{}
static QoreValue PseudoString_split_VsVbVb(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* separator = *qpp_string_helper_0;
    bool with_separator = HARD_QORE_VALUE_BOOL(args, 1);
    bool keep_trailing_empty = HARD_QORE_VALUE_BOOL(args, 2);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 527 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    // convert pattern encoding to string if necessary
    TempEncodingHelper temp(separator, str->getEncoding(), xsink);
    if (*xsink)
        return QoreValue();

    return split_intern(temp->c_str(), temp->strlen(), str->c_str(), str->strlen(), str->getEncoding(),
        with_separator, keep_trailing_empty);
    return QoreValue();
}

// list<string> PseudoString::split(string separator, string quote, bool trim_unquoted = False, bool keep_trailing_empty = False) const{}
static QoreValue PseudoString_split_VsVsVbVb(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* separator = *qpp_string_helper_0;
    QoreStringNodeValueHelper qpp_string_helper_1(get_hard_value_param(args, 1));
    const QoreStringNode* quote = *qpp_string_helper_1;
    bool trim_unquoted = HARD_QORE_VALUE_BOOL(args, 2);
    bool keep_trailing_empty = HARD_QORE_VALUE_BOOL(args, 3);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 746 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return split_with_quote(xsink, separator, str, quote, trim_unquoted, nullptr, nullptr, keep_trailing_empty);
}

// AbstractIterator<string> PseudoString::splitChars() const{}
static QoreValue PseudoString_splitChars(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 585 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return new QoreObject(QC_STRINGSPLITITERATOR, getProgram(),
        new StringSplitIterator(str, nullptr, StringSplitIterator::SPLIT_CHARS));
    return QoreValue();
}

// AbstractIterator<string> PseudoString::splitLines() const{}
static QoreValue PseudoString_splitLines(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 660 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreString nl("\n");
    return new QoreObject(QC_STRINGSPLITITERATOR, getProgram(),
        new StringSplitIterator(str, &nl, StringSplitIterator::STRIP_TRAILING_CR));
    return QoreValue();
}

// AbstractIterator<string> PseudoString::splitLinesRegex(string separator_pattern, int options = 0, bool with_separator = False) const{}
static QoreValue PseudoString_splitLinesRegex_VsViVb(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* separator_pattern = *qpp_string_helper_0;
    int64 options = HARD_QORE_VALUE_INT(args, 1);
    bool with_separator = HARD_QORE_VALUE_BOOL(args, 2);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 695 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
        SimpleRefHolder<QoreRegex> re(new QoreRegex(*separator_pattern, options, xsink));
    if (*xsink) {
        return QoreValue();
    }
    ReferenceHolder<StringRegexSplitIterator> it(
        new StringRegexSplitIterator(str, *re, with_separator, xsink), xsink);
    if (*xsink) {
        return QoreValue();
    }
    return new QoreObject(QC_STRINGREGEXSPLITITERATOR, getProgram(), it.release());
}

// list<string> PseudoString::splitRegex(string separator_pattern, int options = 0, bool with_separator = False, int limit = -1) const{}
static QoreValue PseudoString_splitRegex_VsViVbVi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* separator_pattern = *qpp_string_helper_0;
    int64 options = HARD_QORE_VALUE_INT(args, 1);
    bool with_separator = HARD_QORE_VALUE_BOOL(args, 2);
    int64 limit = HARD_QORE_VALUE_INT(args, 3);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 777 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreRegex qr(*separator_pattern, options, xsink);
    if (*xsink) {
        return QoreValue();
    }

    return qr.extractWithPattern(*str, with_separator, xsink, limit);
}

// list<string> PseudoString::splitRegex(string separator_pattern, bool with_separator = False, int limit = -1) const{}
static QoreValue PseudoString_splitRegex_VsVbVi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* separator_pattern = *qpp_string_helper_0;
    bool with_separator = HARD_QORE_VALUE_BOOL(args, 1);
    int64 limit = HARD_QORE_VALUE_INT(args, 2);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 812 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreRegex qr(*separator_pattern, 0, xsink);
    if (*xsink) {
        return QoreValue();
    }

    return qr.extractWithPattern(*str, with_separator, xsink, limit);
}

// AbstractIterator<string> PseudoString::splitString(string separator) const{}
static QoreValue PseudoString_splitString_Vs(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* separator = *qpp_string_helper_0;
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 555 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    // Convert separator encoding if needed; use c_str()/size() on the source
    // (the iterator holds its own ref and walks bytes — encoding matters only
    // for the separator search).
    TempEncodingHelper temp(separator, str->getEncoding(), xsink);
    if (*xsink)
        return QoreValue();
    return new QoreObject(QC_STRINGSPLITITERATOR, getProgram(),
        new StringSplitIterator(str, *temp));
    return QoreValue();
}

// bool PseudoString::startsWith(string prefix) const{}
static QoreValue PseudoString_startsWith_Vs(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* prefix = *qpp_string_helper_0;
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1486 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    // convert pattern encoding to string if necessary
    TempEncodingHelper temp(prefix, str->getEncoding(), xsink);
    if (*xsink) {
        return QoreValue();
    }
    return str->startsWith(**temp);
}

// int PseudoString::strlen() const{}
static QoreValue PseudoString_strlen(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 116 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->strlen();
}

// bool PseudoString::strp() const{}
static QoreValue PseudoString_strp(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 449 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return true;
}

// string PseudoString::substr(softint start) const{}
static QoreValue PseudoString_substr_vi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 start = HARD_QORE_VALUE_INT(args, 0);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 470 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreStringNode* rv = str->substr(start, xsink);
    if (!rv)
        rv = new QoreStringNode(str->getEncoding());
    return rv;
}

// string PseudoString::substr(softint start, softint length) const{}
static QoreValue PseudoString_substr_vivi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 start = HARD_QORE_VALUE_INT(args, 0);
    int64 length = HARD_QORE_VALUE_INT(args, 1);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 497 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreStringNode* rv = str->substr(start, length, xsink);
    if (!rv)
        rv = new QoreStringNode(str->getEncoding());
    return rv;
}

// string PseudoString::toBase64(softint max_line_length = -1) const{}
static QoreValue PseudoString_toBase64_vi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 max_line_length = HARD_QORE_VALUE_INT(args, 0);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1300 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreStringNode *rv = new QoreStringNode;
    rv->concatBase64(str, max_line_length);
    return rv;
}

// string PseudoString::toBase64Url(softint max_line_length = -1) const{}
static QoreValue PseudoString_toBase64Url_vi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1324 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreStringNode* rv = new QoreStringNode;
    rv->concatBase64Url(*str);
    return rv;
}

// binary PseudoString::toBinary() const{}
static QoreValue PseudoString_toBinary(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1225 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    SimpleRefHolder<BinaryNode> b(new BinaryNode);
    b->append(str->c_str(), str->size());
    return b.release();
}

// string PseudoString::toHex() const{}
static QoreValue PseudoString_toHex(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1274 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    QoreStringNode *rv = new QoreStringNode;
    rv->concatHex(str);
    return rv;
}

// int PseudoString::toInt(int base = 10) const{}
static QoreValue PseudoString_toInt_Vi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 base = HARD_QORE_VALUE_INT(args, 0);
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 430 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    if (base < 0 || base == 1 || base > 36) {
        return xsink -> raiseException("INVALID-BASE", "base " QLLD " is invalid; base must be 0 or 2 - 36 inclusive",
            base);
    }
    QoreAsciiCompatStringHelper text(*str);
    return strtoll(text.c_str(), 0, (int)base);
}

// string PseudoString::toMD5() const{}
static QoreValue PseudoString_toMD5(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1029 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    DigestHelper dh(*str);
    if (dh.doDigest(MD5_ERR, EVP_md5(), xsink))
        return QoreValue();

    return dh.getString();
}

// string PseudoString::toSHA1() const{}
static QoreValue PseudoString_toSHA1(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1057 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    DigestHelper dh(*str);
    if (dh.doDigest(SHA1_ERR, EVP_sha1(), xsink))
        return QoreValue();

    return dh.getString();
}

// string PseudoString::toSHA224() const{}
static QoreValue PseudoString_toSHA224(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1088 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    #if !defined(OPENSSL_NO_SHA256) && defined(HAVE_OPENSSL_SHA512)
    DigestHelper dh(*str);
    if (dh.doDigest(SHA224_ERR, EVP_sha224(), xsink))
        return QoreValue();

    return dh.getString();
#else
    missing_openssl_feature("SHA224", xsink);
    return QoreValue();
#endif
    return QoreValue();
}

// string PseudoString::toSHA256() const{}
static QoreValue PseudoString_toSHA256(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1124 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    #if !defined(OPENSSL_NO_SHA256) && defined(HAVE_OPENSSL_SHA512)
    DigestHelper dh(*str);
    if (dh.doDigest(SHA256_ERR, EVP_sha256(), xsink))
        return QoreValue();

    return dh.getString();
#else
    missing_openssl_feature("SHA256", xsink);
    return QoreValue();
#endif
    return QoreValue();
}

// string PseudoString::toSHA384() const{}
static QoreValue PseudoString_toSHA384(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1162 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    #if !defined(OPENSSL_NO_SHA512) && defined(HAVE_OPENSSL_SHA512)
    DigestHelper dh(*str);
    if (dh.doDigest(SHA384_ERR, EVP_sha384(), xsink))
        return QoreValue();

    return dh.getString();
#else
    missing_openssl_feature("SHA384", xsink);
    return QoreValue();
#endif
    return QoreValue();
}

// string PseudoString::toSHA512() const{}
static QoreValue PseudoString_toSHA512(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1200 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    #if !defined(OPENSSL_NO_SHA512) && defined(HAVE_OPENSSL_SHA512)
    DigestHelper dh(*str);
    if (dh.doDigest(SHA512_ERR, EVP_sha512(), xsink))
        return QoreValue();

    return dh.getString();
#else
    missing_openssl_feature("SHA512", xsink);
    return QoreValue();
#endif
    return QoreValue();
}

// int PseudoString::typeCode() const{}
static QoreValue PseudoString_typeCode(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 94 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return NT_STRING;
}

// string PseudoString::unaccent() const{}
static QoreValue PseudoString_unaccent(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 1412 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    SimpleRefHolder<QoreStringNode> rv(new QoreStringNode(str->getEncoding()));
    if (do_unaccent(*(*rv), *str, xsink))
        return QoreValue();

    return rv.release();
}

// string PseudoString::upr() const{}
static QoreValue PseudoString_upr(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 287 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    SimpleRefHolder<QoreStringNode> rv(new QoreStringNode(str->getEncoding()));
   if (do_toupper(*(*rv), *str, xsink))
      return QoreValue();

   return rv.release();
}

// bool PseudoString::val() const{}
static QoreValue PseudoString_val(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 370 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return !str->empty();
}

// int PseudoString::width() const{}
static QoreValue PseudoString_width(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreStringNode* str = get_pseudo_string_arg(v);
# 186 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_String.qpp"
    return str->getCharWidth(xsink);
}

DLLLOCAL void preinitPseudoStringClass() {
    QC_PSEUDOSTRING = new QoreBuiltinClass("<string>", "::Qore::<string>", QDOM_DEFAULT);
    CID_PSEUDOSTRING = QC_PSEUDOSTRING->getID();
    QC_PSEUDOSTRING->setSystem();
}

DLLLOCAL QoreClass* initPseudoStringClass() {
    if (!QC_PSEUDOSTRING)
        preinitPseudoStringClass();

    // set parent class
    assert(QC_PSEUDOVALUE);
    QC_PSEUDOSTRING->addBuiltinVirtualBaseClass(QC_PSEUDOVALUE);

    // AbstractIterator<int> PseudoString::codePointIterator() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 616);
        QC_PSEUDOSTRING->addConstMethod("codePointIterator", (q_method_t)PseudoString_codePointIterator, Public, QCF_CONSTANT, QDOM_DEFAULT, QC_ABSTRACTITERATOR->getTypeInfo([&]() { type_vec_t qpp_type_args; qpp_type_args.push_back(bigIntTypeInfo); return qpp_type_args; }(), false));
    }

    // int PseudoString::comparePartial(string other_string) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1344);
        QC_PSEUDOSTRING->addConstMethod("comparePartial", (q_method_t)PseudoString_comparePartial_Vs, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, bigIntTypeInfo, 1, stringTypeInfo, QORE_PARAM_NO_ARG, "other_string");
    }

    // bool PseudoString::contains(string substring) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1521);
        QC_PSEUDOSTRING->addConstMethod("contains", (q_method_t)PseudoString_contains_Vs, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, stringTypeInfo, QORE_PARAM_NO_ARG, "substring");
    }

    // bool PseudoString::empty() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 200);
        QC_PSEUDOSTRING->addConstMethod("empty", (q_method_t)PseudoString_empty, Public, QCF_CONSTANT, QDOM_DEFAULT, boolTypeInfo);
    }

    // string PseudoString::encoding() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 215);
        QC_PSEUDOSTRING->addConstMethod("encoding", (q_method_t)PseudoString_encoding, Public, QCF_CONSTANT, QDOM_DEFAULT, stringTypeInfo);
    }

    // bool PseudoString::endsWith(string suffix) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1502);
        QC_PSEUDOSTRING->addConstMethod("endsWith", (q_method_t)PseudoString_endsWith_Vs, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, stringTypeInfo, QORE_PARAM_NO_ARG, "suffix");
    }

    // bool PseudoString::equalPartial(string other_string) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1377);
        QC_PSEUDOSTRING->addConstMethod("equalPartial", (q_method_t)PseudoString_equalPartial_Vs, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, stringTypeInfo, QORE_PARAM_NO_ARG, "other_string");
    }

    // bool PseudoString::equalPartialPath(string other_string) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1395);
        QC_PSEUDOSTRING->addConstMethod("equalPartialPath", (q_method_t)PseudoString_equalPartialPath_Vs, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, stringTypeInfo, QORE_PARAM_NO_ARG, "other_string");
    }

    // int PseudoString::find(softstring substring, softint offset = 0) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 324);
        QC_PSEUDOSTRING->addConstMethod("find", (q_method_t)PseudoString_find_vsvi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, bigIntTypeInfo, 2, softStringTypeInfo, QORE_PARAM_NO_ARG, "substring", softBigIntTypeInfo, QoreSimpleValue((int64)0), "offset");
    }

    // *int PseudoString::getByte(int byte_offset) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1459);
        QC_PSEUDOSTRING->addConstMethod("getByte", (q_method_t)PseudoString_getByte_Vi, Public, QCF_CONSTANT|QCF_NAMED_ARGS, QDOM_DEFAULT, bigIntOrNothingTypeInfo, 1, bigIntTypeInfo, QORE_PARAM_NO_ARG, "byte_offset");
    }

    // string PseudoString::getDecoded(int decoding_flags = CD_ALL) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1691);
        QC_PSEUDOSTRING->addConstMethod("getDecoded", (q_method_t)PseudoString_getDecoded_Vi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, stringTypeInfo, 1, bigIntTypeInfo, QoreSimpleValue((int64)CD_ALL), "decoding_flags");
    }

    // string PseudoString::getEncoded(int encoding_flags = CE_XHTML) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1674);
        QC_PSEUDOSTRING->addConstMethod("getEncoded", (q_method_t)PseudoString_getEncoded_Vi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, stringTypeInfo, 1, bigIntTypeInfo, QoreSimpleValue((int64)CE_XHTML), "encoding_flags");
    }

    // *string PseudoString::getLine(int offset = 0, *string line_separator, bool trim_line = True, *reference<int> byte_count) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1555);
        QC_PSEUDOSTRING->addConstMethod("getLine", (q_method_t)PseudoString_getLine_ViNsVbC15_reference_int_, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, stringOrNothingTypeInfo, 4, bigIntTypeInfo, QoreSimpleValue((int64)0), "offset", stringOrNothingTypeInfo, QORE_PARAM_NO_ARG, "line_separator", boolTypeInfo, QoreSimpleValue(true), "trim_line", qore_get_complex_reference_or_nothing_type(bigIntTypeInfo), QORE_PARAM_NO_ARG, "byte_count");
    }

    // int PseudoString::getUnicode(int offset = 0) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1432);
        QC_PSEUDOSTRING->addConstMethod("getUnicode", (q_method_t)PseudoString_getUnicode_Vi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, bigIntTypeInfo, 1, bigIntTypeInfo, QoreSimpleValue((int64)0), "offset");
    }

    // bool PseudoString::intp() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 384);
        QC_PSEUDOSTRING->addConstMethod("intp", (q_method_t)PseudoString_intp, Public, QCF_CONSTANT, QDOM_DEFAULT, boolTypeInfo);
    }

    // bool PseudoString::isDataAscii() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1241);
        QC_PSEUDOSTRING->addConstMethod("isDataAscii", (q_method_t)PseudoString_isDataAscii, Public, QCF_CONSTANT, QDOM_DEFAULT, boolTypeInfo);
    }

    // bool PseudoString::isDataPrintableAscii() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1256);
        QC_PSEUDOSTRING->addConstMethod("isDataPrintableAscii", (q_method_t)PseudoString_isDataPrintableAscii, Public, QCF_CONSTANT, QDOM_DEFAULT, boolTypeInfo);
    }

    // AbstractIterator<char> PseudoString::iterator() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 640);
        QC_PSEUDOSTRING->addConstMethod("iterator", (q_method_t)PseudoString_iterator, Public, QCF_CONSTANT, QDOM_DEFAULT, QC_ABSTRACTITERATOR->getTypeInfo([&]() { type_vec_t qpp_type_args; qpp_type_args.push_back(charTypeInfo); return qpp_type_args; }(), false));
    }

    // int PseudoString::length() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 160);
        QC_PSEUDOSTRING->addConstMethod("length", (q_method_t)PseudoString_length, Public, QCF_CONSTANT, QDOM_DEFAULT, bigIntTypeInfo);
    }

    // string PseudoString::lwr() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 250);
        QC_PSEUDOSTRING->addConstMethod("lwr", (q_method_t)PseudoString_lwr, Public, QCF_CONSTANT, QDOM_DEFAULT, stringTypeInfo);
    }

    // bool PseudoString::regex(string pattern, int options = 0) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 846);
        QC_PSEUDOSTRING->addConstMethod("regex", (q_method_t)PseudoString_regex_VsVi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 2, stringTypeInfo, QORE_PARAM_NO_ARG, "pattern", bigIntTypeInfo, QoreSimpleValue((int64)0), "options");
    }

    // int PseudoString::regexCount(string pattern, int options = 0) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 913);
        QC_PSEUDOSTRING->addConstMethod("regexCount", (q_method_t)PseudoString_regexCount_VsVi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, bigIntTypeInfo, 2, stringTypeInfo, QORE_PARAM_NO_ARG, "pattern", bigIntTypeInfo, QoreSimpleValue((int64)0), "options");
    }

    // string PseudoString::regexEscape() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1002);
        QC_PSEUDOSTRING->addConstMethod("regexEscape", (q_method_t)PseudoString_regexEscape, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // *list<*string> PseudoString::regexExtract(string pattern, int options = 0) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 885);
        QC_PSEUDOSTRING->addConstMethod("regexExtract", (q_method_t)PseudoString_regexExtract_VsVi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, qore_get_complex_list_or_nothing_type(stringOrNothingTypeInfo), 2, stringTypeInfo, QORE_PARAM_NO_ARG, "pattern", bigIntTypeInfo, QoreSimpleValue((int64)0), "options");
    }

    // *list<hash<RegexMatchInfo>> PseudoString::regexExtractDetailed(string pattern, int options = 0) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 979);
        QC_PSEUDOSTRING->addConstMethod("regexExtractDetailed", (q_method_t)PseudoString_regexExtractDetailed_VsVi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, qore_get_complex_list_or_nothing_type(hashdeclRegexMatchInfo->getTypeInfo(false)), 2, stringTypeInfo, QORE_PARAM_NO_ARG, "pattern", bigIntTypeInfo, QoreSimpleValue((int64)0), "options");
    }

    // auto PseudoString::regexExtractNamed(string pattern, int options = 0) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 946);
        QC_PSEUDOSTRING->addConstMethod("regexExtractNamed", (q_method_t)PseudoString_regexExtractNamed_VsVi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, autoTypeInfo, 2, stringTypeInfo, QORE_PARAM_NO_ARG, "pattern", bigIntTypeInfo, QoreSimpleValue((int64)0), "options");
    }

    // int PseudoString::rfind(softstring substring, softint offset = -1) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 358);
        QC_PSEUDOSTRING->addConstMethod("rfind", (q_method_t)PseudoString_rfind_vsvi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, bigIntTypeInfo, 2, softStringTypeInfo, QORE_PARAM_NO_ARG, "substring", softBigIntTypeInfo, QoreSimpleValue((int64)-1), "offset");
    }

    // int PseudoString::size() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 138);
        QC_PSEUDOSTRING->addConstMethod("size", (q_method_t)PseudoString_size, Public, QCF_CONSTANT, QDOM_DEFAULT, bigIntTypeInfo);
    }

    // bool PseudoString::sizep() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1475);
        QC_PSEUDOSTRING->addConstMethod("sizep", (q_method_t)PseudoString_sizep, Public, QCF_CONSTANT, QDOM_DEFAULT, boolTypeInfo);
    }

    // list<string> PseudoString::split(string separator, bool with_separator = False, bool keep_trailing_empty = False) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 527);
        QC_PSEUDOSTRING->addConstMethod("split", (q_method_t)PseudoString_split_VsVbVb, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, qore_get_complex_list_type(stringTypeInfo), 3, stringTypeInfo, QORE_PARAM_NO_ARG, "separator", boolTypeInfo, QoreSimpleValue(false), "with_separator", boolTypeInfo, QoreSimpleValue(false), "keep_trailing_empty");
    }

    // list<string> PseudoString::split(string separator, string quote, bool trim_unquoted = False, bool keep_trailing_empty = False) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 746);
        QC_PSEUDOSTRING->addConstMethod("split", (q_method_t)PseudoString_split_VsVsVbVb, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, qore_get_complex_list_type(stringTypeInfo), 4, stringTypeInfo, QORE_PARAM_NO_ARG, "separator", stringTypeInfo, QORE_PARAM_NO_ARG, "quote", boolTypeInfo, QoreSimpleValue(false), "trim_unquoted", boolTypeInfo, QoreSimpleValue(false), "keep_trailing_empty");
    }

    // AbstractIterator<string> PseudoString::splitChars() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 585);
        QC_PSEUDOSTRING->addConstMethod("splitChars", (q_method_t)PseudoString_splitChars, Public, QCF_CONSTANT, QDOM_DEFAULT, QC_ABSTRACTITERATOR->getTypeInfo([&]() { type_vec_t qpp_type_args; qpp_type_args.push_back(stringTypeInfo); return qpp_type_args; }(), false));
    }

    // AbstractIterator<string> PseudoString::splitLines() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 660);
        QC_PSEUDOSTRING->addConstMethod("splitLines", (q_method_t)PseudoString_splitLines, Public, QCF_CONSTANT, QDOM_DEFAULT, QC_ABSTRACTITERATOR->getTypeInfo([&]() { type_vec_t qpp_type_args; qpp_type_args.push_back(stringTypeInfo); return qpp_type_args; }(), false));
    }

    // AbstractIterator<string> PseudoString::splitLinesRegex(string separator_pattern, int options = 0, bool with_separator = False) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 695);
        QC_PSEUDOSTRING->addConstMethod("splitLinesRegex", (q_method_t)PseudoString_splitLinesRegex_VsViVb, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, QC_ABSTRACTITERATOR->getTypeInfo([&]() { type_vec_t qpp_type_args; qpp_type_args.push_back(stringTypeInfo); return qpp_type_args; }(), false), 3, stringTypeInfo, QORE_PARAM_NO_ARG, "separator_pattern", bigIntTypeInfo, QoreSimpleValue((int64)0), "options", boolTypeInfo, QoreSimpleValue(false), "with_separator");
    }

    // list<string> PseudoString::splitRegex(string separator_pattern, int options = 0, bool with_separator = False, int limit = -1) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 777);
        QC_PSEUDOSTRING->addConstMethod("splitRegex", (q_method_t)PseudoString_splitRegex_VsViVbVi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, qore_get_complex_list_type(stringTypeInfo), 4, stringTypeInfo, QORE_PARAM_NO_ARG, "separator_pattern", bigIntTypeInfo, QoreSimpleValue((int64)0), "options", boolTypeInfo, QoreSimpleValue(false), "with_separator", bigIntTypeInfo, QoreSimpleValue((int64)-1), "limit");
    }

    // list<string> PseudoString::splitRegex(string separator_pattern, bool with_separator = False, int limit = -1) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 812);
        QC_PSEUDOSTRING->addConstMethod("splitRegex", (q_method_t)PseudoString_splitRegex_VsVbVi, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, qore_get_complex_list_type(stringTypeInfo), 3, stringTypeInfo, QORE_PARAM_NO_ARG, "separator_pattern", boolTypeInfo, QoreSimpleValue(false), "with_separator", bigIntTypeInfo, QoreSimpleValue((int64)-1), "limit");
    }

    // AbstractIterator<string> PseudoString::splitString(string separator) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 555);
        QC_PSEUDOSTRING->addConstMethod("splitString", (q_method_t)PseudoString_splitString_Vs, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, QC_ABSTRACTITERATOR->getTypeInfo([&]() { type_vec_t qpp_type_args; qpp_type_args.push_back(stringTypeInfo); return qpp_type_args; }(), false), 1, stringTypeInfo, QORE_PARAM_NO_ARG, "separator");
    }

    // bool PseudoString::startsWith(string prefix) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1486);
        QC_PSEUDOSTRING->addConstMethod("startsWith", (q_method_t)PseudoString_startsWith_Vs, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, stringTypeInfo, QORE_PARAM_NO_ARG, "prefix");
    }

    // int PseudoString::strlen() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 116);
        QC_PSEUDOSTRING->addConstMethod("strlen", (q_method_t)PseudoString_strlen, Public, QCF_CONSTANT, QDOM_DEFAULT, bigIntTypeInfo);
    }

    // bool PseudoString::strp() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 449);
        QC_PSEUDOSTRING->addConstMethod("strp", (q_method_t)PseudoString_strp, Public, QCF_CONSTANT, QDOM_DEFAULT, boolTypeInfo);
    }

    // string PseudoString::substr(softint start) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 470);
        QC_PSEUDOSTRING->addConstMethod("substr", (q_method_t)PseudoString_substr_vi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, stringTypeInfo, 1, softBigIntTypeInfo, QORE_PARAM_NO_ARG, "start");
    }

    // string PseudoString::substr(softint start, softint length) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 497);
        QC_PSEUDOSTRING->addConstMethod("substr", (q_method_t)PseudoString_substr_vivi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, stringTypeInfo, 2, softBigIntTypeInfo, QORE_PARAM_NO_ARG, "start", softBigIntTypeInfo, QORE_PARAM_NO_ARG, "length");
    }

    // string PseudoString::toBase64(softint max_line_length = -1) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1300);
        QC_PSEUDOSTRING->addConstMethod("toBase64", (q_method_t)PseudoString_toBase64_vi, Public, QCF_CONSTANT|QCF_NAMED_ARGS, QDOM_DEFAULT, stringTypeInfo, 1, softBigIntTypeInfo, QoreSimpleValue((int64)-1), "max_line_length");
    }

    // string PseudoString::toBase64Url(softint max_line_length = -1) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1324);
        QC_PSEUDOSTRING->addConstMethod("toBase64Url", (q_method_t)PseudoString_toBase64Url_vi, Public, QCF_CONSTANT|QCF_NAMED_ARGS, QDOM_DEFAULT, stringTypeInfo, 1, softBigIntTypeInfo, QoreSimpleValue((int64)-1), "max_line_length");
    }

    // binary PseudoString::toBinary() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1225);
        QC_PSEUDOSTRING->addConstMethod("toBinary", (q_method_t)PseudoString_toBinary, Public, QCF_CONSTANT, QDOM_DEFAULT, binaryTypeInfo);
    }

    // string PseudoString::toHex() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1274);
        QC_PSEUDOSTRING->addConstMethod("toHex", (q_method_t)PseudoString_toHex, Public, QCF_CONSTANT, QDOM_DEFAULT, stringTypeInfo);
    }

    // int PseudoString::toInt(int base = 10) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 430);
        QC_PSEUDOSTRING->addConstMethod("toInt", (q_method_t)PseudoString_toInt_Vi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, bigIntTypeInfo, 1, bigIntTypeInfo, QoreSimpleValue((int64)10), "base");
    }

    // string PseudoString::toMD5() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1029);
        QC_PSEUDOSTRING->addConstMethod("toMD5", (q_method_t)PseudoString_toMD5, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoString::toSHA1() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1057);
        QC_PSEUDOSTRING->addConstMethod("toSHA1", (q_method_t)PseudoString_toSHA1, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoString::toSHA224() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1088);
        QC_PSEUDOSTRING->addConstMethod("toSHA224", (q_method_t)PseudoString_toSHA224, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoString::toSHA256() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1124);
        QC_PSEUDOSTRING->addConstMethod("toSHA256", (q_method_t)PseudoString_toSHA256, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoString::toSHA384() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1162);
        QC_PSEUDOSTRING->addConstMethod("toSHA384", (q_method_t)PseudoString_toSHA384, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoString::toSHA512() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1200);
        QC_PSEUDOSTRING->addConstMethod("toSHA512", (q_method_t)PseudoString_toSHA512, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // int PseudoString::typeCode() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 94);
        QC_PSEUDOSTRING->addConstMethod("typeCode", (q_method_t)PseudoString_typeCode, Public, QCF_CONSTANT, QDOM_DEFAULT, bigIntTypeInfo);
    }

    // string PseudoString::unaccent() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 1412);
        QC_PSEUDOSTRING->addConstMethod("unaccent", (q_method_t)PseudoString_unaccent, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoString::upr() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 287);
        QC_PSEUDOSTRING->addConstMethod("upr", (q_method_t)PseudoString_upr, Public, QCF_CONSTANT, QDOM_DEFAULT, stringTypeInfo);
    }

    // bool PseudoString::val() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 370);
        QC_PSEUDOSTRING->addConstMethod("val", (q_method_t)PseudoString_val, Public, QCF_CONSTANT, QDOM_DEFAULT, boolTypeInfo);
    }

    // int PseudoString::width() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_String.qpp", 186);
        QC_PSEUDOSTRING->addConstMethod("width", (q_method_t)PseudoString_width, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, bigIntTypeInfo);
    }

    return QC_PSEUDOSTRING;
}
