/* -*- mode: c++; indent-tabs-mode: nil -*- */
/*
    Pseudo_QC_Binary.qpp

    Qore Programming Language

    Copyright (C) 2003 - 2026 Qore Technologies, s.r.o.

    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the "Software"),
    to deal in the Software without restriction, including without limitation
    the rights to use, copy, modify, merge, publish, distribute, sublicense,
    and/or sell copies of the Software, and to permit persons to whom the
    Software is furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.

    Note that the Qore library is released under a choice of three open-source
    licenses: MIT (as above), LGPL 2+, or GPL 2+; see README-LICENSE for more
    information.
*/

#include <qore/Qore.h>
#include "qore/intern/qore_string_private.h"
/* Qore class Qore::<binary> */

qore_classid_t CID_PSEUDOBINARY;
QoreClass* QC_PSEUDOBINARY;

// bool PseudoBinary::empty() const{}
static QoreValue PseudoBinary_empty(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const BinaryNode* b = v.get<const BinaryNode>();
# 186 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    return b->empty();
}

// int PseudoBinary::find(data pattern, softint byte_offset = 0) const{}
static QoreValue PseudoBinary_find_VDvi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreValue pattern = get_param_value(args, 0);
    int64 byte_offset = HARD_QORE_VALUE_INT(args, 1);
    const BinaryNode* b = v.get<const BinaryNode>();
# 96 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    const char* bin_ptr;
    size_t bin_len;
    q_get_data(pattern, bin_ptr, bin_len);

    if (!bin_len) {
        return qore_string_private::emptyNeedleIndex(byte_offset, b->size());
    }
    if (byte_offset < 0) {
        byte_offset = b->size() + byte_offset;
        if (byte_offset < 0) {
            return -1;
        }
    } else if ((size_t)byte_offset >= b->size()) {
        return -1;
    }

    size_t len = b->size() - byte_offset;
    if (!len) {
        return bin_len ? -1 : 0;
    } else if (len < 0) {
        return -1;
    }

    void* ptr = q_memmem(static_cast<const char*>(b->getPtr()) + byte_offset, len, bin_ptr, bin_len);
    if (!ptr) {
        return -1;
    }
    return static_cast<int64>(reinterpret_cast<const char*>(ptr) - reinterpret_cast<const char*>(b->getPtr()));
}

// int PseudoBinary::rfind(data pattern, softint byte_offset = -1) const{}
static QoreValue PseudoBinary_rfind_VDvi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreValue pattern = get_param_value(args, 0);
    int64 byte_offset = HARD_QORE_VALUE_INT(args, 1);
    const BinaryNode* b = v.get<const BinaryNode>();
# 151 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    const char* bin_ptr;
    size_t bin_len;
    q_get_data(pattern, bin_ptr, bin_len);

    if (!bin_len) {
        return qore_string_private::emptyNeedleRindex(byte_offset, b->size());
    }
    if (byte_offset < 0) {
        byte_offset = b->size() + byte_offset;
        if (byte_offset < 0) {
            return -1;
        }
    } else if ((size_t)byte_offset >= b->size()) {
        byte_offset = b->size() - 1;
    }

    assert((size_t)byte_offset < b->size());
    void* ptr = q_memrmem(b->getPtr(), byte_offset + 1, bin_ptr, bin_len);
    if (!ptr) {
        return -1;
    }
    return static_cast<int64>(reinterpret_cast<const char*>(ptr) - reinterpret_cast<const char*>(b->getPtr()));
}

// int PseudoBinary::size() const{}
static QoreValue PseudoBinary_size(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const BinaryNode* b = v.get<const BinaryNode>();
# 69 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    return b->size();
}

// bool PseudoBinary::sizep() const{}
static QoreValue PseudoBinary_sizep(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 675 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    return true;
}

// list<binary> PseudoBinary::split(data separator, bool keep_trailing_empty = False) const{}
static QoreValue PseudoBinary_split_VDVb(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreValue separator = get_param_value(args, 0);
    bool keep_trailing_empty = HARD_QORE_VALUE_BOOL(args, 1);
    const BinaryNode* b = v.get<const BinaryNode>();
# 226 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    const char* bin_ptr;
    size_t bin_len;
    q_get_data(separator, bin_ptr, bin_len);

    return split_intern(bin_ptr, bin_len, (const char*)b->getPtr(), b->size(), nullptr, false, keep_trailing_empty);
}

// binary PseudoBinary::substr(softint start) const{}
static QoreValue PseudoBinary_substr_vi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 start = HARD_QORE_VALUE_INT(args, 0);
    const BinaryNode* b = v.get<const BinaryNode>();
# 618 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    BinaryNode* b1 = new BinaryNode;
   b->substr(*b1, start);
   return b1;
}

// binary PseudoBinary::substr(softint start, softint length) const{}
static QoreValue PseudoBinary_substr_vivi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 start = HARD_QORE_VALUE_INT(args, 0);
    int64 length = HARD_QORE_VALUE_INT(args, 1);
    const BinaryNode* b = v.get<const BinaryNode>();
# 642 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    BinaryNode* b1 = new BinaryNode;
   b->substr(*b1, start, length);
   return b1;
}

// string PseudoBinary::toBase64(softint max_line_length = -1) const{}
static QoreValue PseudoBinary_toBase64_vi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 max_line_length = HARD_QORE_VALUE_INT(args, 0);
    const BinaryNode* b = v.get<const BinaryNode>();
# 573 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    return new QoreStringNode(b, max_line_length);
}

// string PseudoBinary::toBase64Url(softint max_line_length = -1) const{}
static QoreValue PseudoBinary_toBase64Url_vi(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const BinaryNode* b = v.get<const BinaryNode>();
# 595 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    QoreStringNode* rv = new QoreStringNode;
    rv->concatBase64Url(*b);
    return rv;
}

// string PseudoBinary::toHex() const{}
static QoreValue PseudoBinary_toHex(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const BinaryNode* b = v.get<const BinaryNode>();
# 450 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    QoreStringNode *rv = new QoreStringNode;
   rv->concatHex(b);
   return rv;
}

// string PseudoBinary::toHexArray(*string byte_prefix, *string byte_suffix, int bytes_per_line = 0, *string line_separator) const{}
static QoreValue PseudoBinary_toHexArray_NsNsViNs(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreValue qpp_string_value_0 = get_param_value(args, 0);
    QoreStringNodeValueHelper qpp_string_helper_0(qpp_string_value_0);
    const QoreStringNode* byte_prefix = qpp_string_value_0.getType() == NT_STRING ? *qpp_string_helper_0 : nullptr;
    QoreValue qpp_string_value_1 = get_param_value(args, 1);
    QoreStringNodeValueHelper qpp_string_helper_1(qpp_string_value_1);
    const QoreStringNode* byte_suffix = qpp_string_value_1.getType() == NT_STRING ? *qpp_string_helper_1 : nullptr;
    int64 bytes_per_line = HARD_QORE_VALUE_INT(args, 2);
    QoreValue qpp_string_value_3 = get_param_value(args, 3);
    QoreStringNodeValueHelper qpp_string_helper_3(qpp_string_value_3);
    const QoreStringNode* line_separator = qpp_string_value_3.getType() == NT_STRING ? *qpp_string_helper_3 : nullptr;
    const BinaryNode* b = v.get<const BinaryNode>();
# 505 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
        static const char hexdig[] = "0123456789abcdef";

    const size_t size = b->size();
    const unsigned char* src = static_cast<const unsigned char*>(b->getPtr());

    const char* bp = byte_prefix ? byte_prefix->c_str() : "";
    const size_t bp_len = byte_prefix ? byte_prefix->size() : 0;
    const char* bs = byte_suffix ? byte_suffix->c_str() : "";
    const size_t bs_len = byte_suffix ? byte_suffix->size() : 0;
    const char* ls = line_separator ? line_separator->c_str() : (bytes_per_line > 0 ? "\n" : "");
    const size_t ls_len = line_separator ? line_separator->size() : (bytes_per_line > 0 ? 1 : 0);

    // Pre-compute output size to avoid realloc inside the hot loop
    size_t per_byte = bp_len + 2 + bs_len;
    size_t out_size = size * per_byte;
    if (bytes_per_line > 0 && size > 0) {
        size_t line_count = (size - 1) / static_cast<size_t>(bytes_per_line);
        out_size += line_count * ls_len;
    }

    QoreStringNode* rv = new QoreStringNode;
    rv->reserve(out_size + 1);

    const int bpl = bytes_per_line;
    int col = 0;
    for (size_t i = 0; i < size; ++i) {
        if (i && !(i % 100) && qore_check_cancel(xsink, "formatting binary hex array")) {
            return QoreValue();
        }
        if (bpl > 0 && col == bpl) {
            rv->concat(ls, ls_len);
            col = 0;
        }
        if (bp_len) {
            rv->concat(bp, bp_len);
        }
        unsigned char c = src[i];
        char hex[2] = { hexdig[c >> 4], hexdig[c & 0xf] };
        rv->concat(hex, 2);
        if (bs_len) {
            rv->concat(bs, bs_len);
        }
        ++col;
    }
    return rv;
}

// string PseudoBinary::toMD5() const{}
static QoreValue PseudoBinary_toMD5(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const BinaryNode* b = v.get<const BinaryNode>();
# 256 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    DigestHelper dh(*b);
   if (dh.doDigest(MD5_ERR, EVP_md5(), xsink))
      return QoreValue();

   return dh.getString();
}

// string PseudoBinary::toSHA1() const{}
static QoreValue PseudoBinary_toSHA1(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const BinaryNode* b = v.get<const BinaryNode>();
# 284 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    DigestHelper dh(*b);
   if (dh.doDigest(SHA1_ERR, EVP_sha1(), xsink))
      return QoreValue();

   return dh.getString();
}

// string PseudoBinary::toSHA224() const{}
static QoreValue PseudoBinary_toSHA224(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const BinaryNode* b = v.get<const BinaryNode>();
# 315 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    #if !defined(OPENSSL_NO_SHA256) && defined(HAVE_OPENSSL_SHA512)
   DigestHelper dh(*b);
   if (dh.doDigest(SHA224_ERR, EVP_sha224(), xsink))
      return QoreValue();

   return dh.getString();
#else
   missing_openssl_feature("SHA224", xsink);
   return QoreValue();
#endif
    return QoreValue();
}

// string PseudoBinary::toSHA256() const{}
static QoreValue PseudoBinary_toSHA256(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const BinaryNode* b = v.get<const BinaryNode>();
# 351 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    #if !defined(OPENSSL_NO_SHA256) && defined(HAVE_OPENSSL_SHA512)
   DigestHelper dh(*b);
   if (dh.doDigest(SHA256_ERR, EVP_sha256(), xsink))
      return QoreValue();

   return dh.getString();
#else
   missing_openssl_feature("SHA256", xsink);
   return QoreValue();
#endif
    return QoreValue();
}

// string PseudoBinary::toSHA384() const{}
static QoreValue PseudoBinary_toSHA384(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const BinaryNode* b = v.get<const BinaryNode>();
# 387 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    #if !defined(OPENSSL_NO_SHA512) && defined(HAVE_OPENSSL_SHA512)
   DigestHelper dh(*b);
   if (dh.doDigest(SHA384_ERR, EVP_sha384(), xsink))
      return QoreValue();

   return dh.getString();
#else
   missing_openssl_feature("SHA384", xsink);
   return QoreValue();
#endif
    return QoreValue();
}

// string PseudoBinary::toSHA512() const{}
static QoreValue PseudoBinary_toSHA512(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const BinaryNode* b = v.get<const BinaryNode>();
# 423 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    #if !defined(OPENSSL_NO_SHA512) && defined(HAVE_OPENSSL_SHA512)
   DigestHelper dh(*b);
   if (dh.doDigest(SHA512_ERR, EVP_sha512(), xsink))
      return QoreValue();

   return dh.getString();
#else
   missing_openssl_feature("SHA512", xsink);
   return QoreValue();
#endif
    return QoreValue();
}

// string PseudoBinary::toString(*string encoding) const{}
static QoreValue PseudoBinary_toString_Ns(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreValue qpp_string_value_0 = get_param_value(args, 0);
    QoreStringNodeValueHelper qpp_string_helper_0(qpp_string_value_0);
    const QoreStringNode* encoding = qpp_string_value_0.getType() == NT_STRING ? *qpp_string_helper_0 : nullptr;
    const BinaryNode* b = v.get<const BinaryNode>();
# 661 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    const QoreEncoding *qe = encoding ? QEM.findCreate(encoding) : QCS_DEFAULT;
   if (!b->size())
      return new QoreStringNode(qe);
   return new QoreStringNode((const char *)b->getPtr(), b->size(), qe);
}

// int PseudoBinary::typeCode() const{}
static QoreValue PseudoBinary_typeCode(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 54 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    return NT_BINARY;
}

// bool PseudoBinary::val() const{}
static QoreValue PseudoBinary_val(QoreObject* self, const QoreValue& v, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const BinaryNode* b = v.get<const BinaryNode>();
# 204 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/Pseudo_QC_Binary.qpp"
    return !b->empty();
}

DLLLOCAL void preinitPseudoBinaryClass() {
    QC_PSEUDOBINARY = new QoreBuiltinClass("<binary>", "::Qore::<binary>", QDOM_DEFAULT);
    CID_PSEUDOBINARY = QC_PSEUDOBINARY->getID();
    QC_PSEUDOBINARY->setSystem();
}

DLLLOCAL QoreClass* initPseudoBinaryClass() {
    if (!QC_PSEUDOBINARY)
        preinitPseudoBinaryClass();

    // set parent class
    assert(QC_PSEUDOVALUE);
    QC_PSEUDOBINARY->addBuiltinVirtualBaseClass(QC_PSEUDOVALUE);

    // bool PseudoBinary::empty() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 186);
        QC_PSEUDOBINARY->addConstMethod("empty", (q_method_t)PseudoBinary_empty, Public, QCF_CONSTANT, QDOM_DEFAULT, boolTypeInfo);
    }

    // int PseudoBinary::find(data pattern, softint byte_offset = 0) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 96);
        QC_PSEUDOBINARY->addConstMethod("find", (q_method_t)PseudoBinary_find_VDvi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, bigIntTypeInfo, 2, dataTypeInfo, QORE_PARAM_NO_ARG, "pattern", softBigIntTypeInfo, QoreSimpleValue((int64)0), "byte_offset");
    }

    // int PseudoBinary::rfind(data pattern, softint byte_offset = -1) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 151);
        QC_PSEUDOBINARY->addConstMethod("rfind", (q_method_t)PseudoBinary_rfind_VDvi, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, bigIntTypeInfo, 2, dataTypeInfo, QORE_PARAM_NO_ARG, "pattern", softBigIntTypeInfo, QoreSimpleValue((int64)-1), "byte_offset");
    }

    // int PseudoBinary::size() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 69);
        QC_PSEUDOBINARY->addConstMethod("size", (q_method_t)PseudoBinary_size, Public, QCF_CONSTANT, QDOM_DEFAULT, bigIntTypeInfo);
    }

    // bool PseudoBinary::sizep() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 675);
        QC_PSEUDOBINARY->addConstMethod("sizep", (q_method_t)PseudoBinary_sizep, Public, QCF_CONSTANT, QDOM_DEFAULT, boolTypeInfo);
    }

    // list<binary> PseudoBinary::split(data separator, bool keep_trailing_empty = False) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 226);
        QC_PSEUDOBINARY->addConstMethod("split", (q_method_t)PseudoBinary_split_VDVb, Public, QCF_CONSTANT|QCF_NAMED_ARGS, QDOM_DEFAULT, qore_get_complex_list_type(binaryTypeInfo), 2, dataTypeInfo, QORE_PARAM_NO_ARG, "separator", boolTypeInfo, QoreSimpleValue(false), "keep_trailing_empty");
    }

    // binary PseudoBinary::substr(softint start) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 618);
        QC_PSEUDOBINARY->addConstMethod("substr", (q_method_t)PseudoBinary_substr_vi, Public, QCF_CONSTANT|QCF_NAMED_ARGS, QDOM_DEFAULT, binaryTypeInfo, 1, softBigIntTypeInfo, QORE_PARAM_NO_ARG, "start");
    }

    // binary PseudoBinary::substr(softint start, softint length) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 642);
        QC_PSEUDOBINARY->addConstMethod("substr", (q_method_t)PseudoBinary_substr_vivi, Public, QCF_CONSTANT|QCF_NAMED_ARGS, QDOM_DEFAULT, binaryTypeInfo, 2, softBigIntTypeInfo, QORE_PARAM_NO_ARG, "start", softBigIntTypeInfo, QORE_PARAM_NO_ARG, "length");
    }

    // string PseudoBinary::toBase64(softint max_line_length = -1) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 573);
        QC_PSEUDOBINARY->addConstMethod("toBase64", (q_method_t)PseudoBinary_toBase64_vi, Public, QCF_CONSTANT|QCF_NAMED_ARGS, QDOM_DEFAULT, stringTypeInfo, 1, softBigIntTypeInfo, QoreSimpleValue((int64)-1), "max_line_length");
    }

    // string PseudoBinary::toBase64Url(softint max_line_length = -1) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 595);
        QC_PSEUDOBINARY->addConstMethod("toBase64Url", (q_method_t)PseudoBinary_toBase64Url_vi, Public, QCF_CONSTANT|QCF_NAMED_ARGS, QDOM_DEFAULT, stringTypeInfo, 1, softBigIntTypeInfo, QoreSimpleValue((int64)-1), "max_line_length");
    }

    // string PseudoBinary::toHex() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 450);
        QC_PSEUDOBINARY->addConstMethod("toHex", (q_method_t)PseudoBinary_toHex, Public, QCF_CONSTANT, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoBinary::toHexArray(*string byte_prefix, *string byte_suffix, int bytes_per_line = 0, *string line_separator) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 505);
        QC_PSEUDOBINARY->addConstMethod("toHexArray", (q_method_t)PseudoBinary_toHexArray_NsNsViNs, Public, QCF_RET_VALUE_ONLY|QCF_NAMED_ARGS, QDOM_DEFAULT, stringTypeInfo, 4, stringOrNothingTypeInfo, QORE_PARAM_NO_ARG, "byte_prefix", stringOrNothingTypeInfo, QORE_PARAM_NO_ARG, "byte_suffix", bigIntTypeInfo, QoreSimpleValue((int64)0), "bytes_per_line", stringOrNothingTypeInfo, QORE_PARAM_NO_ARG, "line_separator");
    }

    // string PseudoBinary::toMD5() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 256);
        QC_PSEUDOBINARY->addConstMethod("toMD5", (q_method_t)PseudoBinary_toMD5, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoBinary::toSHA1() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 284);
        QC_PSEUDOBINARY->addConstMethod("toSHA1", (q_method_t)PseudoBinary_toSHA1, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoBinary::toSHA224() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 315);
        QC_PSEUDOBINARY->addConstMethod("toSHA224", (q_method_t)PseudoBinary_toSHA224, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoBinary::toSHA256() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 351);
        QC_PSEUDOBINARY->addConstMethod("toSHA256", (q_method_t)PseudoBinary_toSHA256, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoBinary::toSHA384() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 387);
        QC_PSEUDOBINARY->addConstMethod("toSHA384", (q_method_t)PseudoBinary_toSHA384, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoBinary::toSHA512() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 423);
        QC_PSEUDOBINARY->addConstMethod("toSHA512", (q_method_t)PseudoBinary_toSHA512, Public, QCF_RET_VALUE_ONLY, QDOM_DEFAULT, stringTypeInfo);
    }

    // string PseudoBinary::toString(*string encoding) const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 661);
        QC_PSEUDOBINARY->addConstMethod("toString", (q_method_t)PseudoBinary_toString_Ns, Public, QCF_CONSTANT|QCF_NAMED_ARGS, QDOM_DEFAULT, stringTypeInfo, 1, stringOrNothingTypeInfo, QORE_PARAM_NO_ARG, "encoding");
    }

    // int PseudoBinary::typeCode() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 54);
        QC_PSEUDOBINARY->addConstMethod("typeCode", (q_method_t)PseudoBinary_typeCode, Public, QCF_CONSTANT, QDOM_DEFAULT, bigIntTypeInfo);
    }

    // bool PseudoBinary::val() const{}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/Pseudo_QC_Binary.qpp", 204);
        QC_PSEUDOBINARY->addConstMethod("val", (q_method_t)PseudoBinary_val, Public, QCF_CONSTANT, QDOM_DEFAULT, boolTypeInfo);
    }

    return QC_PSEUDOBINARY;
}
