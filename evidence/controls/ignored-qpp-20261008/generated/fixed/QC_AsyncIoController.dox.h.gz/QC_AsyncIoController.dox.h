//! Qore namespace
namespace Qore {
//! Socket polling operation info hash
/** Contains all the information needed to submit an async I/O operation

    @since %Qore 3.0
*/
struct SocketPollOperationInfo {
    //! Force onComplete dispatch even if the C++ auto-detection doesn't find an override
    /** Works around C++/Qore multiple inheritance method resolution order issues where
        findMethod("onComplete") returns the base no-op from the wrong parent class.

        @since %Qore 3.0
    */
    bool has_on_complete = False;
    //! Optional custom cache key; default: sock.uniqueHash()
    /** Allows multiple concurrent operations on the same socket (e.g., concurrent accepts
        on a listener) by using distinct keys like "accept:<hash>:1", "accept:<hash>:2".
    */
    *string key;
    //! Free-form data to be returned when the operation completes
    *hash<auto> other;
    //! Owner identifier for cancellation; required for proper cleanup during shutdown via cancelByOwner()
    string owner;
    //! Last poll info for this operation
    *hash<SocketPollInfo> poll_info;
    //! Optional result Queue; if provided, results will be pushed to this Queue instead of a new one
    /** This allows multiple operations to share a single result Queue for easier coordination.

        If neither a Queue nor an @ref AbstractPollOperation::onComplete() "onComplete()" override
        is provided, a new Queue is created and returned from @ref Qore::AsyncIoController::submit().
    */
    *Queue<hash<SocketPollResultInfo>> resultQueue;
    //! Pollable I/O object (Socket, EventNotifier, or any AbstractPollableIoObjectBase subclass)
    AbstractPollableIoObjectBase sock;
    //! Poll operation
    AbstractPollOperation<?> spop;
    //! Optional I/O thread affinity key; default: key
    /** Allows several operations with distinct cache keys to be routed to the same
        I/O thread for coordinated cancellation and readiness barriers.

        @since %Qore 3.0
    */
    *string thread_key;
    //! I/O timeout; use a negative value to disable timeout (operation will wait indefinitely)
    /** Default: 30 seconds
    */
    timeout to = 30s;
};
}
//! Qore namespace
namespace Qore {
//! Socket poll result info hash
/** Contains the result of a completed async I/O operation

    @since %Qore 3.0
*/
struct SocketPollResultInfo {
    //! If the operation was canceled
    *bool canceled;
    //! Any exception raised while executing the operation
    *hash<ExceptionInfo> ex;
    //! Free-form data provided when the operation was submitted
    *hash<auto> other;
    //! The pollable I/O object that completed the operation
    AbstractPollableIoObjectBase sock;
    //! The poll operation that completed
    AbstractPollOperation<?> spop;
};
}
//! Qore namespace
namespace Qore {
//! Async I/O controller for managing multiple concurrent socket poll operations
/** The AsyncIoController provides a high-performance event loop for managing multiple concurrent
    socket operations. It uses the most efficient I/O mechanism available on each platform
    (epoll on Linux, kqueue on macOS/BSD) via the EventLoop class.

    The controller runs a dedicated I/O thread that processes socket events and drives poll
    operations through their state machines. Operations are submitted via @ref Qore::AsyncIoController::submit(),
    and results are delivered via callback.

    The controller supports:
    - Multiple concurrent operations on different sockets
    - Multiple concurrent operations on the same socket (using custom keys)
    - Cancellation by socket, key, or owner
    - Autostop behavior (I/O thread exits when all operations complete)
    - Wake/force-poll for handling pending writes (HTTP/2)

   @par Restrictions:
    @ref Qore::PO_NO_NETWORK

     @par Thread Safety
    All public methods are thread-safe. The controller uses a single mutex with careful lock
    ordering to avoid deadlocks.

    @par Three-Phase I/O Cycle
    The I/O thread implements a deterministic three-phase polling cycle:
    - Phase 1 (Snapshot under lock): collect operations needing continuePoll()
    - Phase 2 (continuePoll outside lock): drive operations, collect results
    - Phase 3 (Update under lock + deferred delivery): update cache/EventLoop, deliver callbacks

    @note This class is not available with the @ref PO_NO_NETWORK parse option

    @since %Qore 3.0
*/
class AsyncIoController {

public:
//! Creates a new AsyncIoController
/** @par Code Flags:
    @ref NAMED_ARGS

    @par Example:
    @code{.py}
    auto ctrl = AsyncIoController::get();
    @endcode

    @param auto_stop if @ref True "True" (default), the I/O thread will automatically exit when
    all operations have completed; if @ref False "False", the I/O thread will keep running
    until explicitly stopped

    @throw ASYNCIOCONTROLLER-CONSTRUCTOR-ERROR cannot be instantiated directly; use
    static methods instead
*/
 constructor(bool auto_stop = True);

public:
//! Creates a copy of the AsyncIoController
/** @throw ASYNCIOCONTROLLER-COPY-ERROR AsyncIoController cannot be copied; use
    AsyncIoController::get() to obtain the singleton
*/
 copy();

public:
//! Destroys the AsyncIoController
/** The singleton is cleaned up during qore_cleanup(); this destructor handles the
    final dereference of the private data.
*/
 destructor();

public:
//! Adds a timer on the global singleton
/** When \a user_data is a closure or call-reference, the runtime automatically dispatches
    it to a worker thread in the async-I/O controller's dispatcher pool when the
    deadline fires — it is @b not invoked on the I/O thread, so it may block, acquire
    locks, or perform Qore-level I/O.

    For non-callable \a user_data (numbers, strings, hashes, …), the value is passed to
    the timer callback registered via @ref setTimerCallback() (also dispatched to a
    worker thread).  With no callback installed, non-callable \a user_data is silently
    dropped.

   @par Restrictions:
    @ref Qore::PO_NO_NETWORK, @ref Qore::PO_NO_PROCESS_CONTROL

@par Code Flags:
    @ref NAMED_ARGS

     @param deadline the absolute deadline for the timer
    @param user_data either a closure/call-reference to dispatch, or arbitrary user data
        to deliver through the @ref setTimerCallback() handler
    @return the unique timer ID
    @since %Qore 3.0
*/
static int addTimer(date deadline, auto user_data);

public:
//! Adds an owner-tagged timer on the global singleton
/** Identical to @ref addTimer(date, auto) but tags the timer's callback dispatch with \a owner, so a
    teardown path can deterministically drain a fired-but-not-yet-run callback via
    @ref flushCallbacksByOwner() (in addition to cancelling not-yet-fired timers with @ref cancelTimer()).
    This closes the teardown race where a timer fires, its callback is dispatched to a worker, and the
    owning object is destroyed before the callback runs.

   @par Restrictions:
    @ref Qore::PO_NO_NETWORK, @ref Qore::PO_NO_PROCESS_CONTROL

     @param deadline the absolute deadline for the timer
    @param udata either a closure/call-reference to dispatch, or arbitrary user data
        to deliver through the @ref setTimerCallback() handler
    @param owner the owner identifier to tag the timer's callback dispatch with
    @return the unique timer ID
    @since %Qore 3.0
*/
static int addTimer(date deadline, auto udata, string owner);

public:
//! Cancels an operation by socket on the global singleton
/** @par Code Flags:
    @ref NAMED_ARGS

    @param io_object the I/O object whose operation should be canceled
    @return @ref True "True" if an operation was found and canceled
    @since %Qore 3.0
*/
static bool cancel(AbstractPollableIoObjectBase io_object);

public:
//! Cancels an operation by I/O object and closes it
/** Cancels the poll operation associated with the given I/O object, then shuts down
    and closes it via closeIo(). This is the proper way to tear down a connection whose
    lifecycle is managed by the async I/O controller.

   @par Code Flags:
    @ref NAMED_ARGS

     @param io_object the I/O object whose operation should be canceled and then closed
    @return @ref True "True" if an operation was found and canceled

    @since %Qore 3.0
*/
static bool cancelAndClose(AbstractPollableIoObjectBase io_object);

public:
//! Cancels an operation by key on the global singleton
/** @par Code Flags:
    @ref NAMED_ARGS

    @param key the operation key to cancel
    @return @ref True "True" if an operation was found and canceled
    @since %Qore 3.0
*/
static bool cancelByKey(string key);

public:
//! Cancels all operations for an owner on the global singleton
/** @par Code Flags:
    @ref NAMED_ARGS

    @param owner the owner identifier whose operations should be canceled
    @return the number of operations canceled
    @since %Qore 3.0
*/
static int cancelByOwner(string owner);

public:
//! Cancels a timer on the global singleton
/** @par Restrictions:
    @ref Qore::PO_NO_NETWORK, @ref Qore::PO_NO_PROCESS_CONTROL

@par Code Flags:
    @ref NAMED_ARGS

    @param timer_id the timer ID returned by @ref addTimer()
    @return @ref True "True" if the timer was found and canceled
    @since %Qore 3.0
*/
static bool cancelTimer(int timer_id);

public:
//! Executes an async I/O operation on the global singleton and waits for its result
/** This is the blocking companion to @ref Qore::AsyncIoController::submit(). It uses the controller event loop
    for the actual I/O operation, then waits on the operation's result Queue.

   @par Code Flags:
    @ref NAMED_ARGS

     @param operation_info the operation info hash
    @param replace_existing if @ref True "True", cancel any existing operation with the same key

    @return the operation result hash

    @throw ASYNC-IO-ERROR if the controller is shutting down, the info hash is invalid,
    or the operation uses an @ref AbstractPollOperation::onComplete() "onComplete()"
    callback, or if called from the async I/O thread

    @since %Qore 3.0
*/
static hash<SocketPollResultInfo> exec(hash<SocketPollOperationInfo> operation_info, __7_ bool replace_existing);

public:
//! Waits for all pending onComplete/abort callbacks to be processed
/** Call after cancelByOwner() to ensure all cancelled operation callbacks
    have been delivered before stopping thread pools that depend on them.

    This prevents shutdown deadlocks where a ThreadPool.stop() blocks
    waiting for handler threads that are waiting for onComplete() to
    signal their done counter.

    @since %Qore 3.0
*/
static nothing flushCallbacks();

public:
//! Waits for in-flight callbacks tagged with the given owner to drain
/** Narrowed-scope companion to @ref flushCallbacks() that only waits for
    callbacks whose operations were submitted with the matching @a owner.
    Safe to call from a per-owner teardown path (e.g. a connection manager's
    destructor) where the global flush would deadlock on unrelated long-running
    work on the shared controller.

    Marks the owner as shutting down for the duration of the wait: any callback
    picked up by a worker while the mark is set is silently discarded instead
    of dispatched to user code.  The mark is cleared before return, so later
    submits by a new object reusing the owner string are unaffected.

   @par Code Flags:
    @ref NAMED_ARGS

     @param owner the owner identifier to wait for

    @since %Qore 3.0
*/
static nothing flushCallbacksByOwner(string owner);

public:
//! Returns the autostop flag from the global singleton
/** @return @ref True "True" if autostop is enabled
    @since %Qore 3.0
*/
static bool getAutostop();

public:
//! Returns the number of cached operations on the global singleton
/** @return the number of active operations in the cache
    @since %Qore 3.0
*/
static int getCacheSize();

public:
//! Returns info about the global singleton's state
/** @return a hash with controller state information
    @since %Qore 3.0
*/
static hash<auto> getInfo();

public:
//! Returns true if the global singleton's I/O thread is running
/** @return @ref True "True" if the I/O thread is running
    @since %Qore 3.0
*/
static bool running();

public:
//! Sets the autostop flag on the global singleton
/** @par Code Flags:
    @ref NAMED_ARGS

    @param auto_stop if @ref True "True", the I/O thread will exit when all operations complete
    @since %Qore 3.0
*/
static nothing setAutostop(bool auto_stop = True);

public:
//! Sets the logger on the global singleton
/** @par Code Flags:
    @ref NAMED_ARGS

    @param logger a @ref Qore::LoggerInterfaceBase "LoggerInterfaceBase" object for logging,
    or @ref nothing "NOTHING" to disable per-controller logging
    @since %Qore 3.0
*/
static nothing setLogger(__7_ LoggerInterfaceBase logger);

public:
//! Sets the maximum number of callback dispatcher worker threads on the global singleton
/** Controls the concurrency of user callback dispatch off the I/O thread.

    The default is @code{.py}hardware_concurrency() * 4@endcode, capped at 512 and falling
    back to 4 if the hardware thread count is unavailable.

    Takes effect when the dispatcher or submitTask() pool is next created.

   @par Restrictions:
    @ref Qore::PO_NO_NETWORK, @ref Qore::PO_NO_PROCESS_CONTROL

@par Code Flags:
    @ref NAMED_ARGS

     @param max_workers the maximum number of workers; 0 = auto (hardware_concurrency() * 4,
    capped at 512, fallback 4)

    @since %Qore 3.0
*/
static nothing setMaxCallbackWorkers(int max_workers = 0);

public:
//! Sets the number of I/O threads for the global async I/O controller
/** @par Restrictions:
    @ref Qore::PO_NO_NETWORK, @ref Qore::PO_NO_PROCESS_CONTROL

@par Code Flags:
    @ref NAMED_ARGS

    @param max_threads the maximum number of I/O threads (0 = auto-detect from hardware_concurrency)

    Multiple I/O threads enable nginx-style per-thread connection isolation,
    scaling throughput near-linearly with core count for high connection counts.

    Must be called before the first submit() or from Qore startup code.

    @since %Qore 3.0
*/
static nothing setMaxIoThreads(int max_threads = 0);

public:
//! Sets the timer callback on the global singleton
/** The callback is invoked once per fire of a timer whose \c user_data is @b not a closure or
    call-reference (those are auto-dispatched directly; see @ref addTimer()).  The runtime
    dispatches the callback to a worker thread in the async-I/O controller's dispatcher
    pool — it is @b not invoked on the I/O thread.

   @par Restrictions:
    @ref Qore::PO_NO_NETWORK, @ref Qore::PO_NO_PROCESS_CONTROL

@par Code Flags:
    @ref NAMED_ARGS

     @param callback a callback that accepts a @ref TimerEventInfo hash argument, or
        @ref nothing to disable timer event delivery for non-callable \c user_data

    @since %Qore 3.0
*/
static nothing setTimerCallback(__7_ code callback);

public:
//! Submits an async I/O operation to the global singleton
/** @par Code Flags:
    @ref NAMED_ARGS

    @par Example:
    @code{.py}
    *Queue<hash<SocketPollResultInfo>> q =
        AsyncIoController::submit(operation_info: {"sock": sock, "spop": op, "owner": "server"});
    hash<SocketPollResultInfo> result = q.get();
    @endcode

    @param operation_info the operation info hash
    @param replace_existing if @ref True "True", cancel any existing operation with the same key

    @return a Queue object for receiving the result, or @ref nothing if a callback was provided
    in the info hash

    @throw ASYNC-IO-ERROR if the controller is shutting down or the info hash is invalid

    @since %Qore 3.0
*/
static __7_ Queue<hash<SocketPollResultInfo>> submit(hash<SocketPollOperationInfo> operation_info, __7_ bool replace_existing);

public:
//! Submits a task to the global singleton's thread pool
/** @par Restrictions:
    @ref Qore::PO_NO_NETWORK, @ref Qore::PO_NO_PROCESS_CONTROL

@par Code Flags:
    @ref NAMED_ARGS

    @param task the @ref closure "closure" or @ref call_reference "call reference" to execute
    @param cancel_callback an optional @ref closure "closure" or @ref call_reference "call reference"
    to execute if the pool is stopped before the task can be executed

    @throw ASYNC-IO-ERROR if the controller's thread pool has been stopped

    @since %Qore 3.0
*/
static nothing submitTask(code<nothing()> task, __7_ code<nothing()> cancel_callback);

public:
//! Waits until the global singleton has processed all currently submitted operations
/** @par Code Flags:
    @ref NAMED_ARGS

    @param timeout_ms timeout for waiting; use 0 to wait indefinitely
    @return @ref True "True" if all submitted operations have been processed

    @throw ASYNC-IO-ERROR if called from an async I/O controller I/O thread

    @since %Qore 3.0
*/
static bool waitForProcessing(__7_ timeout timeout_ms);

public:
//! Waits for the global singleton's I/O thread to be ready
/** @par Code Flags:
    @ref NAMED_ARGS

    @param timeout_ms timeout for waiting; use 0 to wait indefinitely
    @return @ref True "True" if the I/O thread is ready within the timeout
    @since %Qore 3.0
*/
static bool waitReady(__7_ timeout timeout_ms);

public:
//! Wakes the I/O thread for a specific socket with pending data
/** Enqueues a targeted re-poll command for the given socket. The I/O thread
    includes that socket's operation in the next poll cycle regardless of
    EventLoop socket readiness, allowing queued send data to be transmitted.

   @par Code Flags:
    @ref NAMED_ARGS

     @param io_object the I/O object whose operation needs re-polling

    @since %Qore 3.0
*/
static nothing wakeSocket(AbstractPollableIoObjectBase io_object);
};
}
