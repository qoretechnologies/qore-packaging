/* -*- mode: c++; indent-tabs-mode: nil -*- */
/*
    QC_AsyncIoController.qpp

    Qore Programming Language

    Copyright (C) 2003 - 2026 Qore Technologies, s.r.o.

    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the "Software"),
    to deal in the Software without restriction, including without limitation
    the rights to use, copy, modify, merge, publish, distribute, sublicense,
    and/or sell copies of the Software, and to permit persons to whom the
    Software is furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.

    Note that the Qore library is released under a choice of three open-source
    licenses: MIT (as above), LGPL 2+, or GPL 2+; see README-LICENSE for more
    information.
*/

#include <qore/Qore.h>
#include <qore/QoreSocketObject.h>
#include "qore/intern/AsyncIoControllerPriv.h"
#include "qore/intern/QC_Socket.h"

extern qore_classid_t CID_QUEUE;
extern qore_classid_t CID_ASYNCIOCONTROLLER;
extern QoreClass* QC_QUEUE;

// Helper: get the singleton's priv data and QoreObject (both ref'd); caller must deref both
static AsyncIoControllerPriv* get_singleton(QoreObject*& obj, ExceptionSink* xsink) {
    obj = qore_get_async_io_controller_obj(xsink);
    if (!obj) {
        return nullptr;
    }
    AsyncIoControllerPriv* ctrl = static_cast<AsyncIoControllerPriv*>(
        obj->getReferencedPrivateData(CID_ASYNCIOCONTROLLER, xsink));
    if (!ctrl) {
        obj->deref(xsink);
        obj = nullptr;
        return nullptr;
    }
    return ctrl;
}
TypedHashDecl* init_hashdecl_SocketPollOperationInfo(QoreNamespace& ns) {
    std::string hd_path = ns.getPath(true);
    if (hd_path == "::") {
        hd_path.clear();
    } else if (!hd_path.empty()) {
        hd_path += "::";
    }
    hd_path += "SocketPollOperationInfo";
    if (hd_path.rfind("::", 0) != 0) {
        hd_path.insert(0, "::");
    }
    TypedHashDecl* hd = new TypedHashDecl("SocketPollOperationInfo", hd_path.c_str());
    hd->addMember("has_on_complete", boolTypeInfo, QoreValue(false));
    hd->addMember("key", stringOrNothingTypeInfo, QoreValue());
    hd->addMember("other", autoHashOrNothingTypeInfo, QoreValue());
    hd->addMember("owner", stringTypeInfo, QoreValue());
    hd->addMember("poll_info", hashdeclSocketPollInfo->getTypeInfo(true), QoreValue());
    hd->addMember("resultQueue", QC_QUEUE->getTypeInfo([&]() { type_vec_t qpp_type_args; qpp_type_args.push_back(hashdeclSocketPollResultInfo->getTypeInfo(false)); return qpp_type_args; }(), true), QoreValue());
    hd->addMember("sock", QC_ABSTRACTPOLLABLEIOOBJECTBASE->getTypeInfo(), QoreValue());
    hd->addMember("spop", QC_ABSTRACTPOLLOPERATION->getTypeInfo([&]() { type_vec_t qpp_type_args; qpp_type_args.push_back(qore_get_wildcard_type()); return qpp_type_args; }(), false), QoreValue());
    hd->addMember("thread_key", stringOrNothingTypeInfo, QoreValue());
    hd->addMember("to", timeoutTypeInfo, QoreValue(DateTimeNode::makeRelative(0, 0, 0, 0, 0, 30, 0)));
    ns.addSystemHashDecl(hd);
    return hd;
}

TypedHashDecl* init_hashdecl_SocketPollResultInfo(QoreNamespace& ns) {
    std::string hd_path = ns.getPath(true);
    if (hd_path == "::") {
        hd_path.clear();
    } else if (!hd_path.empty()) {
        hd_path += "::";
    }
    hd_path += "SocketPollResultInfo";
    if (hd_path.rfind("::", 0) != 0) {
        hd_path.insert(0, "::");
    }
    TypedHashDecl* hd = new TypedHashDecl("SocketPollResultInfo", hd_path.c_str());
    hd->addMember("canceled", boolOrNothingTypeInfo, QoreValue());
    hd->addMember("ex", hashdeclExceptionInfo->getTypeInfo(true), QoreValue());
    hd->addMember("other", autoHashOrNothingTypeInfo, QoreValue());
    hd->addMember("sock", QC_ABSTRACTPOLLABLEIOOBJECTBASE->getTypeInfo(), QoreValue());
    hd->addMember("spop", QC_ABSTRACTPOLLOPERATION->getTypeInfo([&]() { type_vec_t qpp_type_args; qpp_type_args.push_back(qore_get_wildcard_type()); return qpp_type_args; }(), false), QoreValue());
    ns.addSystemHashDecl(hd);
    return hd;
}

/* Qore class Qore::AsyncIoController */

qore_classid_t CID_ASYNCIOCONTROLLER;
QoreClass* QC_ASYNCIOCONTROLLER;

// AsyncIoController::constructor(bool auto_stop = True) {}
static void AsyncIoController_constructor_Vb(QoreObject* self, const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 182 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
xsink->raiseException("ASYNCIOCONTROLLER-CONSTRUCTOR-ERROR",
        "AsyncIoController cannot be instantiated; use static methods");
}

// AsyncIoController::copy() {}
static void AsyncIoController_copy(QoreObject* self, QoreObject* old, AsyncIoControllerPriv* ctrl, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 199 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
xsink->raiseException("ASYNCIOCONTROLLER-COPY-ERROR",
        "AsyncIoController cannot be copied; use AsyncIoController::get()");
}

// AsyncIoController::destructor() {}
static void AsyncIoController_destructor(QoreObject* self, AsyncIoControllerPriv* ctrl, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 191 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
ctrl->deref(xsink);
}

// static int AsyncIoController::addTimer(date deadline, auto user_data){}
static QoreValue static_AsyncIoController_addTimer_VdVA(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const DateTimeNode* deadline = HARD_QORE_VALUE_DATE(args, 0);
    QoreValue user_data = get_param_value(args, 1);
# 553 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return 0;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->addTimer(deadline, user_data, xsink);
}

// static int AsyncIoController::addTimer(date deadline, auto udata, string owner){}
static QoreValue static_AsyncIoController_addTimer_VdVAVs(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const DateTimeNode* deadline = HARD_QORE_VALUE_DATE(args, 0);
    QoreValue udata = get_param_value(args, 1);
    QoreStringNodeValueHelper qpp_string_helper_2(get_hard_value_param(args, 2));
    const QoreStringNode* owner = *qpp_string_helper_2;
# 578 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return 0;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->addTimer(deadline, udata, xsink, owner->c_str());
}

// static bool AsyncIoController::cancel(AbstractPollableIoObjectBase io_object){}
static QoreValue static_AsyncIoController_cancel_C28AbstractPollableIoObjectBase(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    HARD_QORE_VALUE_OBJ_DATA(io_object, AbstractPollableIoObjectBase, args, 0, CID_ABSTRACTPOLLABLEIOOBJECTBASE, "AsyncIoController::cancel()", "AbstractPollableIoObjectBase", xsink);
    if (*xsink)
        return 0;
# 272 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
    QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return false;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->cancel(*io_object, xsink);
}

// static bool AsyncIoController::cancelAndClose(AbstractPollableIoObjectBase io_object){}
static QoreValue static_AsyncIoController_cancelAndClose_C28AbstractPollableIoObjectBase(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    HARD_QORE_VALUE_OBJ_DATA(io_object, AbstractPollableIoObjectBase, args, 0, CID_ABSTRACTPOLLABLEIOOBJECTBASE, "AsyncIoController::cancelAndClose()", "AbstractPollableIoObjectBase", xsink);
    if (*xsink)
        return 0;
# 294 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
    QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return false;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->cancelAndClose(*io_object, xsink);
}

// static bool AsyncIoController::cancelByKey(string key){}
static QoreValue static_AsyncIoController_cancelByKey_Vs(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* key = *qpp_string_helper_0;
# 310 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return false;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->cancelByKey(key, xsink);
}

// static int AsyncIoController::cancelByOwner(string owner){}
static QoreValue static_AsyncIoController_cancelByOwner_Vs(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* owner = *qpp_string_helper_0;
# 326 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return 0;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->cancelByOwner(owner, xsink);
}

// static bool AsyncIoController::cancelTimer(int timer_id){}
static QoreValue static_AsyncIoController_cancelTimer_Vi(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 timer_id = HARD_QORE_VALUE_INT(args, 0);
# 594 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return false;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->cancelTimer(timer_id, xsink);
}

// static hash<SocketPollResultInfo> AsyncIoController::exec(hash<SocketPollOperationInfo> operation_info, *bool replace_existing){}
static QoreValue static_AsyncIoController_exec_C29hash_SocketPollOperationInfo_Nb(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreHashNode* operation_info = HARD_QORE_VALUE_HASH(args, 0);
    bool replace_existing = HARD_QORE_VALUE_BOOL(args, 1);
# 255 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
    QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->exec(obj, operation_info->hashRefSelf(), replace_existing, xsink);
}

// static nothing AsyncIoController::flushCallbacks(){}
static QoreValue static_AsyncIoController_flushCallbacks(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 372 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    ctrl->flushCallbacks();
    return QoreValue();
}

// static nothing AsyncIoController::flushCallbacksByOwner(string owner){}
static QoreValue static_AsyncIoController_flushCallbacksByOwner_Vs(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    QoreStringNodeValueHelper qpp_string_helper_0(get_hard_value_param(args, 0));
    const QoreStringNode* owner = *qpp_string_helper_0;
# 399 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    ctrl->flushCallbacksByOwner(std::string(owner->c_str()));
    return QoreValue();
}

// static bool AsyncIoController::getAutostop(){}
static QoreValue static_AsyncIoController_getAutostop(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 494 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return false;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->getAutostop();
}

// static int AsyncIoController::getCacheSize(){}
static QoreValue static_AsyncIoController_getCacheSize(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 464 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return 0;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->getCacheSize();
}

// static hash<auto> AsyncIoController::getInfo(){}
static QoreValue static_AsyncIoController_getInfo(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 509 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->getInfo(xsink);
}

// static bool AsyncIoController::running(){}
static QoreValue static_AsyncIoController_running(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
# 449 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return false;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->running();
}

// static nothing AsyncIoController::setAutostop(bool auto_stop = True){}
static QoreValue static_AsyncIoController_setAutostop_Vb(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    bool auto_stop = HARD_QORE_VALUE_BOOL(args, 0);
# 479 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    ctrl->setAutostop(auto_stop);
    return QoreValue();
}

// static nothing AsyncIoController::setLogger(*LoggerInterfaceBase logger){}
static QoreValue static_AsyncIoController_setLogger_C20_LoggerInterfaceBase(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreObject* logger = get_param_value(args, 0).get<const QoreObject>();
# 525 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    ctrl->setLogger(const_cast<QoreObject*>(logger), xsink);
    return QoreValue();
}

// static nothing AsyncIoController::setMaxCallbackWorkers(int max_workers = 0){}
static QoreValue static_AsyncIoController_setMaxCallbackWorkers_Vi(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 max_workers = HARD_QORE_VALUE_INT(args, 0);
# 662 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
    QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    ctrl->setMaxCallbackWorkers((int)max_workers);
    return QoreValue();
}

// static nothing AsyncIoController::setMaxIoThreads(int max_threads = 0){}
static QoreValue static_AsyncIoController_setMaxIoThreads_Vi(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 max_threads = HARD_QORE_VALUE_INT(args, 0);
# 683 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    ctrl->setMaxIoThreads((int)max_threads, xsink);
    return QoreValue();
}

// static nothing AsyncIoController::setTimerCallback(*code callback){}
static QoreValue static_AsyncIoController_setTimerCallback_Nc(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const ResolvedCallReferenceNode* callback = get_param_value(args, 0).get<const ResolvedCallReferenceNode>();
# 616 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    ctrl->setTimerCallback(callback ? callback->refRefSelf() : nullptr, xsink);
    return QoreValue();
}

// static *Queue<hash<SocketPollResultInfo>> AsyncIoController::submit(hash<SocketPollOperationInfo> operation_info, *bool replace_existing){}
static QoreValue static_AsyncIoController_submit_C29hash_SocketPollOperationInfo_Nb(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const QoreHashNode* operation_info = HARD_QORE_VALUE_HASH(args, 0);
    bool replace_existing = HARD_QORE_VALUE_BOOL(args, 1);
# 224 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
    QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    // submit() takes ownership of `operation_info` (see the ReferenceHolder in
    // AsyncIoControllerPriv::submit that plugs the per-call leak); our
    // QPP-generated caller still owns its own ref on the method arg, so
    // hand submit() an explicit self-ref via hashRefSelf().
    return ctrl->submit(obj, operation_info->hashRefSelf(), replace_existing, xsink);
}

// static nothing AsyncIoController::submitTask(code<nothing()> task, *code<nothing()> cancel_callback){}
static QoreValue static_AsyncIoController_submitTask_C15code_nothing___C16_code_nothing___(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    const ResolvedCallReferenceNode* task = get_param_value(args, 0).get<const ResolvedCallReferenceNode>();
    const ResolvedCallReferenceNode* cancel_callback = get_param_value(args, 1).get<const ResolvedCallReferenceNode>();
# 637 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
    QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    ctrl->submitTask(task->refRefSelf(), cancel_callback ? cancel_callback->refRefSelf() : nullptr, xsink);
    return QoreValue();
}

// static bool AsyncIoController::waitForProcessing(*timeout timeout_ms){}
static QoreValue static_AsyncIoController_waitForProcessing_Nt(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 timeout_ms = HARD_QORE_VALUE_INT(args, 0);
# 434 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return false;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->waitForProcessing(timeout_ms, xsink);
}

// static bool AsyncIoController::waitReady(*timeout timeout_ms){}
static QoreValue static_AsyncIoController_waitReady_Nt(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    int64 timeout_ms = HARD_QORE_VALUE_INT(args, 0);
# 415 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return false;
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    return ctrl->waitReady(timeout_ms, xsink);
}

// static nothing AsyncIoController::wakeSocket(AbstractPollableIoObjectBase io_object){}
static QoreValue static_AsyncIoController_wakeSocket_C28AbstractPollableIoObjectBase(const QoreListNode* args, RuntimeConfig& runtime_cfg, ExceptionSink* xsink) {
    HARD_QORE_VALUE_OBJ_DATA(io_object, AbstractPollableIoObjectBase, args, 0, CID_ABSTRACTPOLLABLEIOOBJECTBASE, "AsyncIoController::wakeSocket()", "AbstractPollableIoObjectBase", xsink);
    if (*xsink)
        return 0;
# 347 "/home/david/src/qore/git/qore-packaging/results/ignored-qpp-final-20261008/host-release/test/fixed/QC_AsyncIoController.qpp"
    QoreObject* obj;
    AsyncIoControllerPriv* ctrl = get_singleton(obj, xsink);
    if (!ctrl) {
        return QoreValue();
    }
    ReferenceHolder<AsyncIoControllerPriv> ctrl_holder(ctrl, xsink);
    ReferenceHolder<QoreObject> obj_holder(obj, xsink);
    // Use QoreObject unique hash — the private data pointer
    // (AbstractPollableIoObjectBase*) can change during QUIC handshake when
    // the socket is reconfigured, causing hash mismatches with the cache key.
    // The QoreObject unique hash is stable across the connection lifecycle.
    ctrl->wakeSocketByObject(const_cast<QoreObject*>(obj_io_object), xsink);
    return QoreValue();
}

DLLLOCAL void preinitAsyncIoControllerClass() {
    QC_ASYNCIOCONTROLLER = new QoreBuiltinClass("AsyncIoController", "::Qore::AsyncIoController", QDOM_NETWORK);
    CID_ASYNCIOCONTROLLER = QC_ASYNCIOCONTROLLER->getID();
    QC_ASYNCIOCONTROLLER->setSystem();
}

DLLLOCAL QoreClass* initAsyncIoControllerClass(QoreNamespace& ns) {
    if (!QC_ASYNCIOCONTROLLER)
        preinitAsyncIoControllerClass();

    // AsyncIoController::constructor(bool auto_stop = True) {}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 182);
        QC_ASYNCIOCONTROLLER->addConstructor(AsyncIoController_constructor_Vb, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, 1, boolTypeInfo, QoreSimpleValue(true), "auto_stop");
    }

    // AsyncIoController::copy() {}
    QC_ASYNCIOCONTROLLER->setCopy((q_copy_t)AsyncIoController_copy);

    // AsyncIoController::destructor() {}
    QC_ASYNCIOCONTROLLER->setDestructor((q_destructor_t)AsyncIoController_destructor);

    // static int AsyncIoController::addTimer(date deadline, auto user_data){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 553);
        QC_ASYNCIOCONTROLLER->addStaticMethod("addTimer", (q_func_t)static_AsyncIoController_addTimer_VdVA, Public, QCF_NAMED_ARGS, QDOM_NETWORK|QDOM_PROCESS, bigIntTypeInfo, 2, dateTypeInfo, QORE_PARAM_NO_ARG, "deadline", autoTypeInfo, QORE_PARAM_NO_ARG, "user_data");
    }

    // static int AsyncIoController::addTimer(date deadline, auto udata, string owner){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 578);
        QC_ASYNCIOCONTROLLER->addStaticMethod("addTimer", (q_func_t)static_AsyncIoController_addTimer_VdVAVs, Public, QCF_NO_FLAGS, QDOM_NETWORK|QDOM_PROCESS, bigIntTypeInfo, 3, dateTypeInfo, QORE_PARAM_NO_ARG, "deadline", autoTypeInfo, QORE_PARAM_NO_ARG, "udata", stringTypeInfo, QORE_PARAM_NO_ARG, "owner");
    }

    // static bool AsyncIoController::cancel(AbstractPollableIoObjectBase io_object){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 272);
        QC_ASYNCIOCONTROLLER->addStaticMethod("cancel", (q_func_t)static_AsyncIoController_cancel_C28AbstractPollableIoObjectBase, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, QC_ABSTRACTPOLLABLEIOOBJECTBASE->getTypeInfo(), QORE_PARAM_NO_ARG, "io_object");
    }

    // static bool AsyncIoController::cancelAndClose(AbstractPollableIoObjectBase io_object){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 294);
        QC_ASYNCIOCONTROLLER->addStaticMethod("cancelAndClose", (q_func_t)static_AsyncIoController_cancelAndClose_C28AbstractPollableIoObjectBase, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, QC_ABSTRACTPOLLABLEIOOBJECTBASE->getTypeInfo(), QORE_PARAM_NO_ARG, "io_object");
    }

    // static bool AsyncIoController::cancelByKey(string key){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 310);
        QC_ASYNCIOCONTROLLER->addStaticMethod("cancelByKey", (q_func_t)static_AsyncIoController_cancelByKey_Vs, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, stringTypeInfo, QORE_PARAM_NO_ARG, "key");
    }

    // static int AsyncIoController::cancelByOwner(string owner){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 326);
        QC_ASYNCIOCONTROLLER->addStaticMethod("cancelByOwner", (q_func_t)static_AsyncIoController_cancelByOwner_Vs, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, bigIntTypeInfo, 1, stringTypeInfo, QORE_PARAM_NO_ARG, "owner");
    }

    // static bool AsyncIoController::cancelTimer(int timer_id){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 594);
        QC_ASYNCIOCONTROLLER->addStaticMethod("cancelTimer", (q_func_t)static_AsyncIoController_cancelTimer_Vi, Public, QCF_NAMED_ARGS, QDOM_NETWORK|QDOM_PROCESS, boolTypeInfo, 1, bigIntTypeInfo, QORE_PARAM_NO_ARG, "timer_id");
    }

    // static hash<SocketPollResultInfo> AsyncIoController::exec(hash<SocketPollOperationInfo> operation_info, *bool replace_existing){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 255);
        QC_ASYNCIOCONTROLLER->addStaticMethod("exec", (q_func_t)static_AsyncIoController_exec_C29hash_SocketPollOperationInfo_Nb, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, hashdeclSocketPollResultInfo->getTypeInfo(false), 2, hashdeclSocketPollOperationInfo->getTypeInfo(false), QORE_PARAM_NO_ARG, "operation_info", boolOrNothingTypeInfo, QORE_PARAM_NO_ARG, "replace_existing");
    }

    // static nothing AsyncIoController::flushCallbacks(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 372);
        QC_ASYNCIOCONTROLLER->addStaticMethod("flushCallbacks", (q_func_t)static_AsyncIoController_flushCallbacks, Public, QCF_NO_FLAGS, QDOM_DEFAULT, nothingTypeInfo);
    }

    // static nothing AsyncIoController::flushCallbacksByOwner(string owner){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 399);
        QC_ASYNCIOCONTROLLER->addStaticMethod("flushCallbacksByOwner", (q_func_t)static_AsyncIoController_flushCallbacksByOwner_Vs, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, nothingTypeInfo, 1, stringTypeInfo, QORE_PARAM_NO_ARG, "owner");
    }

    // static bool AsyncIoController::getAutostop(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 494);
        QC_ASYNCIOCONTROLLER->addStaticMethod("getAutostop", (q_func_t)static_AsyncIoController_getAutostop, Public, QCF_NO_FLAGS, QDOM_DEFAULT, boolTypeInfo);
    }

    // static int AsyncIoController::getCacheSize(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 464);
        QC_ASYNCIOCONTROLLER->addStaticMethod("getCacheSize", (q_func_t)static_AsyncIoController_getCacheSize, Public, QCF_NO_FLAGS, QDOM_DEFAULT, bigIntTypeInfo);
    }

    // static hash<auto> AsyncIoController::getInfo(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 509);
        QC_ASYNCIOCONTROLLER->addStaticMethod("getInfo", (q_func_t)static_AsyncIoController_getInfo, Public, QCF_NO_FLAGS, QDOM_DEFAULT, autoHashTypeInfo);
    }

    // static bool AsyncIoController::running(){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 449);
        QC_ASYNCIOCONTROLLER->addStaticMethod("running", (q_func_t)static_AsyncIoController_running, Public, QCF_NO_FLAGS, QDOM_DEFAULT, boolTypeInfo);
    }

    // static nothing AsyncIoController::setAutostop(bool auto_stop = True){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 479);
        QC_ASYNCIOCONTROLLER->addStaticMethod("setAutostop", (q_func_t)static_AsyncIoController_setAutostop_Vb, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, nothingTypeInfo, 1, boolTypeInfo, QoreSimpleValue(true), "auto_stop");
    }

    // static nothing AsyncIoController::setLogger(*LoggerInterfaceBase logger){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 525);
        QC_ASYNCIOCONTROLLER->addStaticMethod("setLogger", (q_func_t)static_AsyncIoController_setLogger_C20_LoggerInterfaceBase, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, nothingTypeInfo, 1, QC_LOGGERINTERFACEBASE->getOrNothingTypeInfo(), QORE_PARAM_NO_ARG, "logger");
    }

    // static nothing AsyncIoController::setMaxCallbackWorkers(int max_workers = 0){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 662);
        QC_ASYNCIOCONTROLLER->addStaticMethod("setMaxCallbackWorkers", (q_func_t)static_AsyncIoController_setMaxCallbackWorkers_Vi, Public, QCF_NAMED_ARGS, QDOM_NETWORK|QDOM_PROCESS, nothingTypeInfo, 1, bigIntTypeInfo, QoreSimpleValue((int64)0), "max_workers");
    }

    // static nothing AsyncIoController::setMaxIoThreads(int max_threads = 0){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 683);
        QC_ASYNCIOCONTROLLER->addStaticMethod("setMaxIoThreads", (q_func_t)static_AsyncIoController_setMaxIoThreads_Vi, Public, QCF_NAMED_ARGS, QDOM_NETWORK|QDOM_PROCESS, nothingTypeInfo, 1, bigIntTypeInfo, QoreSimpleValue((int64)0), "max_threads");
    }

    // static nothing AsyncIoController::setTimerCallback(*code callback){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 616);
        QC_ASYNCIOCONTROLLER->addStaticMethod("setTimerCallback", (q_func_t)static_AsyncIoController_setTimerCallback_Nc, Public, QCF_NAMED_ARGS, QDOM_NETWORK|QDOM_PROCESS, nothingTypeInfo, 1, codeOrNothingTypeInfo, QORE_PARAM_NO_ARG, "callback");
    }

    // static *Queue<hash<SocketPollResultInfo>> AsyncIoController::submit(hash<SocketPollOperationInfo> operation_info, *bool replace_existing){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 224);
        QC_ASYNCIOCONTROLLER->addStaticMethod("submit", (q_func_t)static_AsyncIoController_submit_C29hash_SocketPollOperationInfo_Nb, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, QC_QUEUE->getTypeInfo([&]() { type_vec_t qpp_type_args; qpp_type_args.push_back(hashdeclSocketPollResultInfo->getTypeInfo(false)); return qpp_type_args; }(), true), 2, hashdeclSocketPollOperationInfo->getTypeInfo(false), QORE_PARAM_NO_ARG, "operation_info", boolOrNothingTypeInfo, QORE_PARAM_NO_ARG, "replace_existing");
    }

    // static nothing AsyncIoController::submitTask(code<nothing()> task, *code<nothing()> cancel_callback){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 637);
        QC_ASYNCIOCONTROLLER->addStaticMethod("submitTask", (q_func_t)static_AsyncIoController_submitTask_C15code_nothing___C16_code_nothing___, Public, QCF_NAMED_ARGS, QDOM_NETWORK|QDOM_PROCESS, nothingTypeInfo, 2, qore_get_complex_code_type(nothingTypeInfo, [&]() { type_vec_t v; return v; }(), false), QORE_PARAM_NO_ARG, "task", qore_get_complex_code_or_nothing_type(nothingTypeInfo, [&]() { type_vec_t v; return v; }(), false), QORE_PARAM_NO_ARG, "cancel_callback");
    }

    // static bool AsyncIoController::waitForProcessing(*timeout timeout_ms){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 434);
        QC_ASYNCIOCONTROLLER->addStaticMethod("waitForProcessing", (q_func_t)static_AsyncIoController_waitForProcessing_Nt, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, timeoutOrNothingTypeInfo, QORE_PARAM_NO_ARG, "timeout_ms");
    }

    // static bool AsyncIoController::waitReady(*timeout timeout_ms){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 415);
        QC_ASYNCIOCONTROLLER->addStaticMethod("waitReady", (q_func_t)static_AsyncIoController_waitReady_Nt, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, boolTypeInfo, 1, timeoutOrNothingTypeInfo, QORE_PARAM_NO_ARG, "timeout_ms");
    }

    // static nothing AsyncIoController::wakeSocket(AbstractPollableIoObjectBase io_object){}
    {
        QoreBuiltinSrcLocHelper _qpp_src_loc_h("/fixture/QC_AsyncIoController.qpp", 347);
        QC_ASYNCIOCONTROLLER->addStaticMethod("wakeSocket", (q_func_t)static_AsyncIoController_wakeSocket_C28AbstractPollableIoObjectBase, Public, QCF_NAMED_ARGS, QDOM_DEFAULT, nothingTypeInfo, 1, QC_ABSTRACTPOLLABLEIOOBJECTBASE->getTypeInfo(), QORE_PARAM_NO_ARG, "io_object");
    }

    return QC_ASYNCIOCONTROLLER;
}
