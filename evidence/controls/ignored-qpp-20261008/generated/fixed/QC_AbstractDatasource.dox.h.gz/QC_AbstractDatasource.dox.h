//! Qore namespace
namespace Qore {
//! SQL namespace
namespace SQL {
//! This class defines an abstract interface for database access, inherited by both the Datasource and DatasourcePool classes
/**@par Restrictions:
    @ref Qore::PO_NO_DATABASE

*/
class AbstractDatasource {

public:
//! Manually signals the start of transaction management on the AbstractDatasource
/** This method should be called when the AbstractDatasource object will be shared between more than 1 thread, and a transaction will be started with a AbstractDatasource::select() method or the like.

    This method does not make any communication with the server to start a transaction; it only allocates the transaction lock to the current thread in %Qore.

    @par Example:
    @code{.py}
db.beginTransaction();
    @endcode
 */
abstract nothing beginTransaction();

public:
//! Starts a driver-native bulk-load operation
/** This is the low-level protocol used by BulkSqlUtil for explicitly requested native bulk inserts.

   @par Code Flags:
    @ref NAMED_ARGS

     @param table the SQL-rendered target table name
    @param columns SQL-rendered target column names in row-hash order
    @param options optional driver-specific options
    @return @ref True when started; @ref False when the mechanism is dynamically unavailable
    @throw ABSTRACT-DATASOURCE-ERROR this method was not implemented by the concrete datasource subclass

    @since %Qore 3.0
*/
bool bulkLoadBegin(string table, list<string> columns, __7_ hash<auto> options);

public:
//! Ends an active driver-native bulk-load operation
/** @param success @ref True to finish normally; @ref False to abort
    @throw ABSTRACT-DATASOURCE-ERROR this method was not implemented by the concrete datasource subclass

    @since %Qore 3.0
*/
nothing bulkLoadEnd(bool success);

public:
//! Sends one block to an active driver-native bulk-load operation
/** @param rows a hash of column lists or scalar constants
    @throw ABSTRACT-DATASOURCE-ERROR this method was not implemented by the concrete datasource subclass

    @since %Qore 3.0
*/
nothing bulkLoadRows(hash<auto> rows);

public:
//! Removes any registered mutation observer from the object
/** @note this method must be re-implemented in subclasses of AbstractDatasource; it is implemented in
    @ref Qore::SQL::Datasource "Datasource" and @ref Qore::SQL::DatasourcePool "DatasourcePool"

    @see setMutationObserver()

    @since %Qore 3.0
*/
nothing clearMutationObserver();

public:
//! Commits the current transaction and releases any thread resources associated with the transaction
/**@par Example:
    @code{.py}
db.commit();
    @endcode
 */
abstract nothing commit();

public:
//! Should return @ref True "True" if the current thread is in a transaction with this object, must be re-implemented in subclasses to provide the desired functionality
/** @note
    - this is reimplemented as @ref Qore::SQL::Datasource::currentThreadInTransaction() "Datasource::currentThreadInTransaction()" and @ref Qore::SQL::DatasourcePool::currentThreadInTransaction() "DatasourcePool::currentThreadInTransaction()"
    - this method was added as a non-abstract method in Qore 0.8.10 to avoid breaking existing subclasses of AbstractDatasource

    @since Qore 0.8.10
 */
bool currentThreadInTransaction();

public:
//! Executes an %SQL command on the server and returns either the integer row count (for example, for updates, inserts, and deletes) or the data retrieved (for example, if a stored procedure is executed that returns values)
/** @param sql The %SQL command to execute on the server
    @param ... Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder specifications (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return The return value depends on the DBI driver; normally, for commands with placeholders, a hash is returned holding the values acquired from executing the %SQL statement. For all other commands, normally an integer row count is returned. However, some DBI drivers also allow select statements to be executed through this interface, which would also return a hash (column names) of lists (values for each column).

    @par Example:
    @code{.py}
int rows = db.exec("insert into table (varchar_col, timestamp_col, blob_col, numeric_col) values (%v, %v, %v, %d)", string, now(), binary, 100);
    @endcode
 */
abstract auto exec(string sql,  ...);

public:
//! Executes an %SQL command on the server and returns either the row count (for example, for updates and inserts) or the data retrieved (for example, if a stored procedure is executed that returns values)
/** This method does not do any variable binding, so it's useful for example for DDL statements etc

   @par Code Flags:
    @ref NAMED_ARGS

     @par Warning:
    Using this method to execute pure dynamic %SQL many times with different %SQL strings (as opposed to using the same string and binding by value instead of dynamic %SQL) can affect application performance by prohibiting the efficient usage of the DB server's statement cache. See DB server documentation for variable binding and the %SQL statement cache for more information.

    @param sql The %SQL command to execute on the server; this string will not be subjected to any transformations for variable binding

    @return The return value depends on the DBI driver; normally, for commands with placeholders, a hash is returned holding the values acquired from executing the %SQL statement. For all other commands, normally an integer row count is returned. However, some DBI drivers also allow select statements to be executed through this interface, which would also return a hash (column names) of lists (values for each column).

    @par Example:
    @code{.py}
db.execRaw("create table my_tab (id number, some_text varchar2(30))");
    @endcode
 */
abstract auto execRaw(string sql);

public:
//! Returns an integer bitfield of DBI driver capabilities
/** @return an integer bitfield of DBI driver capabilities; see @ref dbi_capabilities for the meaning of each bit

   @par Code Flags:
    @ref RET_VALUE_ONLY

     @par Example:
    @code{.py}
int caps = db.getCapabilities();
if (!(caps & DBI_CAP_TRANSACTION_MANAGEMENT))
    throw "DATASOURCE-ERROR", sprintf("DBI driver %y does not support transaction management", db.getDriverName());
    @endcode

    @note
    - this is reimplemented as @ref Qore::SQL::Datasource::getCapabilities() "Datasource::getCapabilities()" and
      @ref Qore::SQL::DatasourcePool::getCapabilities() "DatasourcePool::getCapabilities()"
    - this method was added as a non-abstract method in %Qore 3.0 to avoid breaking existing subclasses of
      AbstractDatasource

    @since %Qore 3.0
*/
int getCapabilities();

public:
//! Retrieves the driver-specific client library version information
/** @return the driver-specific client library version information

    @par Example:
    @code{.py}
auto ver = db.getClientVersion();
    @endcode

    @note see the documentation for the DBI driver being used for possible exceptions
 */
abstract auto getClientVersion();

public:
//! Returns a @ref datasource_hash "datasource hash" describing the configuration of the current object
/** @par Example:
    @code{.py}
hash<auto> h = ds.getConfigHash();
    @endcode

    @return a @ref datasource_hash "datasource hash" describing the configuration of the current object

    @since %Qore 0.8.8
 */
abstract hash<auto> getConfigHash();

public:
//! Returns a string giving the configuration of the current object in a format that can be parsed by parse_datasource()
/** @par Example:
    @code{.py}
string str = ds.getConfigString();
    @endcode

    @return a string giving the configuration of the current object in a format that can be parsed by parse_datasource()

    @since %Qore 0.8.8
 */
abstract string getConfigString();

public:
//! Retrieves the database-specific charset set encoding for the object
/** @return the database-specific charset set encoding for the object

    @par Example:
    @code{.py}
*string enc = db.getDBEncoding();
    @endcode

    @see AbstractDatasource::getOSEncoding();
*/
abstract __7_ string getDBEncoding();

public:
//! Returns the database name parameter as a string or @ref nothing if none is set
/** @return the database name parameter as a string or @ref nothing if none is set

    @par Example:
    @code{.py}
*string db = db.getDBName();
    @endcode
*/
abstract __7_ string getDBName();

public:
//! Returns the name of the driver used for the object
/** @return the name of the driver used for the object

    @par Example:
    @code{.py}
string driver = db.getDriverName();
    @endcode

    @see getDriverRealName()
 */
abstract string getDriverName();

public:
//! Returns the real DB driver name if supported by the driver, otherwise the %Qore driver name
/** @return the real DB driver name if supported by the driver, otherwise the %Qore driver name

    @par Example:
    @code{.py}
*string db = db.getDriverRealName();
    @endcode

    By default this base class method returns @ref getDriverName(); override in subclasses to modify this behavior

    @see getDriverName()

    @since %Qore 1.14
*/
string getDriverRealName();

public:
//! Returns the hostname parameter as a string or @ref nothing if none is set
/** @return the hostname parameter as a string or @ref nothing if none is set

    @par Example:
    @code{.py}
*string host = db.getHostName();
    @endcode
 */
abstract __7_ string getHostName();

public:
//! Returns the innermost mutation declaration for the current thread, if any
/** @par Code Flags:
    @ref RET_VALUE_ONLY

@note this base class method always returns @ref nothing

    @see pushMutationDeclaration()

    @since %Qore 3.0
*/
__7_ hash<SqlMutationInfo> getMutationDeclaration();

public:
//! Returns the %Qore character encoding name for the object as a string or @ref nothing if none is set
/** @return the %Qore character encoding name for the object as a string or @ref nothing if none is set

    @par Example:
    @code{.py}
*string enc = db.getOSEncoding();
    @endcode
 */
abstract __7_ string getOSEncoding();

public:
//! Returns the current value for the given option
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @param option the option to get
    @return the value of the option

    @note This base class method always throws an exception

    @since %Qore 0.9.4
*/
auto getOption(string option);

public:
//! Returns the valid options for the driver associated with the AbstractDatasource with descriptions and current values for the current AbstractDatasource object
/** @par Code Flags:
    @ref RET_VALUE_ONLY

@return a hash where the keys are valid option names, and the values are hashes with the following keys:
    - \c "desc": a string description of the option
    - \c "type": a string giving the data type restriction for the option
    - \c "value": the current value of the option

    @note this base class method always returns an empty hash

    @since %Qore 0.9.4
 */
hash<auto> getOptionHash();

public:
//! Returns the password parameter as a string or @ref nothing if none is set
/** @return the password parameter as a string or @ref nothing if none is set

    @par Example:
    @code{.py}
*string pass = db.getPassword();
    @endcode
 */
abstract __7_ string getPassword();

public:
//! Gets the port number that will be used for the next connection to the server
/** Invalid port numbers will cause an exception to be thrown when the connection is opened

    @par Example:
    @code{.py}
*int port = db.getPort();
    @endcode
 */
abstract __7_ int getPort();

public:
//! Returns an @ref Qore::SQL::AbstractSQLStatement "AbstractSQLStatement" object based on the current database connection object
/** @note
    - this is reimplemented as @ref Qore::SQL::Datasource::getSQLStatement() "Datasource::getSQLStatement()" and
      @ref Qore::SQL::DatasourcePool::getSQLStatement() "DatasourcePool::getSQLStatement()"
    - this method was added as a non-abstract method in Qore 0.9.0 to avoid breaking existing subclasses of
      AbstractDatasource

    @since Qore 0.9.0
*/
AbstractSQLStatement getSQLStatement();

public:
//! Returns the driver-specific server version data for the current connection
/** @return the driver-specific server version data for the current connection

    @par Example:
    @code{.py}
auto ver = db.getServerVersion();
    @endcode

    @note see the documentation for the DBI driver being used for additional possible exceptions
 */
abstract auto getServerVersion();

public:
//! Returns the username parameter as a string or @ref nothing if none is set
/** @return the username parameter as a string or @ref nothing if none is set

    @par Example:
    @code{.py}
*string user = db.getUserName();
    @endcode
 */
abstract __7_ string getUserName();

public:
//! Returns @ref True "True" if a mutation observer is registered on the object
/** @par Code Flags:
    @ref RET_VALUE_ONLY

@note this base class method always returns @ref False "False"

    @see setMutationObserver()

    @since %Qore 3.0
*/
bool hasMutationObserver();

public:
//! Returns @ref True if a transaction is currently in progress
/** @return @ref True if a transaction is currently in progress

    @par Example:
    @code{.py}
bool b = db.inTransaction();
    @endcode
 */
abstract bool inTransaction();

public:
//! Removes the innermost mutation declaration for the current thread
/** @throw SQL-MUTATION-DECLARATION-ERROR there is no active declaration in this thread to remove

    @note this method must be re-implemented in subclasses of AbstractDatasource; it is implemented in
    @ref Qore::SQL::Datasource "Datasource" and @ref Qore::SQL::DatasourcePool "DatasourcePool"

    @see pushMutationDeclaration()

    @since %Qore 3.0
*/
nothing popMutationDeclaration();

public:
//! Pushes producer-declared mutation metadata for the current thread
/** Prefer @ref Qore::SQL::SqlMutationDeclaration "SqlMutationDeclaration", which removes the
    declaration deterministically when it goes out of scope.

    Declarations nest; the innermost declaration in the calling thread is the one reported to the
    observer.  Every call must be matched by a call to popMutationDeclaration().

   @par Code Flags:
    @ref NAMED_ARGS

     @param info the declaration; see @ref Qore::SQL::SqlMutationInfo "SqlMutationInfo" for the
    structural rules enforced

    @throw SQL-MUTATION-DECLARATION-ERROR the declaration is invalid; nothing was pushed

    @note this method must be re-implemented in subclasses of AbstractDatasource; it is implemented in
    @ref Qore::SQL::Datasource "Datasource" and @ref Qore::SQL::DatasourcePool "DatasourcePool"

    @since %Qore 3.0
*/
nothing pushMutationDeclaration(hash<SqlMutationInfo> info);

public:
//! Reports the start of a bounded stream to the mutation observer
/** %Qore never sees or buffers the stream payload; only byte counts are propagated.  This method is
    for producers of bulk or \c COPY streams; DBI drivers use the equivalent C++ API.

   @par Code Flags:
    @ref NAMED_ARGS

     @param declared_bytes the declared size of the stream in bytes; if <= 0 then the
    \c "max_growth_bytes" value of the current declaration is used, if any

    @return @ref True "True" to continue streaming

    @note the observer can reject the stream, in which case an exception is thrown

    @since %Qore 3.0
*/
bool reportMutationStreamBegin(int declared_bytes = 0);

public:
//! Reports the end of a bounded stream to the mutation observer
/** @par Code Flags:
    @ref NAMED_ARGS

    @param consumed_bytes the total number of bytes consumed by the stream
    @param ok @ref False "False" if the stream failed

    @return @ref True "True"; stream end is a notification and cannot be rejected

    @since %Qore 3.0
*/
bool reportMutationStreamEnd(int consumed_bytes, bool ok = True);

public:
//! Reports bounded stream progress to the mutation observer
/** @par Code Flags:
    @ref NAMED_ARGS

    @param consumed_bytes the total number of bytes consumed by the stream so far

    @return @ref True "True" to continue streaming

    @note the observer can stop the stream, in which case an exception is thrown

    @since %Qore 3.0
*/
bool reportMutationStreamProgress(int consumed_bytes);

public:
//! Rolls the current transaction back and releases any thread resources associated with the transaction
/**@par Example:
    @code{.py}
db.rollback();
    @endcode
 */
abstract nothing rollback();

public:
//! Executes an %SQL select statement on the server and (normally) returns the result as a hash (column names) of lists (column values per row)
/** The usual return format of this method is suitable for use with @ref context "context statements", for easy iteration and processing of query results.
    Alternatively, the HashListIterator class can be used to iterate the return value of this method.

    Additionally, this format is a more efficient format than that returned by the AbstractDatasource::selectRows() method, because the column names are not repeated for each row returned. Therefore, for retrieving anything greater than small amounts of data, it is recommended to use this method instead of AbstractDatasource::selectRows().

    To execute select statements that begin a transaction (such as \c "select for update"), execute AbstractDatasource::beginTransaction() first to signal that a transaction is starting;
    this is particularly important when the object is shared among more than one thread.

    @param sql The %SQL command to execute on the server
    @param ... Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder specifications (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return This method returns a hash (the keys are the column names) of lists (the column data per row) when executed with an %SQL select statement, however some DBI drivers allow any %SQL to be executed through this method, in which case other data types can be returned (such as an integer for a row count or a hash for output parameters when executing a stored procedure).  If no rows are found, a hash of column names assigned to empty lists is returned.

    @par Example:
    @code{.py}
# bind a string and a date/time value by value in a query
hash<auto> query = db.select("select * from table where varchar_column = %v and timestamp_column > %v", string, 2007-10-11T15:31:26.289);
if (query.firstValue())
    printf("got results\n");
    @endcode

    @note This method returns all the data available immediately; to process query data piecewise, use the SQLStatement class
 */
abstract auto select(string sql,  ...);

public:
//! Executes an %SQL select statement and returns a columnar result
/** Implementations can return a @ref Qore::SQL::ColumnarResult "ColumnarResult" optimized for column-oriented
    consumers such as DataFrame. The base implementation keeps existing AbstractDatasource subclasses source-compatible
    by calling AbstractDatasource::vselect() and converting a column hash or row list result.

   @par Code Flags:
    @ref RET_VALUE_ONLY

     @param sql The %SQL command to execute on the server
    @param ... Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder specifications
    (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return a ColumnarResult object

    @par Example:
    @code{.py}
ColumnarResult result = db.selectColumnar("select id, name from customer where status = %v", "active");
buffer<int64> ids = result.getColumn("id");
    @endcode

    @since %Qore 3.0
 */
ColumnarResult selectColumnar(string sql,  ...);

public:
//! Executes an %SQL select statement on the server and returns the first row as a hash (the column values)
/** If more than one row is returned, then it is treated as an error and a \c DBI-SELECT-ROW-ERROR is returned (however the DBI driver should raise its own exception here to avoid retrieving more than one row from the server). For a similar method taking a list for all bind arguments, see AbstractDatasource::vselectRow().

    This method also accepts all bind parameters (<tt>%%d</tt>, <tt>%%v</tt>, etc) as documented in @ref sql_binding "Binding by Value and Placeholder"

    To execute select statements that begin a transaction (such as \c "select for update"), execute AbstractDatasource::beginTransaction() first to signal that a transaction is starting;
    this is particularly important when the object is shared among more than one thread.

    @param sql The %SQL command to execute on the server
    @param ... Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder specifications (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return This method normally returns a hash (the keys are the column names) of row data or @ref nothing if no row is found for the query when executed with an %SQL select statement, however some DBI drivers allow any %SQL statement to be executed through this method (not only select statements), in this case other data types can be returned

    @par Example:
    @code{.py}
*list<auto> h = db.selectRow("select * from example_table where id = 1");
    @endcode

    @throw DBI-SELECT-ROW-ERROR more than 1 row retrieved from the server
 */
abstract auto selectRow(string sql,  ...);

public:
//! Executes an %SQL select statement on the server and returns the result as a list (rows) of hashes (the column values)
/** The return format of this method is not as memory efficient as that returned by the AbstractDatasource::select() method, therefore for larger amounts of data, it is recommended to use AbstractDatasource::select().
    The usual return value of this method can be iterated with the ListHashIterator class.

    This method also accepts all bind parameters (<tt>%%d</tt>, <tt>%%v</tt>, etc) as documented in @ref sql_binding "Binding by Value and Placeholder"

    To execute select statements that begin a transaction (such as \c "select for update"), execute AbstractDatasource::beginTransaction() first to signal that a transaction is starting;
    this is particularly important when the object is shared among more than one thread.

    @param sql The %SQL command to execute on the server
    @param ... Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder specifications (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return Normally returns a list (rows) of hash (where the keys are the column names of each row) or @ref nothing if no rows are found for the query, however some DBI drivers allow any %SQL statement to be executed through this method (not only select statements), in this case other data types can be returned

    @par Example:
    @code{.py}
*list<auto> list = db.selectRows("select * from example_table");
    @endcode

    @see AbstractDatasource::select()

    @note This method returns all the data available immediately; to process query data piecewise, use the SQLStatement class
 */
abstract auto selectRows(string sql,  ...);

public:
//! Executes an %SQL select statement and returns typed row hashes
/** Implementations return a list whose entries are hashdecl-backed row hashes when the statement returns a normal row
    result. See Datasource::selectRowsTyped() and DatasourcePool::selectRowsTyped() for concrete behavior.

    @param sql The %SQL command to execute on the server
    @param ... Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder specifications
    (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return Normally returns a list of typed row hashes, or another driver-specific value for non-result-set statements

    @par Example:
    @code{.py}
list<auto> rows = db.selectRowsTyped("select id, name from customer where status = %v", "active");
printf("%d\n", rows[0].id);
    @endcode

    @since %Qore 3.0
 */
abstract auto selectRowsTyped(string sql,  ...);

public:
//! Executes an %SQL select statement and returns a typed column-oriented result
/** Implementations return hashdecl-backed column hashes with typed column containers when the statement returns a
    normal result set. See Datasource::selectTyped() and DatasourcePool::selectTyped() for concrete behavior.

    @param sql The %SQL command to execute on the server
    @param ... Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder specifications
    (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return Normally returns a typed column result hash, or another driver-specific value for non-result-set statements

    @par Example:
    @code{.py}
hash<auto> result = db.selectTyped("select id, name from customer where status = %v", "active");
buffer<int64> ids = result.id;
    @endcode

    @since %Qore 3.0
 */
abstract auto selectTyped(string sql,  ...);

public:
//! Registers an opt-in structured mutation observer on the object
/** @par Code Flags:
    @ref NAMED_ARGS

    @par Example:
    @code{.py}
ds.setMutationObserver(\admission.event(), SQL_MUTATION_MASK_DEFAULT, tenant_id);
    @endcode

    @param observer the callback to invoke; it is called with a single
    @ref Qore::SQL::SqlMutationEventInfo "SqlMutationEventInfo" argument and may return a
    @ref Qore::SQL::SqlMutationDecisionInfo "SqlMutationDecisionInfo" hash
    @param event_mask the bitmask of event classes to deliver; see @ref sql_mutation_masks
    @param arg an argument reported unchanged in the \c "arg" key of every event

    @par Observer Semantics
    @anchor sql_mutation_admission
    @parblock
    @ref Qore::SQL::SQL_MUTATION_EVENT_PRE_EXEC "SQL_MUTATION_EVENT_PRE_EXEC",
    @ref Qore::SQL::SQL_MUTATION_EVENT_STREAM_BEGIN "SQL_MUTATION_EVENT_STREAM_BEGIN", and
    @ref Qore::SQL::SQL_MUTATION_EVENT_STREAM_PROGRESS "SQL_MUTATION_EVENT_STREAM_PROGRESS" are
    <b>admission points</b>; every other event is a notification.

    At an admission point:
    - returning @ref nothing, or a hash with \c "admit" set to @ref True "True", admits the operation;
    - returning a hash with \c "admit" set to @ref False "False" rejects it: %Qore raises the given
      \c "err" and \c "desc" (defaulting to \c SQL-MUTATION-REJECTED), does not execute the
      operation, and does not change the transaction state;
    - an exception thrown by the observer propagates and the operation is not executed.  Admission
      is fail-closed by design.

    Every rejected admission point - whether rejected by an \c "admit" @ref False "False" decision or
    by a fail-closed observer exception - is followed by exactly one terminal notification carrying
    @ref Qore::SQL::SQL_MUTATION_OUTCOME_NOT_EXECUTED "SQL_MUTATION_OUTCOME_NOT_EXECUTED" and
    \c "replay_safe" @ref True "True", so that an observer tracking operations by \c "op_id" always
    sees the operation's lifetime close.  This matters most when nothing else would report one: a
    rejection outside a transaction is followed by no rollback, so no
    @ref Qore::SQL::SQL_MUTATION_EVENT_OUTCOME "SQL_MUTATION_EVENT_OUTCOME" event is ever emitted.

    @htmlonly <style><!-- td.qore { background-color: #5b9409; color: white; } --></style> @endhtmlonly
    <table>
    <tr>
        <td class="qore"><b>Rejected at</b></td>
        <td class="qore"><b>Terminal event</b></td>
    </tr>
    <tr>
        <td>\c SQL_MUTATION_EVENT_PRE_EXEC</td>
        <td>\c SQL_MUTATION_EVENT_POST_EXEC, pairing the admission event</td>
    </tr>
    <tr>
        <td>\c SQL_MUTATION_EVENT_STREAM_BEGIN</td>
        <td>\c SQL_MUTATION_EVENT_STREAM_END; the producer never started         the stream, so it reports no end boundary of its own</td>
    </tr>
    <tr>
        <td>\c SQL_MUTATION_EVENT_STREAM_PROGRESS</td>
        <td>\c SQL_MUTATION_EVENT_STREAM_END, reported by the producer         of the stream it stopped</td>
    </tr>
    </table>

    The terminal event reports the rejection exception in its \c "ex" key without consuming it, and
    it cannot re-enter the callback that produced the rejection.

    At a notification event:
    - the return value is ignored;
    - an exception thrown by the observer is raised <b>after</b> the real outcome has been
      determined and applied.  The database outcome, the transaction state, and the value returned
      to the caller are unaffected.  In particular an observer that throws while handling
      @ref Qore::SQL::SQL_MUTATION_OUTCOME_COMMIT_AMBIGUOUS "SQL_MUTATION_OUTCOME_COMMIT_AMBIGUOUS"
      does not turn that outcome into a rollback.

    Operations issued from inside an observer callback do not generate events, so an observer may
    query the same object without recursing.
    @endparblock

    @note
    - %Qore performs no classification of %SQL text, database error text, or command tags; all
      semantic metadata comes from the producer through
      @ref Qore::SQL::SqlMutationDeclaration "SqlMutationDeclaration"
    - observer registration is scoped to this object; there is no process-global registry
    - this method must be re-implemented in subclasses of AbstractDatasource; it is implemented in
      @ref Qore::SQL::Datasource "Datasource" and @ref Qore::SQL::DatasourcePool "DatasourcePool"
    - this method was added as a non-abstract method in %Qore 3.0 to avoid breaking existing
      subclasses of AbstractDatasource

    @see
    - @ref Qore::SQL::SqlMutationDeclaration "SqlMutationDeclaration"
    - clearMutationObserver()

    @since %Qore 3.0
*/
nothing setMutationObserver(code<__7_ hash<SqlMutationDecisionInfo>(hash<SqlMutationEventInfo>)> observer, int event_mask = SQL_MUTATION_MASK_DEFAULT, auto arg);

public:
//! Executes an %SQL command on the server and returns either the integer row count (for example, for updates, inserts, and deletes) or the data retrieved (for example, if a stored procedure is executed that returns values), taking a list for all bind arguments
/** Same as AbstractDatasource::exec() except takes an explicit list for bind arguments

   @par Code Flags:
    @ref NAMED_ARGS

     @param sql The %SQL command to execute on the server
    @param arguments Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder specifications (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return The return value depends on the DBI driver; normally, for commands with placeholders, a hash is returned holding the values acquired from executing the %SQL statement. For all other commands, normally an integer row count is returned. However, some DBI drivers also allow select statements to be executed through this interface, which would also return a hash (column names) of lists (values for each column).

    @par Example:
    @code{.py}
int rows = db.vexec("insert into example_table value (%v, %v, %v)", arg_list);
    @endcode
 */
abstract auto vexec(string sql, __7_ softlist<auto> arguments);

public:
//! Executes a select statement on the server and returns the results in a hash (column names) of lists (column values per row), taking a list for all bind arguments
/** The usual return format of this method is suitable for use with @ref context "context statements", for easy iteration and processing of query results.
    Alternatively, the HashListIterator class can be used to iterate the return value of this method.

    This method also accepts all bind parameters (<tt>%%d</tt>, <tt>%%v</tt>, etc) as documented in @ref sql_binding "Binding by Value and Placeholder"

    To execute select statements that begin a transaction (such as \c "select for update"), execute AbstractDatasource::beginTransaction() first to signal that a transaction is starting;
    this is particularly important when the object is shared among more than one thread.

   @par Code Flags:
    @ref NAMED_ARGS

     @param sql The %SQL command to execute on the server
    @param arguments Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder specifications (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return Normally returns a hash (the keys are the column names) of list (each hash key's value is a list giving the row data), however some DBI drivers allow any %SQL statement to be executed through this method (not only select statements), in this case other data types can be returned.  If no rows are found, a hash of column names assigned to empty lists is returned.

    @par Example:
    @code{.py}
hash<auto> query = db.vselect("select * from example_table where id = %v and name = %v", arg_list);
if (query.firstValue())
    printf("got results\n");
    @endcode

    @see AbstractDatasource::select()

    @note This method returns all the data available immediately; to process query data piecewise, use the SQLStatement class
 */
abstract auto vselect(string sql, __7_ softlist<auto> arguments);

public:
//! Executes a select statement and returns a columnar result, taking a list for all bind arguments
/** This method is the same as AbstractDatasource::selectColumnar(), except this method takes a single argument after
    the %SQL command giving the list of bind value parameters.

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param sql The %SQL command to execute on the server
    @param arguments Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder
    specifications (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return a ColumnarResult object

    @see AbstractDatasource::selectColumnar()

    @since %Qore 3.0
 */
ColumnarResult vselectColumnar(string sql, __7_ softlist<auto> arguments);

public:
//! Executes a select statement on the server and returns the first row as a hash (column names and values), taking a list for all bind arguments
/** This method is the same as the AbstractDatasource::selectRow() method, except this method takes a single argument after the %SQL command giving the list of bind value parameters

    This method also accepts all bind parameters (<tt>%%d</tt>, <tt>%%v</tt>, etc) as documented in @ref sql_binding "Binding by Value and Placeholder"

    To execute select statements that begin a transaction (such as \c "select for update"), execute AbstractDatasource::beginTransaction() first to signal that a transaction is starting;
    this is particularly important when the object is shared among more than one thread.

   @par Code Flags:
    @ref NAMED_ARGS

     @param sql The %SQL command to execute on the server
    @param arguments Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder specifications (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return This method normally returns a hash (the keys are the column names) of row data or @ref nothing if no row is found for the query when executed with an %SQL select statement, however some DBI drivers allow any %SQL statement to be executed through this method (not only select statements), in this case other data types can be returned

    @par Example:
    @code{.py}
*hash<auto> h = db.vselectRow("select * from example_table where id = %v and type = %v", arg_list);
    @endcode

    @see AbstractDatasource::selectRow()
 */
abstract auto vselectRow(string sql, __7_ softlist<auto> arguments);

public:
//! Executes a select statement on the server and returns the results in a list (rows) of hashes (column names and values), taking a list for all bind arguments
/** Same as the AbstractDatasource::selectRows() method, except this method takes a single argument after the %SQL command giving the list of bind value parameters.

    The usual return value of this method can be iterated with the ListHashIterator class.

    The return format of this method is not as memory efficient as that returned by the AbstractDatasource::select() method, therefore for larger amounts of data, it is recommended to use AbstractDatasource::select().

    This method also accepts all bind parameters (<tt>%%d</tt>, <tt>%%v</tt>, etc) as documented in @ref sql_binding "Binding by Value and Placeholder"

    To execute select statements that begin a transaction (such as \c "select for update"), execute AbstractDatasource::beginTransaction() first to signal that a transaction is starting;
    this is particularly important when the object is shared among more than one thread.

   @par Code Flags:
    @ref NAMED_ARGS

     @param sql The %SQL command to execute
    @param arguments Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder specifications (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return Normally returns a list (rows) of hash (where the keys are the column names of each row) or @ref nothing if no rows are found for the query, however some DBI drivers allow any %SQL statement to be executed through this method (not only select statements), in this case other data types can be returned

    @par Example:
    @code{.py}
*list<auto> list = db.vselectRows("select * from example_table where id = %v and type = %v", arg_list);
    @endcode

    @see AbstractDatasource::selectRows()

    @note This method returns all the data available immediately; to process query data piecewise, use the SQLStatement class
 */
abstract auto vselectRows(string sql, __7_ softlist<auto> arguments);

public:
//! Executes a select statement and returns typed row hashes, taking a list for all bind arguments
/** This method is the same as AbstractDatasource::selectRowsTyped(), except this method takes a single argument after
    the %SQL command giving the list of bind value parameters.

   @par Code Flags:
    @ref NAMED_ARGS

     @param sql The %SQL command to execute
    @param arguments Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder
    specifications (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return Normally returns a list of typed row hashes, or another driver-specific value for non-result-set statements

    @see AbstractDatasource::selectRowsTyped()

    @since %Qore 3.0
 */
abstract auto vselectRowsTyped(string sql, __7_ softlist<auto> arguments);

public:
//! Executes a select statement and returns a typed column-oriented result, taking a list for all bind arguments
/** This method is the same as AbstractDatasource::selectTyped(), except this method takes a single argument after the
    %SQL command giving the list of bind value parameters.

   @par Code Flags:
    @ref NAMED_ARGS

     @param sql The %SQL command to execute on the server
    @param arguments Include any values to be bound (using <tt>%v</tt> in the command string) or placeholder
    specifications (using <tt>:</tt><em>key_name</em> in the command string) in order after the command string

    @return Normally returns a typed column result hash, or another driver-specific value for non-result-set statements

    @see AbstractDatasource::selectTyped()

    @since %Qore 3.0
 */
abstract auto vselectTyped(string sql, __7_ softlist<auto> arguments);
};
}
}
