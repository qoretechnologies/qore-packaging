
//! main Qore-language namespace
namespace Qore {
//! Methods in this pseudo-class can be executed on @ref string "strings"
/***/
class zzz8stringzzz9 : public zzz8valuezzz9 {

public:
//! Returns a lazy iterator yielding each Unicode codepoint of the string as an integer.
/** Each yielded value is the codepoint at the iterator's current position
    (decoded from the source string's encoding via
    \c QoreString::getUnicodePointFromBytePos()).  Designed for
    character-aware tokenizers and parsers.

    For pure ASCII / byte-oriented work,
    @ref Qore::zzz8stringzzz9::getByte() is faster (skips codepoint decoding).
    For yielding each character as a 1-character @ref string, use
    @ref Qore::zzz8stringzzz9::splitChars() instead.

    @return a @ref Qore::StringCharIterator "StringCharIterator" yielding
            integer codepoints

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
int letters = 0;
foreach int cp in (text.codePointIterator()) {
    if ((cp >= ord("A") && cp <= ord("Z")) || (cp >= ord("a") && cp <= ord("z"))) {
        ++letters;
    }
}
    @endcode

    @since %Qore 3.0
 */
AbstractIterator<int> codePointIterator() const;

public:
//! Compares the beginning of the current string with a shorter string passed as an argument
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @par Example:
    @code{.py}
int i = str.comparePartial(other_string);
    @endcode

    @param other_string the partial string to compare the current string to

    @return -1, 0, or 1 if the argument string is less than, equal, or greater than the beginning of the current
    string; returns also -1 if the argument string is equal to the beginning of the current string but the argument
    string is longer than the current string

    @since %Qore 0.8.8
*/
int comparePartial(string other_string) const;

public:
//! Returns @ref True if the given string contains the argument
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @param substring The characters to check in the string

    @return @ref True if the given string contains the argument

    @note an empty \a substring is contained in every string, including an empty string

    @since %Qore 2.0
    @since %Qore 3.0 an empty \a substring is contained in every string
*/
bool contains(string substring) const;

public:
//! Returns @ref True if the string is empty, @ref False if not
/** The opposite of Qore::zzz8stringzzz9::val()

    @return @ref True if the string is empty, @ref False if not

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
bool b = str.empty();
    @endcode
*/
bool empty() const;

public:
//! Returns the name of the string's @ref character_encoding "character encoding"
/**@return the name of the string's @ref character_encoding "character encoding"

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
string enc = str.encoding();
    @endcode

    @note equivalent to @ref Qore::get_encoding(string)
*/
string encoding() const;

public:
//! Returns @ref True if the given string ends with the argument
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @param suffix The characters to check at the end of the string

    @return @ref True if the given string ends with the argument

    @since %Qore 2.0
*/
bool endsWith(string suffix) const;

public:
//! Compares the beginning of the current string with a shorter string passed as an argument for equality only, returns @ref True "True" if the string argument matches the beginning of the string, @ref False "False" if not
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @par Example:
    @code{.py}
bool b = str.equalPartial(other_string);
    @endcode

    This pseudo-method is slightly faster than comparePartial() since the length of the substring can be used to
    determine if the strings can match or not.

    @param other_string the partial string to compare the current string to

    @return @ref True "True" if the string argument matches the beginning of the string, @ref False "False" if not

    @since %Qore 0.8.8
*/
bool equalPartial(string other_string) const;

public:
//! Compares the beginning of the current string assumed to be a path with a shorter string passed as an argument for equality only, returns @ref True "True" if the string argument matches the beginning of the string where either both strings are the same size or the current string has a '/' or '?' character after the point where the argument string stops, @ref False "False" if not
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @par Example:
    @code{.py}
bool b = str.equalPartialPath(other_string);
    @endcode

    @param other_string the partial string to compare the current string to

    @return @ref True "True" if the string argument matches the beginning of the string where either both strings are
    the same size or the current string has a '/' or '?' character after the point where the argument string stops,
    @ref False "False" if not

    @since %Qore 0.8.8
*/
bool equalPartialPath(string other_string) const;

public:
//! Retrieves the character position of a substring within a string
/** The \a offset argument and the return value are in character positions; byte offsets may differ from the character offsets with multi-byte @ref character_encoding "character encodings".

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param substring the substring to find in the string; if the @ref character_encoding "character encoding" of this string does not match \a str, then it will be converted to <em>str</em>'s @ref character_encoding "character encoding" before processing
    @param offset the starting character position for the search

    @return the character position of a substring within a string, -1 is returned if the substring is not found

    @note an empty substring is found at the search position, as at every position from the start to the end of the
    string inclusive; a search position after the end of the string has no match

    @par Example:
    @code{.py}
int i = str.find(substr);
if (i == -1)
    printf("could not find %y in %y\n", substr, str);
    @endcode

    @throw ENCODING-CONVERSION-ERROR this exception could be thrown if the string arguments have different @ref character_encoding "character encodings" and an error occurs during encoding conversion
    @throw INVALID-ENCODING this exception could be thrown if a character offset calculation fails due to invalid encoding of multi-byte character data

    @note equivalent to @ref Qore::index(softstring, softstring, softint)

    @see
    - Qore::zzz8stringzzz9::rfind(softstring, softint)
    - rindex(softstring, softstring, softint)
    - bindex(softstring, softstring, softint)
    - brindex(softstring, softstring, softint)
 */
int find(softstring substring, softint offset = 0) const;

public:
//! Returns the raw byte at the given byte offset, or @ref nothing if the offset is out of range.
/** Unlike \c string[] which allocates a fresh
    one-character QoreStringNode per call, this pseudo-method returns the byte as an
    integer (0..255) with no allocation.  Designed for hot byte-oriented scan loops
    (tokenizers, simple parsers) where the per-call string allocation dominates.

    For multi-byte encodings, the returned value is a single byte of the underlying
    encoding (UTF-8 byte, etc.), NOT a Unicode codepoint.  Use @ref getUnicode() if
    you need codepoints.

   @par Code Flags:
    @ref CONSTANT, @ref NAMED_ARGS

     @par Example:
    @code{.py}
*int b = src.getByte(pos);
if (b == ord("#")) { ... }
    @endcode

    @param byte_offset the byte offset into the string (negative values count from the end)

    @return the raw byte at the offset (0..255), or @ref nothing if the offset is
            out of range

    @since %Qore 3.0
*/
__7_ int getByte(int byte_offset) const;

public:
//! returns a string based on the string value, decoded as per the \a code argument
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @par
    @code{.py}
string ns = string.getDecoded(CE_XML);
    @endcode

    @param decoding_flags a decoding bitfield argument; see @ref StringConcatDecoding for more information

    @see Qore::zzz8stringzzz9::getEncoded()

    @since %Qore 0.8.12
 */
string getDecoded(int decoding_flags = CD_ALL) const;

public:
//! returns a string based on the string value with encodings as per the \a code argument
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @par
    @code{.py}
string ns = string.getEncoded(CE_XML);
    @endcode

    @param encoding_flags an encoding bitfield argument; see @ref StringConcatEncoding for more information

    @see Qore::zzz8stringzzz9::getDecoded()

    @since %Qore 0.8.12
 */
string getEncoded(int encoding_flags = CE_XHTML) const;

public:
//! returns a string for the next line in the string buffer starting at the given offset (or at the beginning if no offset is given)
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @par Example:
    @code{.py}
*string line = string.getLine(pos);
    @endcode

    @param offset the offset in bytes from the beginning of the string; negative numbers give an offset from the end
    of the string
    @param line_separator the optional end of line character(s) to use to detect lines in the buffer; if this string is not
    passed, then the end of line character(s) are detected automatically, and can be either \c "\n", \c "\r", or
    \c "\r\n"; if this string is passed and has a different @ref character_encoding "character encoding" from this
    object's (as determined by the \c encoding parameter), then it will be converted to the string's
    @ref character_encoding "character encoding"
    @param trim_line if @ref True the string return values for the lines iterated will be trimmed of the eol bytes
    @param byte_count an optional reference to an integer that returns the number of bytes in the line including the end of
    line characters

    @return the line found or @ref nothing if no end of line character(s) were found or no data was found after the
    offset

    @since %Qore 0.8.9
 */
__7_ string getLine(int offset = 0, __7_ string line_separator, bool trim_line = True, __7_ reference<int> byte_count) const;

public:
//! returns the Unicode code for the given character offset in the string
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @par Example:
    @code{.py}
int uc = str.getUnicode(0);
    @endcode

    @param offset the offset in characters in the string; negative numbers give offsets from the end of the string

    @return the Unicode code for the given character offset in the string

    @since %Qore 0.8.8
*/
int getUnicode(int offset = 0) const;

public:
//! Returns @ref True if the string can be converted to an integer, @ref False if not, this depends on the first (or possibly second) character of the string, if it's 0 - 9 (possibly preceded by \c "-"), then the method returns @ref True
/**@return @ref True if the string can be converted to an integer, @ref False if not, this depends on the first (or possibly second) character of the string, if it's 0 - 9 (possibly preceded by \c "-"), then the method returns @ref True

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
if (n.intp())
    printf("%y: can be converted to an integer: %d\n", n, int(n));
    @endcode
*/
bool intp() const;

public:
//! returns @ref True if the string is empty or has no characters with the high bit set (ie all characters < 128)
/** @return @ref True if the string is empty or has no characters with the high bit set (ie all characters < 128)

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
bool b = str.isDataAscii();
    @endcode

    @since %Qore 0.8.6
 */
bool isDataAscii() const;

public:
//! returns @ref True if the string is empty or only contains printable non-control ASCII characters (ie all characters > 31 && < 127)
/** @return @ref True if the string is empty or only contains printable non-control ASCII characters (ie all
    characters > 31 && < 127)

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
bool b = str.isDataPrintableAscii();
    @endcode

    @since %Qore 0.8.6
 */
bool isDataPrintableAscii() const;

public:
//! Returns a lazy iterator yielding each Unicode codepoint of the string as a char value.
/** Each yielded value is a @ref char decoded from the source string's
    encoding via \c QoreString::getUnicodePointFromBytePos().  This is the
    pseudo-method used by <tt>iterate string</tt>.

    For integer codepoints, use
    @ref Qore::zzz8stringzzz9::codePointIterator() instead.  For
    single-character strings, use @ref Qore::zzz8stringzzz9::splitChars().

    @return a @ref Qore::StringIterator "StringIterator" yielding char values

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
foreach char c in (text.iterator()) {
    printf("%y\n", c.ord());
}
    @endcode

    @since %Qore 3.0
 */
AbstractIterator<char> iterator() const;

public:
//! Returns the number of characters in the string; may not be equal to the byte length (returned by Qore::zzz8stringzzz9::strlen() and Qore::zzz8stringzzz9::size()) for @ref character_encoding "multi-byte character encodings"
/**@return the number of characters in the string; may not be equal to the byte length (returned by Qore::zzz8stringzzz9::strlen() and Qore::zzz8stringzzz9::size()) for @ref character_encoding "multi-byte character encodings"

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
int len = str.length();
    @endcode

    @note
    - this operation has <i>O(n)</i> complexity if the string has a multi-byte @ref character_encoding "character encoding", otherwise it is <i>O(1)</i>
    - equivalent to @ref Qore::length(softstring)

    @see
    - Qore::zzz8stringzzz9::strlen()
    - Qore::zzz8stringzzz9::size()
    - Qore::zzz8stringzzz9::width()
*/
int length() const;

public:
//! Returns the string in lower case
/** @par Code Flags:
    @ref CONSTANT

    @par Example:
    @code{.py}
printf("%y", "PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ ÓDY".lwr());
# outputs: "příliš žluťoučký kůň úpěl ďábelské ódy"
    @endcode

    This pseudo-method applies the Unicode default <i>full</i> lower-case mapping to every
    character in the string.  The mapping covers the entire Unicode range and can map a single
    character to more than one character (for example <tt>U+0130</tt> maps to
    <tt>U+0069 U+0307</tt>); characters with no lower-case mapping are returned unchanged.  The
    language-independent @c Final_Sigma condition is applied, so a Greek capital sigma
    (<tt>U+03A3</tt>) at the end of a word maps to <tt>U+03C2</tt> rather than <tt>U+03C3</tt>;
    language-specific mappings (Turkish, Azeri, and Lithuanian) are not applied.
    A character whose mapping cannot be represented in the string's
    @ref character_encoding "character encoding" is returned unchanged; case conversion never
    raises an encoding conversion error.

    @return the string in lower case

    @note
    - equivalent to @ref Qore::tolower(string)

    @see
    - Qore::zzz8stringzzz9::upr()
    - @ref Qore::zzz8charzzz9::lwr() "Qore::zzz8charzzz9::lwr()"
    - tolower()
    - toupper()

    @since %Qore 0.8.8 this pseudo-method operates on a wide range of characters and is no longer limited to ASCII characters
*/
string lwr() const;

public:
//! Returns @ref True if the regular expression matches the string passed, otherwise returns @ref False
/** Strings are converted to UTF-8 for pattern-matching; if any invalid encodings are encountered, an
    \c ENCODING-CONVERSION-ERROR is raised

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param pattern the regular expression pattern
    @param options regular expression options; see @ref regex_constants for possible values

    @return @ref True if the regular expression matches the string passed, otherwise returns @ref False

    @par Example:
    @code{.py}
bool b = "hello".regex("^hel"); # returns True
    @endcode

    @throw REGEX-COMPILATION-ERROR There was an error compiling the regular expression
    @throw REGEX-OPTION-ERROR the option argument contains invalid option bits
    @throw ENCODING-CONVERSION-ERROR this exception could be thrown if an encoding error is encountered when
    converting the given strings to UTF-8

    @note equivalent to @ref Qore::regex(string, string, int)

    @see @ref qore_regex for more information about regular expression support in Qore

    @since %Qore 0.8.5
 */
bool regex(string pattern, int options = 0) const;

public:
//! Returns the number of non-overlapping matches of a regular expression pattern in the string
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @param pattern the regular expression pattern to count
    @param options optional @ref regex_constants "regex option constants"

    @return the number of non-overlapping matches found; 0 if no match

    @par Example:
    @code{.py}
int n = "abc 123 def 456".regexCount("\\d+"); # returns 2
    @endcode

    @throw REGEX-COMPILATION-ERROR invalid regular expression
    @throw REGEX-OPTION-ERROR invalid option flag
    @throw ENCODING-CONVERSION-ERROR this exception could be thrown if the string arguments have different
    @ref character_encoding "character encodings" and an error occurs during encoding conversion

    @since %Qore 3.0

    @see regex_count()
*/
int regexCount(string pattern, int options = 0) const;

public:
//! Escapes all non-alphanumeric characters in the string with a backslash, making it safe for use as a literal pattern in regular expressions
/** @return a new string where all non-alphanumeric characters are prefixed with a backslash

    @note Escaping is character-aware; non-ASCII codepoints are escaped as whole characters, not as their
    encoded bytes.

   @par Code Flags:
    @ref RET_VALUE_ONLY

     @par Example:
    @code{.py}
string escaped = "price: $100".regexEscape(); # returns "price\\:\\ \\$100"
    @endcode

    @since %Qore 3.0

    @see regex_escape()
*/
string regexEscape() const;

public:
//! Returns a list of substrings in a string based on matching patterns defined by a regular expression
/** Strings are converted to UTF-8 for pattern-matching; if any invalid encodings are encountered, an
    \c ENCODING-CONVERSION-ERROR is raised

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param pattern the regular expression to use for matching, elements should be given in parentheses
    @param options regular expression options; see @ref regex_constants for possible values

    @return a list of substrings in a string based on matching patterns defined by a regular expression or
    @ref nothing if no match was made

    @par Example:
    @code{.py}
string str = "ns:element";
*list<*string> rv = str.regexExtract("(\\w+):(\\w+)");
    @endcode

    @throw REGEX-COMPILATION-ERROR There was an error compiling the regular expression
    @throw REGEX-OPTION-ERROR the option argument contains invalid option bits
    @throw ENCODING-CONVERSION-ERROR this exception could be thrown if an encoding error is encountered when
    converting the given strings to UTF-8

    @note equivalent Qore::regex_extract(string, string, int)

    @see @ref qore_regex for more information about regular expression support in Qore

    @since %Qore 0.8.5

    @since %Qore 0.8.8 this function accepts the @ref Qore::RE_Global option to extract all occurrences of the
    pattern(s) in a string
 */
__7_ list<*string> regexExtract(string pattern, int options = 0) const;

public:
//! Returns detailed match information for all matches of a regular expression pattern in the string
/** Returns a list of @ref Qore::RegexMatchInfo "RegexMatchInfo" hashes containing match text,
    offsets, captured groups, and named groups.

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param pattern the regular expression pattern
    @param options optional @ref regex_constants "regex option constants"; use @ref RE_Global to find all matches

    @return a list of @ref Qore::RegexMatchInfo "RegexMatchInfo" hashes; @ref nothing if no match

    @par Example:
    @code{.py}
*list<hash<RegexMatchInfo>> matches = "hello world".regexExtractDetailed("\\w+", RE_Global);
# matches[0] = {"match": "hello", "offset": 0, "length": 5}
# matches[1] = {"match": "world", "offset": 6, "length": 5}
    @endcode

    @throw REGEX-COMPILATION-ERROR invalid regular expression
    @throw REGEX-OPTION-ERROR invalid option flag
    @throw ENCODING-CONVERSION-ERROR this exception could be thrown if the string arguments have different
    @ref character_encoding "character encodings" and an error occurs during encoding conversion

    @since %Qore 3.0

    @see regex_extract_detailed()
*/
__7_ list<hash<RegexMatchInfo>> regexExtractDetailed(string pattern, int options = 0) const;

public:
//! Extracts named capture groups from the string using a regular expression pattern
/** Named groups are defined with <tt>(?&lt;name&gt;...)</tt> or <tt>(?P&lt;name&gt;...)</tt> syntax.

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param pattern the regular expression pattern containing named groups
    @param options optional @ref regex_constants "regex option constants"; use @ref RE_Global to extract all matches

    @return for non-global: \c *hash<string, *string> where keys are group names and values are matched text
    (or @ref nothing for unmatched optional groups); for global: \c *list<hash<string, *string>>; returns
    @ref nothing if there are no named groups in the pattern or no match

    @par Example:
    @code{.py}
auto h = "2026-04-08".regexExtractNamed("(?<year>\\d{4})-(?<month>\\d{2})-(?<day>\\d{2})");
# h = {"year": "2026", "month": "04", "day": "08"}
    @endcode

    @throw REGEX-COMPILATION-ERROR invalid regular expression
    @throw REGEX-OPTION-ERROR invalid option flag
    @throw ENCODING-CONVERSION-ERROR this exception could be thrown if the string arguments have different
    @ref character_encoding "character encodings" and an error occurs during encoding conversion

    @since %Qore 3.0

    @see regex_extract_named()
*/
auto regexExtractNamed(string pattern, int options = 0) const;

public:
//! Retrieves the character position of a substring within a string, starting the search from the end of the string
/** The \a offset argument and the return value are in character positions; byte offsets may differ from the character offsets with multi-byte @ref character_encoding "character encodings".

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param substring the substring to find in \a str; if the @ref character_encoding "character encoding" of this string does not match \a str, then it will be converted to <em>str</em>'s @ref character_encoding "character encoding" before processing
    @param offset the starting character position for the search, -1 means start from the end of the string

    @return the character position of a substring within a string, -1 is returned if the substring is not found

    @note an empty substring is found at the search position, as at every position from the start to the end of the
    string inclusive; with the default search position (-1, the end of the string), it is found at the end of the
    string (the length of the string)

    @par Example:
    @code{.py}
int i = str.rfind(substr);
if (i == -1)
    printf("could not find %y in %y\n", substr, str);
    @endcode

    @throw ENCODING-CONVERSION-ERROR this exception could be thrown if the string arguments have different @ref character_encoding "character encodings" and an error occurs during encoding conversion
    @throw INVALID-ENCODING this exception could be thrown if a character offset calculation fails due to invalid encoding of multi-byte character data

    @note equivalent to @ref Qore::rindex(softstring, softstring, softint)

    @see
    - Qore::zzz8stringzzz9::find(softstring, softint)
    - index(softstring, softstring, softint)
    - bindex(softstring, softstring, softint)
    - brindex(softstring, softstring, softint)
 */
int rfind(softstring substring, softint offset = -1) const;

public:
//! Returns the number of bytes in the string (not including the terminating null character (\c '\0')
/**@return the number of bytes in the string (not including the terminating null character (\c '\0')

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
int len = str.size();
    @endcode

    @note
    - this operation is always executed in constant time (ie <i>O(1)</i>) because the string's byte length is always stored with the string
    - equivalent to Qore::zzz8stringzzz9::strlen() and @ref Qore::strlen(softstring)

    @see
    - Qore::zzz8stringzzz9::sizep()
    - Qore::zzz8stringzzz9::length()
    - Qore::zzz8stringzzz9::width()
*/
int size() const;

public:
//! Returns @ref True since strings can return a non-zero size
/** @par Code Flags:
    @ref CONSTANT

@return @ref True since strings can return a non-zero size

    @see Qore::zzz8stringzzz9::size()

    @since %Qore 0.8.9
*/
bool sizep() const;

public:
//! Splits a string into a list of components based on a separator string
/**@par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @param separator the separator string; if the separator string is not found in the string to split, then a list with only one element containing the entire string argument is returned'; if this string has a different @ref character_encoding "character encoding" than \a str, then it will be converted to <em>str</em>'s @ref character_encoding "character encoding"
    @param with_separator include the separator string in every element
    @param keep_trailing_empty keep the empty final field produced by a subject that ends with the separator; see @ref split_trailing_empty_fields

    @return a list of each component of a string separated by a separator string, with the separator removed; the separator pattern will not be included in the elements of the list returned unless the \a with_separator argument is @ref True

    @par Example:
    @code{.py}
string str = "some:text:here";
list<string> list = str.split(":"); # returns ("some", "text", "here")
list<string> t = "a/b/".split("/", False, True); # returns ("a", "b", "")
    @endcode

    @throw ENCODING-CONVERSION-ERROR this exception could be thrown if the string arguments have different @ref character_encoding "character encodings" and an error occurs during encoding conversion

    @note equivalent to @ref Qore::split(string, string, bool, bool)

    @since
    - %Qore 0.8.5
    - %Qore 3.0 added the \c keep_trailing_empty parameter
 */
list<string> split(string separator, bool with_separator = False, bool keep_trailing_empty = False) const;

public:
//! Splits a string into a list of components based on a separator string and a quote character
/** The quote character can appear as the first part of a field, in which case it is assumed to designate the entire
    field. If instances of the quote character are found in the field preceded by a backquote character
    (<tt>\\</tt>), then these quote characters are included as part of the field's text and not treated as quote
    characters.
    Also the separator character can appear as a part of a field with this variant.
    This variant is useful for parsing CSV files, for example.

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param separator the separator string; if the separator string is not found in the string to split, then a list with
    only one element containing the entire string argument is returned'; if this string has a different
    @ref character_encoding "character encoding" than \a str, then it will be converted to <em>str</em>'s
    @ref character_encoding "character encoding"
    @param quote the quote character
    @param trim_unquoted remove leading and trailing whitespace from unquoted fields
    @param keep_trailing_empty keep the empty final field produced by a subject that ends with the separator; see
    @ref split_trailing_empty_fields

    @return a list of each component of a string separated by a separator string, with the separator and any enclosing
    quote characters removed

    @par Example:
    @code{.py}
# returns ("some", ", and commas, here is another one! ,", "here")
list<string> list = "some,'text with spaces, and commas, here is another one! ,',here".split(",", "'");
    @endcode

    @throw ENCODING-CONVERSION-ERROR this exception could be thrown if the string arguments have different
    @ref character_encoding "character encodings" and an error occurs during encoding conversion

    @throw SPLIT-ERROR field missing closing quote character; extra text following quoted field

    @note equivalent to @ref Qore::split(string, string, string, bool, bool)

    @since
    - %Qore 0.8.5 added this pseudo-method
    - %Qore 0.8.6 added the \c trim_unquoted parameter
    - %Qore 3.0 added the \c keep_trailing_empty parameter
 */
list<string> split(string separator, string quote, bool trim_unquoted = False, bool keep_trailing_empty = False) const;

public:
//! Returns a lazy iterator yielding each character of the string, one per element.
/** Each element is a zero-copy @ref Qore::StringSplitIterator "StringSplitIterator"
    view covering one codepoint of the source string.  Works with any encoding
    Qore supports (the iterator walks codepoints using
    \c QoreString::getUnicodePointFromBytePos()).

    Streaming counterpart of the eager list-returning @ref Qore::zzz8stringzzz9::split() "Qore::zzz8stringzzz9::split()"
    pseudo-methods; the intermediate list is never materialised.

    @return a @ref Qore::StringSplitIterator "StringSplitIterator" in
            SPLIT_CHARS mode

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
int digits = foldl $1 + ($2 =~ /[0-9]/ ? 1 : 0), 0, str.splitChars();
    @endcode

    @since %Qore 3.0
 */
AbstractIterator<string> splitChars() const;

public:
//! Returns a lazy iterator yielding each line of the string, one per element.
/** Splits on "\n"; a trailing "\r" byte on each piece is trimmed so files
    with "\r\n" line endings iterate identically to "\n"-delimited files.
    Streaming counterpart of splitting on "\n" and then mapping \c chomp;
    the intermediate list is never built when consumed by @ref map,
    @ref select, or @ref foldl.

    @return an @ref Qore::StringSplitIterator "StringSplitIterator"

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
int errors = foldl $1 + ($2 =~ /ERROR/ ? 1 : 0), 0, log.splitLines();
    @endcode

    @since %Qore 3.0
 */
AbstractIterator<string> splitLines() const;

public:
//! Returns a lazy iterator yielding the pieces produced by splitting on a regex.
/** Streaming counterpart of @ref Qore::zzz8stringzzz9::splitRegex; returns a
    @ref Qore::StringRegexSplitIterator "StringRegexSplitIterator"
    that runs one @c pcre2_match per element and yields zero-copy
    views onto the (UTF-8) subject string.  Composes directly with
    @ref map, @ref select, @ref foldl, and @c foreach — the
    intermediate list is never built, and early termination
    (select / first) stops the scan at the first hit.

    Eager splitting is still available via
    @ref Qore::zzz8stringzzz9::splitRegex when every piece is needed and
    throughput matters more than memory.

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param separator_pattern the separator regular expression
    @param options regex options (e.g. \c RE_Caseless)
    @param with_separator include the separator match in each element

    @return a @ref Qore::StringRegexSplitIterator "StringRegexSplitIterator"

    @par Example:
    @code{.py}
# first line containing FATAL — stops at first hit
*string fatal = first(select text.splitLinesRegex("\r?\n|\r"),
                      $1 =~ /FATAL/);
    @endcode

    @since %Qore 3.0
 */
AbstractIterator<string> splitLinesRegex(string separator_pattern, int options = 0, bool with_separator = False) const;

public:
//! Splits a string into a list of components based on a separator regular expression
/**@par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @par Example:
    @code{.py}
string str = "some\\:text:here";
list<string> list = str.splitRegex("(?<!\\\\)\\:"); # returns ("some\\:text", "here")
    @endcode

    @param separator_pattern the separator regular expression; if the separator regular expression is not matched in the
    string to split, then a list with only one element containing the entire string argument is returned'; if this
    string has a different @ref character_encoding "character encoding" than \a str, then it will be converted to
    <em>str</em>'s @ref character_encoding "character encoding"
    @param options regular expression options; see @ref regex_constants for possible values
    @param with_separator include the separator string in every element
    @param limit the maximum number of elements to return; \c -1 (the default) means no limit; when the limit is
    reached, the last element will contain the remainder of the string

    @return a list of each component of a string separated by a separator regular expression, with the separator
    removed; the separator pattern will not be included in the elements of the list returned unless the
    \a with_separator argument is @ref True; the strings in the return value are always returned in UTF-8 encoding

    @throw ENCODING-CONVERSION-ERROR this exception could be thrown if the string arguments have different
    @ref character_encoding "character encodings" and an error occurs during encoding conversion

    @since %Qore 1.0.7
    @since %Qore 3.0 added the \a limit parameter
 */
list<string> splitRegex(string separator_pattern, int options = 0, bool with_separator = False, int limit = -1) const;

public:
//! Splits a string into a list of components based on a separator regular expression
/**@par Code Flags:
    @ref RET_VALUE_ONLY

    @par Example:
    @code{.py}
string str = "some\\:text:here";
list<string> list = str.splitRegex("(?<!\\\\)\\:"); # returns ("some\\:text", "here")
    @endcode

    @param separator_pattern the separator regular expression; if the separator regular expression is not matched in the
    string to split, then a list with only one element containing the entire string argument is returned'; if this
    string has a different @ref character_encoding "character encoding" than \a str, then it will be converted to
    <em>str</em>'s @ref character_encoding "character encoding"
    @param with_separator include the separator string in every element
    @param limit the maximum number of elements to return; \c -1 (the default) means no limit; when the limit is
    reached, the last element will contain the remainder of the string

    @return a list of each component of a string separated by a separator regular expression, with the separator
    removed; the separator pattern will not be included in the elements of the list returned unless the
    \a with_separator argument is @ref True; the strings in the return value are always returned in UTF-8 encoding

    @throw ENCODING-CONVERSION-ERROR this exception could be thrown if the string arguments have different
    @ref character_encoding "character encodings" and an error occurs during encoding conversion

    @since %Qore 1.0.7
    @since %Qore 3.0 added the \a limit parameter
 */
list<string> splitRegex(string separator_pattern, bool with_separator = False, int limit = -1) const;

public:
//! Returns a lazy @ref Qore::StringSplitIterator iterator yielding zero-copy views of each piece.
/** Streaming counterpart of @ref split(); the intermediate @ref list "list" is
    never built when the iterator is consumed by @ref map, @ref select, or
    @ref foldl.  Each yielded element is a view onto the original string's
    buffer, materialised lazily only if the caller mutates it.

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param separator the byte-wise delimiter; an empty delimiter yields the whole
           string once

    @return an @ref Qore::StringSplitIterator "StringSplitIterator"

    @par Example:
    @code{.py}
int errors = foldl $1 + ($2 =~ /ERROR/ ? 1 : 0), 0, log.splitString("\n");
    @endcode

    @since %Qore 3.0
 */
AbstractIterator<string> splitString(string separator) const;

public:
//! Returns @ref True if the given string starts with the argument
/** @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

    @param prefix The characters to check at the beginning of the string

    @return @ref True if the given string starts with the argument

    @since %Qore 2.0
*/
bool startsWith(string prefix) const;

public:
//! Returns the number of bytes in the string (not including the terminating null character (\c '\0')
/**@return the number of bytes in the string (not including the terminating null character (\c '\0')

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
int len = str.strlen();
    @endcode

    @note
    - this operation is always executed in constant time (ie <i>O(1)</i>) because the string's byte length is always stored with the string
    - equivalent to Qore::zzz8stringzzz9::size() and @ref Qore::strlen(softstring)

    @see
    - Qore::zzz8stringzzz9::size()
    - Qore::zzz8stringzzz9::length()
    - Qore::zzz8stringzzz9::width()
*/
int strlen() const;

public:
//! Returns @ref True by default
/**@return @ref True by default

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
if (n.strp())
    printf("%y: can be converted to a string: '%s'\n", n, string(n));
    @endcode
*/
bool strp() const;

public:
//! Returns a portion of a string starting from an integer offset
/** Arguments can be negative, giving offsets from the end of the string. All offsets are character positions, not byte positions.

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param start The starting character for the substring where the first character is at offset 0; if the offset is negative, it designates the number of characters from the end of the string.  If the offset is 0, then the entire string is returned.

    @return the substring of the string starting from an integer character offset; the rest of the string is returned after this offset; an emtpy string is returned if the argument cannot be satisfied

    @par Example:
    @code{.py}
# get the last 10 characters of a string
string substr = str.substr(-10);
    @endcode

    @throw INVALID-ENCODING this exception could be thrown if a character offset calculation fails due to invalid encoding of multi-byte character data

    @note equivalent to @ref Qore::substr(softstring, softint)
 */
string substr(softint start) const;

public:
//! Returns a portion of a string starting from an integer offset, with a length parameter
/** Arguments can be negative, giving offsets from the end of the string. All offsets are character positions, not byte positions.

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param start The starting character for the substring where the first character is at offset 0; if the offset is negative, it designates the number of characters from the end of the string
    @param length The maximum number of characters to copy; if this value is negative, the rest of the string from \a start will be copied to the substring, except without - \a length characters from the end of the string

    @return the substring of the string according to the arguments passed; an emtpy string is returned if the argument cannot be satisfied

    @par Example:
    @code{.py}
# get a substring 10 characters into the string except omitting the last 2 characters of the string
string substr = str.substr(10, -2);
    @endcode

    @throw INVALID-ENCODING this exception could be thrown if a character offset calculation fails due to invalid encoding of multi-byte character data

    @note equivalent to @ref Qore::substr(softstring, softint, softint)

    @since %Qore 0.8.5
 */
string substr(softint start, softint length) const;

public:
//! Returns the base64-encoded representation of the string
/** @par Code Flags:
    @ref CONSTANT, @ref NAMED_ARGS

    @par Example:
    @code{.py}
string base64 = str.toBase64(64);
    @endcode

    Implementation based on <a href="http://www.ietf.org/rfc/rfc1421.txt">RFC-1421</a> and
    <a href="http://www.ietf.org/rfc/rfc2045.txt">RFC-2045</a>

    @param max_line_length the maximum length of a line in the resulting output string in bytes; if this value is > 0 then
    output lines will be separated by CRLF characters

    @return the base64-encoded string of the data passed

    @since %Qore 0.8.8

    @see
    - Qore::zzz8binaryzzz9::toBase64()
    - make_base64_string(string, softint)
*/
string toBase64(softint max_line_length = -1) const;

public:
//! Returns the base64-url-encoded representation of the string
/** Base64-URL encoding is defined by <a href="https://datatracker.ietf.org/doc/html/rfc4648">RFC-4648</a>

   @par Code Flags:
    @ref CONSTANT, @ref NAMED_ARGS

     @par Example:
    @code{.py}
string base64 = str.toBase64Url();
    @endcode

    @param max_line_length ignored for Base64-URL output; accepted for compatibility with Qore::zzz8stringzzz9::toBase64()

    @return the base64-url-encoded string of the data passed

    @since %Qore 1.19.0

    @see
    - Qore::zzz8binaryzzz9::toBase64Url()
    - make_base64_url_string(string)
*/
string toBase64Url(softint max_line_length = -1) const;

public:
//! Returns a binary value with the string's data
/** @par Code Flags:
    @ref CONSTANT

    @par Example:
    @code{.py}
binary bin = str.toBinary();
    @endcode

    @return a binary value with the string's data

    @see Qore::binary(softstring) "binary(softstring)"

    @since %Qore 0.9.3
*/
binary toBinary() const;

public:
//! returns a string of hexadecimal digits corresponding to the contents of the string
/** @par Code Flags:
    @ref CONSTANT

    @par Example:
    @code{.py}
string str = str.toHex();
    @endcode

    @return a string of hexadecimal digits corresponding to the contents of the string

    @since %Qore 0.8.8

    @see
    - Qore::zzz8binaryzzz9::toHex()
    - make_hex_string(string)
 */
string toHex() const;

public:
//! Converts the string to an integer value with respect to the <b>base</b>
/** If a character is out of range of the corresponding <b>base</b> only the substring preceeding the character is
    taken into account.\n
    Base 0 means to interpret as a code literal, so that the actual base is 8, 10, or 16.

   @par Code Flags:
    @ref RET_VALUE_ONLY, @ref NAMED_ARGS

     @param base the base of the integer in the string; this value must be 0 or 2 - 36 inclusive or an \c INVALID-BASE
    exception will be thrown

    @return the integer value corresponding to the arguments

    @par Example:
    @code{.py}
"fe".toInt(16);   // returns 254
"34".toInt(5);    // returns 19
"2p".toInt(25);   // returns 2  (p means 25, which is out of range)
"2p".toInt(26);   // returns 77
"2z".toInt(36);   // returns 107
"21".toInt();     // returns 21 (base = 10)
"21".toInt(0);    // returns 21 (base = 10)
"021".toInt(0);   // returns 17 (base =  8)
"0x21".toInt(0);  // returns 33 (base = 16)
    @endcode

    @throw INVALID-BASE the base is invalid; must be 0 or 2 - 36 inclusive

    @see Qore::zzz8valuezzz9::toInt()
    @see Qore::int(string str, int base = 10)

    @since
    - %Qore 0.8.13; in previous versions the \link Qore::zzz8valuezzz9::toInt() \endlink function (without the <b>base</b>
      argument) applied also to strings
    - %Qore 3.0 a string in an encoding that is not ASCII-compatible (UTF-16) is converted as the same characters in
      UTF-8; previously an \c UNSUPPORTED-ENCODING exception was raised
  */
int toInt(int base = 10) const;

public:
//! Returns the <a href="http://en.wikipedia.org/wiki/MD5">MD5 message digest</a> of the string as a hex string
/** The trailing null character is not included in the digest returned.

    @return a hex string of the digest (ex: \c "5d41402abc4b2a76b9719d911017c592")

   @par Code Flags:
    @ref RET_VALUE_ONLY

     @par Example:
    @code{.py}
string str = "hello".toMD5(); # returns "5d41402abc4b2a76b9719d911017c592"
    @endcode

    @throw MD5-DIGEST-ERROR error calculating digest (should not normally happen)

    @note
    - equivalent to @ref Qore::MD5()
    - the MD5 algorithm is not collision-resistant; it's recommended to use another hash algorithm (like SHA-256) if
      cryptographic security is important

    @see
    - MD5_bin()
    - Qore::zzz8binaryzzz9::toMD5()

    @since %Qore 0.8.5
 */
string toMD5() const;

public:
//! Returns the <a href="http://en.wikipedia.org/wiki/SHA-1">SHA1</a> message digest of the string as a hex string
/** The trailing null character is not included in the digest returned.

    @return a hex string of the digest (ex: \c "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d")

   @par Code Flags:
    @ref RET_VALUE_ONLY

     @par Example:
    @code{.py}
string str = "hello".toSHA1(); # returns "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    @endcode

    @throw SHA1-DIGEST-ERROR error calculating digest (should not normally happen)

    @note equivalent to @ref Qore::SHA1()

    @see
    - SHA1_bin()
    - Qore::zzz8binaryzzz9::toSHA1()

    @since %Qore 0.8.5
 */
string toSHA1() const;

public:
//! Returns the SHA-224 message digest (a variant of <a href="http://en.wikipedia.org/wiki/SHA-2">SHA-2</a>) of the string as a hex string
/** The trailing null character is not included in the digest returned.

    @par Platform Availability:
    @ref Qore::Option::HAVE_SHA224

   @par Code Flags:
    @ref RET_VALUE_ONLY

 
    @return a hex string of the digest (ex: \c "ea09ae9cc6768c50fcee903ed054556e5bfc8347907f12598aa24193")

    @par Example:
    @code{.py}
string str = "hello".toSHA224("hello"); # returns "ea09ae9cc6768c50fcee903ed054556e5bfc8347907f12598aa24193"
    @endcode

    @throw SHA224-DIGEST-ERROR error calculating digest (should not normally happen)

    @note equivalent to @ref Qore::SHA224()

    @see
    - SHA224_bin()
    - Qore::zzz8binaryzzz9::toSHA224()

    @since %Qore 0.8.5
 */
string toSHA224() const;

public:
//! Returns the SHA-256 message digest (a variant of <a href="http://en.wikipedia.org/wiki/SHA-2">SHA-2</a>) of the string as a hex string
/** The trailing null character is not included in the digest returned.

    @par Platform Availability:
    @ref Qore::Option::HAVE_SHA256

   @par Code Flags:
    @ref RET_VALUE_ONLY

 
    @return a hex string of the digest (ex: \c "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824")

    @par Example:
    @code{.py}
string str = "hello".toSHA256(); # returns "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"
    @endcode

    @throw SHA256-DIGEST-ERROR error calculating digest (should not normally happen)

    @note equivalent to @ref Qore::SHA256()

    @see
    - SHA256_bin()
    - Qore::zzz8binaryzzz9::toSHA256()

    @since %Qore 0.8.5
 */
string toSHA256() const;

public:
//! Returns the SHA-384 message digest (a variant of <a href="http://en.wikipedia.org/wiki/SHA-2">SHA-2</a>) of the string as a hex string
/** The trailing null character is not included in the digest returned.

    @par Platform Availability:
    @ref Qore::Option::HAVE_SHA384

   @par Code Flags:
    @ref RET_VALUE_ONLY

 
    @return a hex string of the digest (ex:
    \c "59e1748777448c69de6b800d7a33bbfb9ff1b463e44354c3553bcdb9c666fa90125a3c79f90397bdf5f6a13de828684f")

    @par Example:
    @code{.py}
# returns "59e1748777448c69de6b800d7a33bbfb9ff1b463e44354c3553bcdb9c666fa90125a3c79f90397bdf5f6a13de828684f"
string str = "hello".toSHA384();
    @endcode

    @throw SHA384-DIGEST-ERROR error calculating digest (should not normally happen)

    @note equivalent to @ref Qore::SHA384()

    @see
    - SHA384_bin()
    - Qore::zzz8binaryzzz9::toSHA224()

    @since %Qore 0.8.5
 */
string toSHA384() const;

public:
//! Returns the SHA-512 message digest (a variant of <a href="http://en.wikipedia.org/wiki/SHA-2">SHA-2</a>) of the string as a hex string
/** The trailing null character is not included in the digest returned.

    @par Platform Availability:
    @ref Qore::Option::HAVE_SHA512

   @par Code Flags:
    @ref RET_VALUE_ONLY

 
    @return a hex string of the digest (ex:
    \c "9b71d224bd62f3785d96d46ad3ea3d73319bfbc2890caadae2dff72519673ca72323c3d99ba5c11d7c7acc6e14b8c5da0c4663475c2e5c3adef46f73bcdec043")

    @par Example:
    @code{.py}
# returns "9b71d224bd62f3785d96d46ad3ea3d73319bfbc2890caadae2dff72519673ca72323c3d99ba5c11d7c7acc6e14b8c5da0c4663475c2e5c3adef46f73bcdec043"
string str = "hello".toSHA512();
    @endcode

    @throw SHA512-DIGEST-ERROR error calculating digest (should not normally happen)

    @note equivalent to @ref Qore::SHA512()

    @see
    - SHA512_bin()
    - Qore::zzz8binaryzzz9::toSHA512()

    @since %Qore 0.8.5
 */
string toSHA512() const;

public:
//! Returns Qore::NT_STRING
/**@return Qore::NT_STRING

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
switch (str.typeCode()) {
    case NT_STRING:
        printf("%y: is a string\n", str);
        break;
}
    @endcode
*/
int typeCode() const;

public:
//! Returns a string with all accented characters removed
/** @par Code Flags:
    @ref RET_VALUE_ONLY

    @par Example:
    @code{.py}
string s = "příliš žluťoučký kůň úpěl ďábelské ódy";
printf("%y\n", s.unaccent()); # result: "prilis zlutoucky kun upel dabelske ody"
    @endcode

    The returned string has the same encoding as the original input.

    @return the string with accents replaced

    @since %Qore 0.8.8
*/
string unaccent() const;

public:
//! Returns the string in upper case
/** @par Code Flags:
    @ref CONSTANT

    @par Example:
    @code{.py}
printf("%y", "příliš žluťoučký kůň úpěl ďábelské ódy".upr());
# outputs: "PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ ÓDY"
    @endcode

    This pseudo-method applies the Unicode default <i>full</i> upper-case mapping to every
    character in the string.  The mapping covers the entire Unicode range and can map a single
    character to more than one character (for example <tt>U+00DF</tt> maps to @c "SS");
    characters with no upper-case mapping are returned unchanged.  Language-specific mappings
    (Turkish, Azeri, and Lithuanian) are not applied.
    A character whose mapping cannot be represented in the string's
    @ref character_encoding "character encoding" is returned unchanged; case conversion never
    raises an encoding conversion error.

    @return the string in upper case

    @note
    - equivalent to @ref Qore::toupper(string)

    @see
    - Qore::zzz8stringzzz9::lwr()
    - @ref Qore::zzz8charzzz9::upr() "Qore::zzz8charzzz9::upr()"
    - tolower()
    - toupper()

    @since %Qore 0.8.8 this pseudo-method operates on a wide range of characters and is no longer limited to ASCII characters
*/
string upr() const;

public:
//! Returns @ref False if the string is empty, @ref True if not
/** @return @ref False if the string is empty, @ref True if not

   @par Code Flags:
    @ref CONSTANT

     @par Example:
    @code{.py}
bool b = str.val();
    @endcode
*/
bool val() const;

public:
//! Returns the width of characters in the string; some unicode characters take up multiple spaces on output
/**@return the width of characters in the string; some unicode characters take up multiple spaces on output;
    for example the string "ステップの例" is made up of 6 double-wide characters, so the width is 12, while the length in
    characters is 6, and the size (string byte length) is 18

   @par Code Flags:
    @ref RET_VALUE_ONLY

     @par Example:
    @code{.py}
int width = str.width();
    @endcode

    @note
    - this operation has <i>O(n)</i> complexity if the string has a multi-byte @ref character_encoding "character encoding", otherwise it is <i>O(1)</i>
    - equivalent to @ref Qore::char_width(softstring)

    @see
    - Qore::zzz8stringzzz9::length()
    - Qore::zzz8stringzzz9::strlen()
    - Qore::zzz8stringzzz9::size()

    @since %Qore 0.9.4
*/
int width() const;
};
}
